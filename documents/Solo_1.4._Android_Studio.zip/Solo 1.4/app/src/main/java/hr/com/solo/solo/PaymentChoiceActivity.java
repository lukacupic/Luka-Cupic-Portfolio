package hr.com.solo.solo;

import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.adapters.PaymentTypeAdapter;
import hr.com.solo.solo.base.BaseActivity;
import hr.com.solo.solo.core.CoreApplication;
import hr.com.solo.solo.core.UserCatalogManager;

public class PaymentChoiceActivity extends BaseActivity  {
	@BindView(R.id.recycler_result_list) RecyclerView recyclerResultList;
	@BindView(R.id.container_layout) FrameLayout containerLayout;
	@BindView(R.id.ic_back) ImageView btnBack;
	@BindView(R.id.title) TextView title;
	PaymentTypeAdapter adapter;

	UserCatalogManager manager;

	public static final String PRICE = "price";
	@Override
	public void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.activity_payment_type);
		ButterKnife.bind(this);
		title.setText(R.string.choose_payment_type);
		manager = CoreApplication.getInstance().getComponent().manager();
		btnBack.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				onBackPressed();
			}
		});
		adapter = new PaymentTypeAdapter(this, getIntent().getStringExtra(PRICE),new View.OnClickListener() {
			@Override
			public void onClick(View view) {
			}
		});
		recyclerResultList.setAdapter(adapter);
		recyclerResultList.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
		super.onCreate(savedInstanceState);
	}

	@Override
	public void showLoading() { }

	@Override
	public void hideLoading() { }

	@Override
	public void displayError(String message) {
		Toast.makeText(this, R.string.error_msg, Toast.LENGTH_LONG).show();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

/*
	@OnClick(R.id.back)
	public void goBack() {
		router.goBack();
	}
*/
}

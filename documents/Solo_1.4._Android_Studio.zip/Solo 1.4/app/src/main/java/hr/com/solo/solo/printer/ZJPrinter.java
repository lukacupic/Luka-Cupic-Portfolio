package hr.com.solo.solo.printer;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import com.zj.btsdk.BluetoothService;
import com.zj.btsdk.PrintPic;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import hr.com.solo.solo.utils.PrinterUtils;

// 2017-07-23 Haris Kovacevic
// 2020-12-17 Farhad Bhuiyan (QR code)
// 2021-04-27 Matija (File saving fix)
// 2022-11-14 Luka

public class ZJPrinter extends BasePrinter {

    private BluetoothService mService;
    private final Context mContext;
    private final Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            handleLooperMessage(msg);
        }
    };

    public ZJPrinter(Context context, PrinterStatusCallback printerStatusCallback) {
        super(printerStatusCallback);
        mContext = context;
    }

    // INTERFACE METHODS

    @Override
    public void connectPrinter(String address, String name) {
        executeAsync(() -> {
            mService = new BluetoothService(mContext, mHandler);
            BluetoothDevice mPrinter = mService.getDevByMac(address);
            mService.connect(mPrinter);
            setConnected(true);
        });
    }

    @Override
    public void printInvoice(Object invoice, Object qrCode) {
        executeAsync(() -> {
            try {
                String text = (String) invoice;
                byte[] charCmd = new byte[]{0x1b, 0x74, 72};
                mService.write(charCmd);
                mService.sendMessage(text, "Windows-1250");

                if (qrCode != null) {
                    // Text + QR Code
                    String path = mContext.getExternalFilesDir(null).toString();
                    OutputStream fOut = null;
                    File file = new File(path, "temp.png");
                    try {
                        fOut = new FileOutputStream(file);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }

                    PrinterUtils.createBitmapFromQR((String) qrCode).compress(Bitmap.CompressFormat.PNG, 100, fOut);

                    fOut.flush();
                    fOut.close(); // Not really required

                    byte[] sendData;
                    PrintPic pg = new PrintPic();
                    pg.initCanvas(384);
                    pg.initPaint();
                    pg.drawImage(65, -25, file.getAbsolutePath());
                    sendData = pg.printDraw();
                    mService.write(sendData);
                    mService.write("\n".getBytes());
                }
                mService.write("- solo.com.hr mobilna fiskalna -".getBytes());
                mService.write("\n\n\n".getBytes());
                statusCallback.onStatus(PrinterStatusCallback.STATUS.DONE);
            } catch (IOException ex) {
                statusCallback.onStatus(PrinterStatusCallback.STATUS.ERROR);
            }
        });
    }

    @Override
    public void disconnectPrinter() {
        executeAsync(() -> {
            if (mService != null) {
                mService.stop();
            }
            mService = null;
            setConnected(false);
        });
    }

    // END OF INTERFACE METHODS

    // PRIVATE METHODS

    private void handleLooperMessage(Message msg) {
        if (statusCallback == null) {
            return;
        }

        switch (msg.what) {
            case BluetoothService.MESSAGE_STATE_CHANGE:
                switch (msg.arg1) {
                    case BluetoothService.STATE_CONNECTED:
                        statusCallback.onStatus(PrinterStatusCallback.STATUS.CONNECTED);
                        break;
                    case BluetoothService.STATE_CONNECTING:
                        statusCallback.onStatus(PrinterStatusCallback.STATUS.CONNECTING);
                        break;
                    case BluetoothService.STATE_LISTEN:
                    case BluetoothService.STATE_NONE:
                        break;
                }
                break;
            case BluetoothService.MESSAGE_CONNECTION_LOST:
            case BluetoothService.MESSAGE_UNABLE_CONNECT:
                statusCallback.onStatus(PrinterStatusCallback.STATUS.NOT_SUPPORTED);
                break;
        }
    }

    // END OF PRIVATE METHODS
}

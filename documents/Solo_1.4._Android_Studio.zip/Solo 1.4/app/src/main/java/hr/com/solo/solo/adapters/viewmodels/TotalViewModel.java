package hr.com.solo.solo.adapters.viewmodels;

import android.view.View;
import android.widget.TextView;

import com.airbnb.epoxy.EpoxyHolder;
import com.airbnb.epoxy.EpoxyModelWithHolder;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.R;

// 2017-04-26 Ian Rumac

public class TotalViewModel extends EpoxyModelWithHolder<TotalViewModel.TotalViewHolder> {
	String price;

	public TotalViewModel(String price) {
		this.price = price;
	}

	@Override
	protected TotalViewHolder createNewHolder() {
		return new TotalViewHolder();
	}

	@Override
	public void bind(TotalViewHolder holder) {
		holder.price.setText(price);
	}

	@Override
	protected int getDefaultLayout() {
		return R.layout.payment_header;
	}

	static class TotalViewHolder extends EpoxyHolder {

		@BindView(R.id.price)
		TextView price;

		@Override
		protected void bindView(View itemView) {
			ButterKnife.bind(this, itemView);
		}
	}
}

package hr.com.solo.solo.core;

import android.graphics.Bitmap;

import com.annimon.stream.Collectors;
import com.annimon.stream.Stream;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.models.CreateReceiptBody;
import hr.com.solo.solo.models.TaxCategoryContainer;
import hr.com.solo.solo.search.models.network.ItemListResponseWrapper;
import hr.com.solo.solo.utils.MathUtils;
import hr.com.solo.solo.utils.PrefsUtils;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.subjects.PublishSubject;

// 2017-04-22 Ian Rumac

public class UserCatalogManager {

    List<CatalogItem> catalogItems = new LinkedList<>();
    Set<CatalogItem> chosenCatalogItems = new HashSet<>();
    Map<String, TaxCategoryContainer> chosenCatalogItemsByTax = new HashMap<>();
    DecimalFormat format = new DecimalFormat("#0.00");
    CreateReceiptBody lastReceiptBody;
    double totalPrice = 0;
    double normalPrice = 0;
    double priceDiff = 0;
    PublishSubject<String> brutoPrice = PublishSubject.create();
    PublishSubject<String> nettPrice = PublishSubject.create();
    PublishSubject<String> diffPrice = PublishSubject.create();

    public UserCatalogManager() {
        brutoPrice.doOnSubscribe(new Consumer<Disposable>() {
            @Override
            public void accept(Disposable disposable) throws Exception {
                notifyTotalPriceChanged();
            }
        });
        nettPrice.doOnSubscribe(new Consumer<Disposable>() {
            @Override
            public void accept(Disposable disposable) throws Exception {
                notifyTotalPriceChanged();
            }
        });
        diffPrice.doOnSubscribe(disposable -> notifyTotalPriceChanged());
    }

    public static Bitmap receiptBodyBmp;

    public CreateReceiptBody getLastReceiptBody() {
        return lastReceiptBody;
    }

    public void setLastReceiptBody(CreateReceiptBody lastReceiptBody) {
        this.lastReceiptBody = null;
        this.lastReceiptBody = lastReceiptBody;
    }

    public boolean isEmpty() {
        return catalogItems==null || catalogItems.isEmpty();
    }

    public void setupFromCache() {
        catalogItems = PrefsUtils.returnCatalogItems();
    }

    public void setupCatalogItems(ItemListResponseWrapper wrapper) {

        catalogItems.clear();
        if (wrapper.itemList != null && !wrapper.itemList.isEmpty()) {
            catalogItems.addAll(wrapper.itemList);
        }
        PrefsUtils.saveData(wrapper);
    }

    public boolean shouldLoadFromCache() {
        long lastCache = PrefsUtils.returnLastDownload();
        return (lastCache + (8 * 60 * 60 * 1000)) > System.currentTimeMillis();
        //return false;
    }

    public List<CatalogItem> getItemsForQuery(String query) {
        return Stream.of(catalogItems)
                .filter(value -> value.getDescription().toLowerCase().contains(query.toLowerCase()))
                .collect(Collectors.toList());
    }

    public PublishSubject<String> getBrutoPrice() {
        return brutoPrice;
    }

    public List<CatalogItem> getCatalogItems() {
        return catalogItems;
    }

    public void add(CatalogItem item) {
        if (!chosenCatalogItemsByTax.containsKey(item.getTax())) {
            chosenCatalogItemsByTax.put(item.getTax(), new TaxCategoryContainer());
        }
        if (chosenCatalogItems.contains(item)) {
            CatalogItem oldItem = null;
            for (CatalogItem itemFromList : chosenCatalogItems) {
                if (item.equals(itemFromList)) {
                    oldItem = itemFromList;
                    break;
                }
            }

            double oldAmount = Double.valueOf(oldItem.getAmountParsable());
            chosenCatalogItems.remove(oldItem);
            double amount = Double.valueOf(item.getAmountParsable());
            oldAmount += amount;
            chosenCatalogItems.add(new CatalogItem(item.getId(), item.getDescription(), item.getAmountUnit(), String.valueOf(oldAmount).replace(".", ","), item.getDefaultAmount(), item.getPrice(), item.getDiscount(), item.getTax()));
            chosenCatalogItemsByTax.get(item.getTax()).add(new CatalogItem(item.getId(), item.getDescription(), item.getAmountUnit(), String.valueOf(oldAmount), item.getDefaultAmount(), item.getPrice(), item.getDiscount(), item.getTax()));
        } else {
            chosenCatalogItems.add(item);
            chosenCatalogItemsByTax.get(item.getTax()).add(item);
        }
        notifyTotalPriceChanged();
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public Double getNormalPrice() {
        return normalPrice;
    }

    public String getTotalPriceString() {
        return format.format(totalPrice);
    }

    public String getNormalPriceString() {
        return format.format(normalPrice);
    }

    public PublishSubject<String> getNettPrice() {
        return nettPrice;
    }

    public void notifyTotalPriceChanged() {
        normalPrice = 0;
        totalPrice = 0;
        priceDiff = 0;
        for (CatalogItem catalogItem : new ArrayList<>(chosenCatalogItems)) {
            normalPrice += (MathUtils.getPriceForItemSet(catalogItem));
            totalPrice += (MathUtils.getBrutoPriceForItemSet(catalogItem));
        }
        priceDiff += (totalPrice - normalPrice);
        brutoPrice.onNext(format.format(totalPrice).replace(".", ","));
        nettPrice.onNext(format.format(normalPrice).replace(".", ","));
        diffPrice.onNext(format.format(priceDiff).replace(".", ","));
    }

    public String getPriceDiff() {
        return format.format(priceDiff);
    }

    public void remove(CatalogItem item) {
        chosenCatalogItems.remove(item);
        chosenCatalogItemsByTax.get(item.getTax()).remove(item);
        if (chosenCatalogItemsByTax.get(item.getTax()).getChosenCatalogItems().isEmpty()) {
            chosenCatalogItemsByTax.remove(item.getTax());
        }
        notifyTotalPriceChanged();
    }

    public PublishSubject<String> getDiffPrice() {
        return diffPrice;
    }

    public void clearAll() {
        totalPrice = 0;
        normalPrice = 0;
        priceDiff = 0;
        lastReceiptBody = null;
        chosenCatalogItems.clear();
        chosenCatalogItemsByTax.clear();
        notifyTotalPriceChanged();
    }

    public Set<CatalogItem> getChosenCatalogItems() {
        return chosenCatalogItems;
    }

    public Map<String, TaxCategoryContainer> getChosenCatalogItemsByTax() {
        return chosenCatalogItemsByTax;
    }
}

package hr.com.solo.solo.archive.list.repositories;

import java.util.List;

import hr.com.solo.solo.archive.search.network.ReceiptItemListResponseWrapper;
import hr.com.solo.solo.archive.search.network.ReceiptResponseItem;
import io.reactivex.Single;

// 2017-04-10 Ian Rumac

public interface ReceiptArchiveRepository {
	Single<ReceiptItemListResponseWrapper> fetchReceipts(String token);
}

package hr.com.solo.solo.archive.search;

import java.util.List;

import hr.com.solo.solo.archive.search.network.ReceiptResponseItem;
import hr.com.solo.solo.base.BaseView;
import hr.com.solo.solo.base.Presenter;
import io.reactivex.Observable;

// 2017-04-08 Ian Rumac

public interface ReceiptSearchContract {
	interface ReceiptSearchView extends BaseView {

		void displayResults(List<ReceiptResponseItem> results);

		Observable<String> getSearchObservable();

		void displayEmpty();

		void displayError(String message);

		void done();
	}

	interface ReceiptSearchPresenter extends Presenter<ReceiptSearchView> { }
}

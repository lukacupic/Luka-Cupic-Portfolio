package hr.com.solo.solo.search.interactors;

import hr.com.solo.solo.base.UseCase;
import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.search.models.SearchParams;
import hr.com.solo.solo.search.repositories.SearchRepositoryInterface;

import java.util.List;

import javax.inject.Inject;

import io.reactivex.Observable;

// 2017-04-08 Ian Rumac

public class SearchRepositoriesUseCase extends UseCase<List<CatalogItem>, String> {
	private final SearchRepositoryInterface repository;

	@Inject
	public SearchRepositoriesUseCase(SearchRepositoryInterface repository) {
		this.repository = repository;
	}

	@Override
	public Observable<List<CatalogItem>> executeWithParams(String query) {
		return repository.getItemsByQuery(query);
	}
}

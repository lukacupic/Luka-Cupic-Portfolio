package hr.com.solo.solo.main.ui;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION_CODES;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.Callable;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.BuildConfig;
import hr.com.solo.solo.R;
import hr.com.solo.solo.SettingsActivity;
import hr.com.solo.solo.TechSupportActivity;
import hr.com.solo.solo.archive.list.ui.ReceiptArchiveActivity;
import hr.com.solo.solo.base.BaseToolbarActivity;
import hr.com.solo.solo.core.CoreApplication;
import hr.com.solo.solo.core.UserCatalogManager;
import hr.com.solo.solo.edit.main.ui.EditReceptActivity;
import hr.com.solo.solo.login.LoginActivity;
import hr.com.solo.solo.main.NewReceiptContract;
import hr.com.solo.solo.main.di.DaggerNewReceiptComponent;
import hr.com.solo.solo.main.di.NewReceiptModule;
import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.main.ui.adapter.NewReceiptAdapter;
import hr.com.solo.solo.models.ReceiptResponse;
import hr.com.solo.solo.models.VersionResponse;
import hr.com.solo.solo.printer.IPrinter;
import hr.com.solo.solo.search.ui.SearchActivity;
import hr.com.solo.solo.utils.Constants;
import hr.com.solo.solo.utils.ImageLoader;
import hr.com.solo.solo.utils.MathUtils;
import hr.com.solo.solo.utils.PrefsUtils;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class NewReceiptActivity extends BaseToolbarActivity implements NewReceiptContract.NewReceiptView {

    @Inject
    NewReceiptContract.NewReceiptPresenter presenter;
    @Inject
    ImageLoader loader;
    @Inject
    UserCatalogManager manager;

    @BindView(R.id.recycler_result_list)
    RecyclerView recyclerResultList;
    @BindView(R.id.container_layout)
    FrameLayout containerLayout;
    @BindView(R.id.search_button)
    ImageView search;
    @BindView(R.id.ic_menu)
    ImageView menuBtn;
    @BindView(R.id.empty_text)
    TextView empty;

    @BindView(R.id.swipe_refresh)
    SwipeRefreshLayout swipeRefreshLayout;
    @BindView(R.id.card_item)
    CardView headerContainer;
    @BindView(R.id.total)
    TextView total;
    @BindView(R.id.receipt_icon)
    ImageView receiptIcon;
    ScrollView menu;

    @BindView(R.id.progress_bar)
    ProgressBar progressBar;

    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static final String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    NewReceiptAdapter adapter;
    public static IPrinter printer = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        LayoutInflater inflater = LayoutInflater.from(this);
        menu = (ScrollView) inflater.inflate(R.layout.drawer, containerLayout, false);
        DaggerNewReceiptComponent.builder()
                .coreComponent(CoreApplication.getInstance().getComponent())
                .newReceiptModule(new NewReceiptModule()).build().inject(this);
        presenter.attachView(this);
        menuBtn.setOnClickListener(v -> openMenu(containerLayout, menu, R.id.new_receipt, manager));
        search.setOnClickListener(
                view -> startActivity(new Intent(NewReceiptActivity.this, SearchActivity.class)));
        adapter = new NewReceiptAdapter(manager);
        recyclerResultList.setAdapter(adapter);
        swipeRefreshLayout.setOnRefreshListener(() -> {
            PrefsUtils.clearCacheTimestamp();
            presenter.getCatalogItems(PrefsUtils.getToken(), true);
        });
        recyclerResultList.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        if (manager.shouldLoadFromCache()) {
            manager.setupFromCache();
            if (manager.getCatalogItems() != null && !manager.getCatalogItems().isEmpty()) {
                addItems(manager.getCatalogItems());
            } else {
                displayEmpty();
            }
        } else {
            presenter.getCatalogItems(PrefsUtils.getToken(), false);
        }
        verifyStoragePermissions(this);
        getVersion().observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(this::verifyNewVersion, throwable -> {
                });
        super.onCreate(savedInstanceState);
    }

    private void verifyNewVersion(VersionResponse versionResponse) {
        int version = 0;
        try {
            PackageInfo pInfo = this.getPackageManager().getPackageInfo(this.getPackageName(), 0);
            version = pInfo.versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        if (version < Integer.parseInt(versionResponse.getVersion())) {
            Dialog dialog = new Dialog(this);
            dialog.setContentView(R.layout.dialog_error);
            dialog.setCancelable(false);
            TextView textMessage = (TextView) dialog.findViewById(R.id.message);
            textMessage.setText(versionResponse.getMessage());
            TextView btn = (TextView) dialog.findViewById(R.id.btn_close);
            btn.setText(versionResponse.getButton());
            btn.setOnClickListener(view -> {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(versionResponse.getUrl()));
                startActivity(i);
            });
            dialog.show();
        }
    }

    public Single<VersionResponse> getVersion() {
        return Single.fromCallable(() -> {
            OkHttpClient client = new OkHttpClient.Builder()
                    .retryOnConnectionFailure(false)
                    .addInterceptor(chain -> {
                        Response response = chain.proceed(chain.request());
                        MediaType mediaType = MediaType.parse("application/json; charset=utf-8");
                        ResponseBody body = ResponseBody.create(mediaType, response.body().bytes());
                        return response.newBuilder().body(body).build();
                    })
                    .build();
            Request.Builder builder = new Request.Builder();
            builder.url("https://solo.com.hr/app/android.json");
            return client.newCall(builder.build()).execute();
        }).subscribeOn(Schedulers.newThread()).map(response -> new Gson().fromJson(response.body().string(), VersionResponse.class));
    }

    public static void verifyStoragePermissions(Activity activity) {
        // Check if we have write permission
        int permission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
        }
    }

    @Override
    public void showMessageError(String error) {
        showErrorWith(error);
    }

    @Override
    public void showLoading() {
        progressBar.setVisibility(View.VISIBLE);
        empty.setVisibility(View.GONE);
    }

    @Override
    public void hideLoading() {
        progressBar.setVisibility(View.GONE);
    }

    @Override
    public void displayError(String message) {
        Toast.makeText(this, R.string.error_msg, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        presenter.detachView(this);
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.attachView(this);
        headerContainer.setOnClickListener(view -> {
            if (!manager.getChosenCatalogItems().isEmpty()) {
                startActivity(new Intent(NewReceiptActivity.this, EditReceptActivity.class));
            }
        });

        if (manager.getCatalogItems() == null || manager.getCatalogItems().isEmpty()) {
            displayEmpty();
            adapter.displayEmpty();
        } else {
            empty.setVisibility(View.GONE);
            setTotalViewDrawable(manager.getChosenCatalogItems().isEmpty());
            total.setText(MathUtils.roundUp(String.valueOf(manager.getTotalPriceString()), 2).toString()
                    .replace(".", ","));
        }
        adapter.notifyModelsChanged();
    }

    boolean hasViewMoved = false;

    void setTotalViewDrawable(boolean isCartEmpty) {
        if (isCartEmpty) {
            ViewGroup.LayoutParams params = receiptIcon.getLayoutParams();

            if (Build.VERSION.SDK_INT >= VERSION_CODES.LOLLIPOP) {
                receiptIcon.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_empty));

            } else {
                receiptIcon.setImageResource(R.drawable.ic_empty);
            }
            params.height = (int) MathUtils.convertDpToPixel(42f);
            params.width = (int) MathUtils.convertDpToPixel(42f);
            if (hasViewMoved) {
                receiptIcon.setY(receiptIcon.getY() + MathUtils.convertDpToPixel(2));
                hasViewMoved = false;
            }

            receiptIcon.setLayoutParams(params);
        } else {
            ViewGroup.LayoutParams params = receiptIcon.getLayoutParams();
            params.height = (int) MathUtils.convertDpToPixel(50f);
            params.width = (int) MathUtils.convertDpToPixel(52f);
            if (!hasViewMoved) {
                receiptIcon.setY(receiptIcon.getY() - MathUtils.convertDpToPixel(3));
                hasViewMoved = true;
            }
            if (Build.VERSION.SDK_INT >= VERSION_CODES.LOLLIPOP) {
                receiptIcon.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_full));

            } else {
                receiptIcon.setImageResource(R.drawable.ic_full);
            }

            receiptIcon.setLayoutParams(params);
        }
    }

    @Override
    public void addNewItem(CatalogItem item) {
    }

    @Override
    public void addItems(List<CatalogItem> items) {
        swipeRefreshLayout.setRefreshing(false);
        empty.setVisibility(View.GONE);
        adapter.addItems(items, item -> {
            manager.add(item);
            adapter.notifyModelsChanged();
            setTotalViewDrawable(false);
        });

        manager.getBrutoPrice().subscribe(s -> {
            if (manager.getChosenCatalogItems().isEmpty()) {
                setTotalViewDrawable(true);
            } else {
                setTotalViewDrawable(false);
            }
            total.setText(s.replace(".", ","));
        }, Throwable::printStackTrace);
    }

    @Override
    public void displayEmpty() {
        empty.setVisibility(View.VISIBLE);
        total.setText("0,00");
        setTotalViewDrawable(true);
    }

    @Override
    public void removeItem() {
    }

    public void openMenu(FrameLayout containerLayout, ScrollView menu, int id,
                         UserCatalogManager manager) {
        containerLayout.addView(menu);

        View.OnClickListener menuListener = view -> {
            if (id == R.id.new_receipt && view.getId() == R.id.new_receipt) {
                manager.clearAll();
                manager.notifyTotalPriceChanged();
                containerLayout.removeView(menu);
                adapter.notifyModelsChanged();
            } else if (view.getId() != id) {
                switch (view.getId()) {
                    case R.id.close:
                        containerLayout.removeView(menu);
                        break;
                    case R.id.new_receipt:
                        containerLayout.removeView(menu);
                        manager.clearAll();
                        manager.notifyTotalPriceChanged();
                        startActivity(
                                new Intent(NewReceiptActivity.this, NewReceiptActivity.class));
                        break;
                    case R.id.archive:
                        containerLayout.removeView(menu);
                        startActivity(new Intent(NewReceiptActivity.this,
                                ReceiptArchiveActivity.class));
                        break;
                    case R.id.settings:
                        containerLayout.removeView(menu);
                        startActivity(
                                new Intent(NewReceiptActivity.this, SettingsActivity.class));
                        break;
                    case R.id.tech_support:
                        containerLayout.removeView(menu);
                        startActivity(
                                new Intent(NewReceiptActivity.this, TechSupportActivity.class));
                        break;
                    case R.id.logout:
                        Intent intent = new Intent(NewReceiptActivity.this,
                                LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK
                                | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        PrefsUtils.clearToken();
                        finish();
                        break;
                    default:
                        break;
                }
            }
        };

        for (int i = 0; i < ((LinearLayout) menu.getChildAt(0)).getChildCount(); i++) {
            ((LinearLayout) menu.getChildAt(0)).getChildAt(i).setOnClickListener(menuListener);
        }
        menu.findViewById(R.id.close).setOnClickListener(menuListener);
    }
}

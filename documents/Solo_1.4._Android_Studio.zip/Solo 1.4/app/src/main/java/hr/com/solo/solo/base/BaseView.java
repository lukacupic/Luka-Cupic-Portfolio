package hr.com.solo.solo.base;

// 2017-04-08 Ian Rumac

public interface BaseView {
	void showLoading();
	void hideLoading();
	void displayError(String message);
}

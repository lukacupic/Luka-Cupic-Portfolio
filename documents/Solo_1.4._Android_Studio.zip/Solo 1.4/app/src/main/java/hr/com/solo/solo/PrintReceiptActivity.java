package hr.com.solo.solo;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;

import androidx.annotation.Nullable;

import android.text.Html;
import android.text.Spanned;
import android.view.View;

import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.gson.Gson;

import java.net.UnknownHostException;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.base.BaseToolbarActivity;
import hr.com.solo.solo.core.CoreApplication;
import hr.com.solo.solo.core.UserCatalogManager;
import hr.com.solo.solo.main.ui.NewReceiptActivity;
import hr.com.solo.solo.models.ReceiptResponse;
import hr.com.solo.solo.networking.SoloService;
import hr.com.solo.solo.printer.PrinterFactory;
import hr.com.solo.solo.printer.PrinterStatusCallback;
import hr.com.solo.solo.utils.Constants;
import hr.com.solo.solo.utils.PrefsUtils;
import hr.com.solo.solo.utils.ScreenshotUtil;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

import static hr.com.solo.solo.R.id.webview;

// 2017-04-25 Ian Rumac
// 2020-12-17 Farhad Bhuiyan (QR code)
// 2022-11-27 Luka

public class PrintReceiptActivity extends BaseToolbarActivity implements PrinterStatusCallback {

    @BindView(R.id.container_layout)
    RelativeLayout containerLayout;
    @BindView(R.id.ic_back)
    ImageView backBn;
    @BindView(webview)
    WebView webView;

    SoloService service;
    UserCatalogManager manager;
    @BindView(R.id.racun_title)
    TextView racunTitle;
    @BindView(R.id.print_btn)
    ImageView printBtn;
    @BindView(R.id.toolbar)
    FrameLayout toolbar;
    @BindView(R.id.viewspace)
    View viewspace;
    @BindView(R.id.stoniraj_btn)
    TextView stornirajBtn;

    public static final String ID = "id";

    private Bitmap mBitmap;
    private String webViewUrl = "";
    private String textToPrint = "";
    private String qrCodeToPrint = null;
    private boolean isPrinting;
    private Single<ResponseBody> printableReceiptObservable;

    public static void startWithID(String id, Context context) {
        Intent intent = new Intent(context, PrintReceiptActivity.class);
        intent.putExtra(ID, id);
        context.startActivity(intent);
    }

    public static void createNewReceipt(Context context) {
        Intent intent = new Intent(context, PrintReceiptActivity.class);
        context.startActivity(intent);
    }

    boolean isArchive = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt_print);
        ButterKnife.bind(this);

        showLoading();
        webView.setWebViewClient(new SoloWebClient());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.setInitialScale(100);

        service = CoreApplication.getInstance().getComponent().service();
        manager = CoreApplication.getInstance().getComponent().manager();

        String id = getIntent().getStringExtra(ID);
        if (id != null && !id.isEmpty()) {
            isArchive = true;
        } else {
            stornirajBtn.setVisibility(View.GONE);
        }

        getReceipt(id).observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(this::showReceipt, throwable -> {
                    try {
                        showNetworkError(throwable);
                    } catch (Exception e) {
                    }
                });

        printBtn.setOnClickListener(view -> {
            createWebPrintJob();
        });
        backBn.setOnClickListener(v -> onBackPressed());
        stornirajBtn.setOnClickListener(view -> {
            stornirajBtn.setEnabled(false);
            HashMap<String, String> map = new HashMap<>();
            map.put("pos", "1");
            map.put("token", PrefsUtils.getToken());
            map.put("id", id);
            service.stopReceipt(map)
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribeOn(Schedulers.newThread()).subscribe(receiptResponse -> {
                stornirajBtn.setEnabled(true);
                showErrorWith(receiptResponse.getMessage());
            }, throwable -> {
                stornirajBtn.setEnabled(true);
                try {
                    throwable.printStackTrace();
                } catch (Exception e) {
                }
            });
        });
    }

    public Single<ReceiptResponse> getReceipt(String id) {
        if (id == null || id.isEmpty()) {
            return Single.fromCallable(() -> {
                OkHttpClient client = new OkHttpClient.Builder()
                        .retryOnConnectionFailure(false)
                        .addInterceptor(chain -> {
                            Response response = chain.proceed(chain.request());
                            MediaType mediaType = MediaType.parse("application/json; charset=utf-8");
                            ResponseBody body = ResponseBody.create(mediaType, response.body().bytes());
                            return response.newBuilder().body(body).build();
                        })
                        .build();
                Request.Builder builder = new Request.Builder()
                        .post(manager.getLastReceiptBody().getRequestBody());
                builder.url(BuildConfig.BASE_URL.concat(Constants.Endpoints.RACUN));
                return client.newCall(builder.build()).execute();
            }).subscribeOn(Schedulers.newThread()).map(response -> new Gson().fromJson(response.body().string(), ReceiptResponse.class));
        } else {
            return service.getSingleReceipt(1, PrefsUtils.getToken(), id);
        }
    }

    private void showNetworkError(Throwable throwable) {
        throwable.printStackTrace();
        if (throwable instanceof UnknownHostException) {
            showErrorWith(getString(R.string.api_ded));
        } else {
            showErrorWith(getString(R.string.conn_error));
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (NewReceiptActivity.printer != null) {
                NewReceiptActivity.printer.setPrinterStatusCallback(null);
            }
        } catch (Exception e) {
        }
        if (mBitmap != null) {
            mBitmap.recycle();
            mBitmap = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (isArchive) {
            super.onBackPressed();
        } else {
            clearManagerData();
        }
    }

    private void clearManagerData() {
        manager.clearAll();
        manager.setLastReceiptBody(null);
        Intent intent = new Intent(this, NewReceiptActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    private void createWebPrintJob() {
        if (PrefsUtils.getPrinterName().isEmpty() && PrefsUtils.getPrinterMac().isEmpty()) {
            showErrorWith(getString(R.string.choose_printer_first));
        } else {
            printableReceiptObservable.subscribeOn(Schedulers.newThread())
                    .observeOn(AndroidSchedulers.mainThread()).subscribe(
                    ignore -> {
                        startPrintProcess();
                        printBtn.setClickable(false);

                    }, throwable -> {
                        try {
                            showNetworkError(throwable);
                        } catch (Exception e) {
                        }
                    });
        }
    }

    public void showCustomError(String message) {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_error);
        TextView textMessage = dialog.findViewById(R.id.message);
        textMessage.setText(message);
        TextView btn = dialog.findViewById(R.id.btn_close);
        btn.setOnClickListener(view -> {
            dialog.dismiss();
            hideLoading();
            onBackPressed();
        });
        dialog.show();
    }

    private void showReceipt(ReceiptResponse receipt) {
        if (receipt.getStatus() != 0) {
            showCustomError(receipt.getMessage());
        } else {
            // Set header title (Invoice Number)
            racunTitle.setText(receipt.getRacun().getBroj_racuna());
            // Load WebView using hash and token
            webViewUrl = "https://solo.com.hr/pos/" + receipt.getRacun().getId() + "?token=" + PrefsUtils.getToken();
            //webViewUrl = receipt.getRacun().getPdf().replace("/download", "/pos");
            webView.loadUrl(webViewUrl);
        }
        // Load printable version
        String textUrl = webViewUrl.replace("/pos", "/txt");
        printableReceiptObservable = service.downloadFileWithDynamicUrl(textUrl);
        printableReceiptObservable.subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(responsebody -> {
                    textToPrint = responsebody.string();
                }, throwable -> {
                    try {
                        showNetworkError(throwable);
                    } catch (Exception e) {
                    }
                });
        if (receipt.getRacun() != null) qrCodeToPrint = receipt.getRacun().getQr();
    }

    ProgressDialog dialog;

    @Override
    public void showLoading() {
        showLoadingWithMessage(getString(R.string.loading_invoice));
    }

    @Override
    public void hideLoading() {
        try {
            if (dialog != null && dialog.isShowing() && !isDestroyed()) {
                dialog.dismiss();
            }
        } catch (Exception e) {
        }
    }

    @Override
    public void displayError(String message) {
    }

    @Override
    public void onStatus(STATUS status) {
        runOnUiThread(() -> {
            showLoadingWithMessage(status.getMessage());
            switch (status) {
                case NOT_SUPPORTED:
                    finishWithMessage(status.getMessage());
                    PrefsUtils.savePrinter(null, null, 0, null);
                    printBtn.setClickable(true);
                    break;
                case CONNECTED: {
                    try {
                        new Handler().postDelayed(this::print, 2000);
                    } catch (Exception e) {
                    }
                    break;
                }
                case CONNECTING:
                    break;
                case DONE:
                    finishWithMessage(getString(R.string.printing));
                    isPrinting = false;
                    printBtn.setClickable(true);
                    break;
            }
        });
    }

    @Override
    public void onMessage(String message) {
    }

    private void showLoadingWithMessage(String message) {
        try {
            if (dialog == null)
                dialog = new ProgressDialog(this);
            Spanned styledMessage;
            String htmlStyling = "<font color='white'><big>" + (message != null ? message : "") + "</big></font>";
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                styledMessage = Html.fromHtml(htmlStyling, Html.FROM_HTML_MODE_LEGACY);
            } else {
                styledMessage = Html.fromHtml(htmlStyling);
            }
            dialog.setMessage(styledMessage);
            dialog.setCancelable(false);
            dialog.setCanceledOnTouchOutside(false);
            if (!dialog.isShowing()) {
                dialog.show();
            }
        } catch (Exception e) {
        }
    }

    private void startPrintProcess() {
        try {
            BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            if (bluetoothAdapter == null) {

            } else if (!bluetoothAdapter.isEnabled()) {
                showCustomError(getString(R.string.bt_disabled));
            } else {
                showLoadingWithMessage(getString(R.string.loading_invoice));
                if (NewReceiptActivity.printer == null || !NewReceiptActivity.printer.isConnected()) {
                    connectPrinter(PrefsUtils.getPrinterName(), PrefsUtils.getPrinterMac(), PrefsUtils.getPrinterRetailer());
                } else {
                    print();
                }
            }
        } catch (Exception e) {
        }
    }

    private void connectPrinter(String printerName, String macAddress, String printerRetailer) {
        NewReceiptActivity.printer = PrinterFactory.getPrinter(printerRetailer, this, this);
        if (NewReceiptActivity.printer != null) {
            NewReceiptActivity.printer.connectPrinter(macAddress, printerName);
        }
    }

    private void print() {
        isPrinting = true;
        showLoadingWithMessage(getString(R.string.printing));
        NewReceiptActivity.printer.setPrinterStatusCallback(this);
        NewReceiptActivity.printer.printInvoice(textToPrint, qrCodeToPrint);

        // set printer timeout to 5 seconds to avoid infinite loop upon accidental disconnect
        new Thread(() -> {
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ex) {
            }

            if (isPrinting) {
                this.onStatus(STATUS.NOT_SUPPORTED);
            }
        }).start();
    }

    private void finishWithMessage(String message) {
        try {
            showLoadingWithMessage(message);
            new Handler().postDelayed(this::hideLoading, 2000);
        } catch (Exception e) {
        }
    }

    class SoloWebClient extends WebViewClient {
        @Override
        public void onPageFinished(WebView view, String url) {
            new Handler().postDelayed(() -> {
                mBitmap = ScreenshotUtil.screenshot(webView);
                hideLoading();
            }, 500);
        }
    }
}

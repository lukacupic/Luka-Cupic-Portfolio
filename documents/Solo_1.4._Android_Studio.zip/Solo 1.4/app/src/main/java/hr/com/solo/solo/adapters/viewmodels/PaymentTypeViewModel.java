package hr.com.solo.solo.adapters.viewmodels;

import android.content.Context;
import android.os.SystemClock;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.airbnb.epoxy.EpoxyHolder;
import com.airbnb.epoxy.EpoxyModelWithHolder;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.PrintReceiptActivity;
import hr.com.solo.solo.R;
import hr.com.solo.solo.core.CoreApplication;

// 2017-04-26 Ian Rumac

public class PaymentTypeViewModel extends EpoxyModelWithHolder<PaymentTypeViewModel.TotalViewHolder> {
    private long lastClickTime=0;
	Context context;
	String type;
	int typeNum;
	View.OnClickListener clickListener;
	public PaymentTypeViewModel(Context context, String type, int typeNum, View.OnClickListener clickListener) {
		this.context = context;
		this.type = type;
		this.typeNum = typeNum;
		this.clickListener = clickListener;
	}

	@Override
	protected TotalViewHolder createNewHolder() {
		return new TotalViewHolder();
	}

	@Override
	public void bind(TotalViewHolder holder) {

		holder.type.setText(type);
		holder.type.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if(SystemClock.elapsedRealtime()-lastClickTime<2000){
				    return;
                }
                lastClickTime=SystemClock.elapsedRealtime();
				if(CoreApplication.getInstance().getComponent().manager() != null &&
						CoreApplication.getInstance().getComponent().manager().getLastReceiptBody() != null) {
					CoreApplication.getInstance().getComponent().manager().getLastReceiptBody().finish(typeNum);
				}
				PrintReceiptActivity.createNewReceipt(view.getContext());
			}
		});

	}

	@Override
	protected int getDefaultLayout() {
		return R.layout.payment_type_viewmodel;
	}

	static class TotalViewHolder extends EpoxyHolder {

		@BindView(R.id.payment_type)
		TextView type;

		@Override
		protected void bindView(View itemView) {
			ButterKnife.bind(this, itemView);
		}
	}
}

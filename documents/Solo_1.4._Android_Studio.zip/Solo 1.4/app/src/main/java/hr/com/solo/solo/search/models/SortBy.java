package hr.com.solo.solo.search.models;

// 2017-04-08 Ian Rumac

public enum SortBy {
	STARS("stars"),
	FORKS("forks"),
	UPDATED("updated");

	private final String value;

	SortBy(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}
}

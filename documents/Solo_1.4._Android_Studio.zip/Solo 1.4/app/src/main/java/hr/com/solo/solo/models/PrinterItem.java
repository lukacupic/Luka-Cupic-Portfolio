package hr.com.solo.solo.models;

// 2017-06-13 Ian Rumac
// 2022-11-18 Luka

public class PrinterItem {
    public static final int BT = 0;
    private String name;
    private String macAddress;
    private final int type;
    private boolean isActive;

    public PrinterItem(String name, String mac, int type) {
        this.name = name;
        this.macAddress = mac;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMacAddress() {
        return macAddress;
    }

    public void setMacAddress(String macAddress) {
        this.macAddress = macAddress;
    }

    public int getType() {
        return type;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }
}

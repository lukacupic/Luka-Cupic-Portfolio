package hr.com.solo.solo.archive.search.di;

import javax.inject.Named;

import dagger.Component;
import hr.com.solo.solo.archive.search.ui.ReceiptSearchActivity;
import hr.com.solo.solo.core.UserReceiptManager;
import hr.com.solo.solo.core.di.CoreComponent;
import hr.com.solo.solo.core.di.PerActivity;
import hr.com.solo.solo.navigation.Router;
import hr.com.solo.solo.networking.SoloService;
import hr.com.solo.solo.utils.ImageLoader;
import io.reactivex.Scheduler;

// 2017-04-08 Ian Rumac

@PerActivity
@Component(dependencies = CoreComponent.class, modules = ReceiptSearchModule.class)
public interface ReceiptSearchComponent {
	void inject(ReceiptSearchActivity mainActivity);

	Router provideRouter();

	SoloService service();

	ImageLoader imageLoader();

	UserReceiptManager manager();

	@Named("io")
	Scheduler schedulerIO();

	@Named("post_execution")
	Scheduler schedulerPostExecution();
}

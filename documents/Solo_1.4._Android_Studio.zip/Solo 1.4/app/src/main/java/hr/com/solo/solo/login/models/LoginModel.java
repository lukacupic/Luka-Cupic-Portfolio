package hr.com.solo.solo.login.models;

// 2017-05-01 Ian Rumac

public class LoginModel {
	/**
	 * status : 0
	 * token : k2f85a47b75f20h21da9zg1337co5a1g
	 * message : Prikazan je API token za korisnika _solo_.
	 */

	private int status;
	private String token;
	private String message;

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}

package hr.com.solo.solo.search.ui.adapters;

import com.airbnb.epoxy.EpoxyAdapter;
import com.airbnb.epoxy.EpoxyModel;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;

import hr.com.solo.solo.core.UserCatalogManager;
import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.navigation.Router;
import hr.com.solo.solo.search.ui.viewmodels.CatalogItemViewModel;
import hr.com.solo.solo.utils.ImageLoader;
import hr.com.solo.solo.utils.OnItemSelected;

// 2017-04-08 Ian Rumac

public class SearchResultsEpoxyAdapter extends EpoxyAdapter implements SearchResultsAdapter {
	Router router;
	ImageLoader loader;
	UserCatalogManager manager;

	@Inject
	public SearchResultsEpoxyAdapter(Router router, ImageLoader loader, UserCatalogManager manager) {
		this.router = router;
		this.loader = loader;
		this.manager = manager;
		enableDiffing();
	}

	@Override
	public void clearAndAddNewModels(List<CatalogItem> githubRepositories, String query, OnItemSelected<CatalogItem> itemOnItemSelected) {
		final int modelsSize = models.size();
		models.clear();
		addModels(githubRepositories, query, itemOnItemSelected);
	}

	@Override
	public void addModels(List<CatalogItem> githubRepositories, String query, OnItemSelected<CatalogItem> itemSelected) {
		for (int i = 0; i < githubRepositories.size(); i++) {
			CatalogItem result = githubRepositories.get(i);

			models.add(new CatalogItemViewModel(result, query, itemSelected,manager));
		}
		notifyModelsChanged();
	}

	@Override
	public void updateModels(List<CatalogItem> catalogItems, String query, OnItemSelected<CatalogItem> itemSelected) {
		Set<String> existingItems = new HashSet<>();
		for (int i = 0; i < models.size(); i++) {
			EpoxyModel model = models.get(i);
			if (model instanceof CatalogItemViewModel) {
				CatalogItem currentViewModel = ((CatalogItemViewModel) model).getResult();
				if(!catalogItems.contains(currentViewModel)){
					models.remove(i);
					notifyItemRemoved(i);
					i--;
				}else{
					((CatalogItemViewModel) model).setQuery(query.toLowerCase());
					existingItems.add(currentViewModel.getDescription());
					notifyModelChanged(model);
				}
			}
		}

		for(CatalogItem catalogItem: catalogItems){
			if(!existingItems.contains(catalogItem.getDescription())){
				addModel(new CatalogItemViewModel(catalogItem, query, itemSelected,manager));
			}
		}

		notifyModelsChanged();
	}
}

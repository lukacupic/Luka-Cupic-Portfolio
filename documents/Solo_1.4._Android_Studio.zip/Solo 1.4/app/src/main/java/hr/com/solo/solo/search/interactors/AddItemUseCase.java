package hr.com.solo.solo.search.interactors;

import java.util.List;

import javax.inject.Inject;

import hr.com.solo.solo.base.UseCase;
import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.search.repositories.SearchRepositoryInterface;
import io.reactivex.Observable;

// 2017-04-08 Ian Rumac

public class AddItemUseCase extends UseCase<Boolean, CatalogItem> {
	private final SearchRepositoryInterface repository;

	@Inject
	public AddItemUseCase(SearchRepositoryInterface repository) {
		this.repository = repository;
	}

	@Override
	public Observable<Boolean> executeWithParams(CatalogItem query) {
		repository.addItem(query);
		return Observable.just(true);
	}
}

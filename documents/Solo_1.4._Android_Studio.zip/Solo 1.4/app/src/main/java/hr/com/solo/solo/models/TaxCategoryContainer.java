package hr.com.solo.solo.models;

import com.annimon.stream.Collectors;
import com.annimon.stream.Stream;

import java.text.DecimalFormat;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.utils.MathUtils;
import hr.com.solo.solo.utils.PrefsUtils;
import io.reactivex.subjects.PublishSubject;

// 2017-05-30 Ian Rumac

public class TaxCategoryContainer {
	static DecimalFormat format = new DecimalFormat("#0.00");

	Set<CatalogItem> chosenCatalogItems = new HashSet<>();
	double totalPrice = 0;
	double normalPrice = 0;
	double priceDiff = 0;
	PublishSubject<String> brutoPrice = PublishSubject.create();
	PublishSubject<String> nettPrice = PublishSubject.create();
	PublishSubject<String> diffPrice = PublishSubject.create();

	public void add(CatalogItem item) {
		if (chosenCatalogItems.contains(item)) {
			CatalogItem oldItem = null;
			for (CatalogItem itemFromList : chosenCatalogItems) {
				if (item.equals(itemFromList)) {
					oldItem = itemFromList;
					break;
				}
			}

			chosenCatalogItems.remove(oldItem);
			chosenCatalogItems.add(item);

		} else {
			chosenCatalogItems.add(item);
		}
		notifyTotalPriceChanged();
	}
	public Double getTotalPrice() {
		return totalPrice;
	}

	public Double getNormalPrice() {
		return normalPrice;
	}

	public String getTotalPriceString() {
		return format.format(totalPrice);
	}

	public String getNormalPriceString() {
		return format.format(normalPrice);
	}

	public PublishSubject<String> getNettPrice() {
		return nettPrice;
	}

	public boolean shouldLoadFromCache() {
		long lastCache = PrefsUtils.returnLastDownload();
		return (lastCache + (8 * 60 * 60 * 1000)) > System.currentTimeMillis();
		//return false;
	}

	public PublishSubject<String> getBrutoPrice() {
		return brutoPrice;
	}

	public void notifyTotalPriceChanged() {
		normalPrice = 0;
		totalPrice = 0;
		priceDiff = 0;
		for (CatalogItem catalogItem : chosenCatalogItems) {
			normalPrice += (MathUtils.getPriceForItemSet(catalogItem));
			totalPrice += (MathUtils.getBrutoPriceForItemSet(catalogItem));
		}
		priceDiff += (totalPrice - normalPrice);
		brutoPrice.onNext(format.format(totalPrice).replace(".", ","));
		nettPrice.onNext(format.format(normalPrice).replace(".", ","));
		diffPrice.onNext(format.format(priceDiff).replace(".", ","));
	}

	public String getPriceDiff() {
		return format.format(priceDiff);
	}

	public void remove(CatalogItem item) {
		chosenCatalogItems.remove(item);
		notifyTotalPriceChanged();
	}

	public PublishSubject<String> getDiffPrice() {
		return diffPrice;
	}

	public void clearAll() {
		totalPrice = 0;
		normalPrice = 0;
		priceDiff = 0;
		chosenCatalogItems.clear();

		notifyTotalPriceChanged();

		chosenCatalogItems.clear();
	}

	public Set<CatalogItem> getChosenCatalogItems() {
		return chosenCatalogItems;
	}
}

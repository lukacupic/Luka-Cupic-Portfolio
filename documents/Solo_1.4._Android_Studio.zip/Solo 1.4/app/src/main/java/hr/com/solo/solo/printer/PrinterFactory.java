package hr.com.solo.solo.printer;

import android.content.Context;

// 2017-07-16 Haris Kovacevic
// 2020-12-17 Farhad Bhuiyan
// 2022-09-27 Matija

public class PrinterFactory {

    public static final String RETAILER_BIXOLON = "BIXOLON";
    public static final String RETAILER_DATECS = "DATECS";
    public static final String RETAILER_STAR = "STAR";
    public static final String RETAILER_ZJ = "ZJ";
    public static final String RETAILER_XMJ = "XMJ"; // Goojprt
    public static final String RETAILER_RONGTA = "RT";

    public static IPrinter getPrinter(String retailer, Context context, PrinterStatusCallback callback) {
        switch (retailer) {
            case RETAILER_BIXOLON:
                return new BixolonPrinter(context, callback);

            case RETAILER_DATECS:
                return new DatecsPrinter(callback);

            case RETAILER_STAR:
                return new StarPrinter(callback);

            case RETAILER_ZJ:
                return new ZJPrinter(context, callback);

            case RETAILER_XMJ:
                return new XMJPrinter(context, callback);

            case RETAILER_RONGTA:
                return new RongtaPrinter(callback);

            default:
                return null;
        }
    }
}

package hr.com.solo.solo.networking;

import hr.com.solo.solo.BuildConfig;
import hr.com.solo.solo.core.CoreApplication;

import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import hr.com.solo.solo.utils.RxErrorHandlingCallAdapterFactory;
import okhttp3.Cache;
import okhttp3.FormBody;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

// 2017-04-08 Ian Rumac

@Module
public class NetworkModule {
	private static final String RESPONSE_DIR_NAME = "responses";
	private static final int CACHE_SIZE = 10 * 1024 * 1024;
	private static final String TOKEN_VALUE = "token ";
	private static final String AUTH = "Authorization";

	@Provides
	@Singleton
	public OkHttpClient provideHttpClient() {
		HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
		loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
		File httpCacheDirectory = new File(CoreApplication.getInstance().getCacheDir(), RESPONSE_DIR_NAME);
		Cache cache = new Cache(httpCacheDirectory, CACHE_SIZE);
		return new OkHttpClient.Builder()
				.addInterceptor(loggingInterceptor)
				.connectTimeout(20 * 1000, TimeUnit.MILLISECONDS)
				.readTimeout(30 * 1000, TimeUnit.MILLISECONDS)
				.retryOnConnectionFailure(false)
				.cache(cache)
				.build();
	}

	@Provides
	@Singleton
	public Retrofit provideRestAdapter(OkHttpClient httpClient) {
		return new Retrofit.Builder()
				.addCallAdapterFactory(RxJava2CallAdapterFactory.create())
				.addConverterFactory(GsonConverterFactory.create())
				.addCallAdapterFactory(RxErrorHandlingCallAdapterFactory.create())
				.client(httpClient)
				.baseUrl(BuildConfig.BASE_URL)
				.build();
	}

	@Provides
	@Singleton
	public SoloService provideRetrofitService(Retrofit retrofit) {
		return retrofit.create(SoloService.class);
	}
}

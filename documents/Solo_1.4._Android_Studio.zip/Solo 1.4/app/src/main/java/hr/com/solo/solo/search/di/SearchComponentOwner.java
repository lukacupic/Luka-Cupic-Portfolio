package hr.com.solo.solo.search.di;

// 2017-04-10 Ian Rumac

public interface SearchComponentOwner {
	SearchComponent searchComponent();
}

package hr.com.solo.solo.main.di;

import hr.com.solo.solo.core.UserCatalogManager;
import hr.com.solo.solo.core.di.PerFragment;
import hr.com.solo.solo.main.NewReceiptPresenterImpl;
import hr.com.solo.solo.main.interactors.NewReceiptUseCase;
import hr.com.solo.solo.main.mappers.NewReceiptResponseMapper;
import hr.com.solo.solo.main.repositories.CatalogDetailsRepository;
import hr.com.solo.solo.main.source.NewReceiptNetworkSource;
import hr.com.solo.solo.main.source.NewReceiptNetworkSourceImpl;
import hr.com.solo.solo.networking.SoloService;
import hr.com.solo.solo.main.NewReceiptContract;
import hr.com.solo.solo.main.repositories.GithubRepositoryDetailsRepository;

import javax.inject.Named;

import dagger.Module;
import dagger.Provides;
import io.reactivex.Scheduler;

// 2017-04-08 Ian Rumac

@Module
public class NewReceiptModule {
	@Provides
	@PerFragment
	NewReceiptResponseMapper provideResultMapper() {
		return new NewReceiptResponseMapper();
	}

	@Provides
	@PerFragment
	NewReceiptNetworkSource provideSource(SoloService service, NewReceiptResponseMapper mapper) {
		return new NewReceiptNetworkSourceImpl(service, mapper);
	}

	@Provides
	@PerFragment
	CatalogDetailsRepository provideRepositoryDetailsRepository(NewReceiptNetworkSource source, @Named("io") Scheduler io) {
		return new GithubRepositoryDetailsRepository(source, io);
	}

	@Provides
	@PerFragment
	NewReceiptUseCase provideGetRepositoryDetailsUseCase(CatalogDetailsRepository repository) {
		return new NewReceiptUseCase(repository);
	}

	@Provides
	@PerFragment
	NewReceiptContract.NewReceiptPresenter providePresenter(NewReceiptUseCase repositoriesUseCase, UserCatalogManager manager) {
		return new NewReceiptPresenterImpl(repositoriesUseCase,manager);
	}
}

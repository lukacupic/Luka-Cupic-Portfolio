package hr.com.solo.solo.printer;

// 2017-07-16 Haris Kovacevic
// 2022-11-15 Luka

public interface PrinterStatusCallback {

    enum STATUS {
        NOT_SUPPORTED("Uređaj nije podržan ili dostupan"),
        CONNECTING("Uspostava veze"),
        CONNECTED("Printer uspješno povezan"),
        DONE("Račun se printa"),
        ERROR("Greška prilikom printanja");

        private final String message;

        STATUS(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }
    }

    void onStatus(STATUS status);

    void onMessage(String message);
}

package hr.com.solo.solo.edit.main.interactors;

import java.util.List;

import javax.inject.Inject;

import hr.com.solo.solo.base.UseCase;
import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.edit.main.repositories.EditReceiptRepository;
import io.reactivex.Observable;

// 2017-04-09 Ian Rumac

public class EditReceiptUseCase extends UseCase<List<CatalogItem>, Boolean> {
	private final EditReceiptRepository repository;

	@Inject
	public EditReceiptUseCase(EditReceiptRepository repository) {
		this.repository = repository;
	}

	@Override
	public Observable<List<CatalogItem>> executeWithParams(Boolean word) {
		return repository.fetchChosenItems().toObservable();
	}
}

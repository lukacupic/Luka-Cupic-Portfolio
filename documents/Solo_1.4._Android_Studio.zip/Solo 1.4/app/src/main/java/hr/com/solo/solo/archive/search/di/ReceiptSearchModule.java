package hr.com.solo.solo.archive.search.di;

import android.app.Activity;
import androidx.fragment.app.FragmentManager;

import javax.inject.Named;

import dagger.Module;
import dagger.Provides;
import hr.com.solo.solo.archive.search.ReceiptSearchContract;
import hr.com.solo.solo.archive.search.ReceiptSearchPresenter;
import hr.com.solo.solo.archive.search.interactors.SearchReceiptsUseCase;
import hr.com.solo.solo.archive.search.repositories.ReceiptSearchRepository;
import hr.com.solo.solo.archive.search.repositories.ReceiptSearchRepositoryInterface;
import hr.com.solo.solo.archive.search.source.SearchNetworkSource;
import hr.com.solo.solo.archive.search.source.SearchSource;
import hr.com.solo.solo.archive.search.ui.adapters.ReceiptSearchResultsAdapter;
import hr.com.solo.solo.archive.search.ui.adapters.ReceiptSearchResultsEpoxyAdapter;
import hr.com.solo.solo.core.UserReceiptManager;
import hr.com.solo.solo.core.di.PerActivity;
import hr.com.solo.solo.navigation.Router;
import hr.com.solo.solo.navigation.RouterImpl;
import hr.com.solo.solo.networking.SoloService;
import hr.com.solo.solo.utils.ImageLoader;
import io.reactivex.Scheduler;

// 2017-04-08 Ian Rumac

@Module
public class ReceiptSearchModule {
	private final Activity activity;
	private final FragmentManager supportManger;

	public ReceiptSearchModule(Activity activity, FragmentManager manager) {
		this.activity = activity;
		this.supportManger = manager;
	}

	@Provides
	@PerActivity
	SearchSource provideSource(SoloService service) {
		return new SearchNetworkSource(service);
	}

	@Provides
	@PerActivity
	ReceiptSearchRepositoryInterface provideRepository(UserReceiptManager source, @Named("io") Scheduler io) {
		return new ReceiptSearchRepository(source, io);
	}

	@Provides
	@PerActivity
	SearchReceiptsUseCase provideSearchRepositoryUseCase(ReceiptSearchRepositoryInterface repository) {
		return new SearchReceiptsUseCase(repository);
	}

	@Provides
	@PerActivity
	ReceiptSearchContract.ReceiptSearchPresenter providePresenter(SearchReceiptsUseCase repositoriesUseCase, @Named("post_execution") Scheduler postExecution) {
		return new ReceiptSearchPresenter(repositoriesUseCase, postExecution);
	}

	@Provides
	@PerActivity
	Router provideRouter() {
		return new RouterImpl(activity, supportManger);
	}

	@Provides
	@PerActivity
	ReceiptSearchResultsAdapter provideAdapter(Router router, ImageLoader loader) {
		return new ReceiptSearchResultsEpoxyAdapter(router, loader);
	}
}

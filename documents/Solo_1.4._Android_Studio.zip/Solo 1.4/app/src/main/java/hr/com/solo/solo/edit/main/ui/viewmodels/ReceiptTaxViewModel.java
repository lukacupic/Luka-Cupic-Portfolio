package hr.com.solo.solo.edit.main.ui.viewmodels;

import java.text.DecimalFormat;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.airbnb.epoxy.EpoxyHolder;
import com.airbnb.epoxy.EpoxyModelWithHolder;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.R;
import hr.com.solo.solo.models.TaxCategoryContainer;
import hr.com.solo.solo.utils.OnItemSelected;
import hr.com.solo.solo.utils.PrefsUtils;
import io.reactivex.functions.Consumer;
import io.reactivex.subjects.PublishSubject;

// 2017-04-21 Ian Rumac

public class ReceiptTaxViewModel extends EpoxyModelWithHolder<ReceiptTaxViewModel.ReceiptHeaderHolder> {
	TaxCategoryContainer container;
	PublishSubject<String> price,afterTax;
	String nett, total, tax;
	OnItemSelected<Boolean> onItemSelected;

	public
	ReceiptTaxViewModel(String tax,TaxCategoryContainer container, OnItemSelected<Boolean> onItemSelected) {
		this.nett = container.getNormalPriceString();
		this.tax = tax;
		this.total = container.getPriceDiff();
		this.price = container.getNettPrice();
		this.afterTax = container.getDiffPrice();
		this.onItemSelected = onItemSelected;
		this.container = container;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		if (!super.equals(o)) {
			return false;
		}

		ReceiptTaxViewModel that = (ReceiptTaxViewModel) o;

		if (container != null ? !container.equals(that.container) : that.container != null) {
			return false;
		}
		return tax != null ? tax.equals(that.tax) : that.tax == null;
	}

	@Override
	public int hashCode() {
		int result = super.hashCode();
		result = 31 * result + (container != null ? container.hashCode() : 0);
		result = 31 * result + (tax != null ? tax.hashCode() : 0);
		return result;
	}

	@Override
	protected ReceiptHeaderHolder createNewHolder() {
		return new ReceiptHeaderHolder();
	}

	@Override
	public void bind(ReceiptHeaderHolder holder) {

		holder.baseAmount.setText("Osnovica ".concat(tax).concat("%"));
		holder.taxAmount.setText("Porez ".concat(tax).concat("%"));
		holder.basePrice.setText(container.getNormalPriceString().replace(".",","));
		holder.taxPrice.setText(container.getPriceDiff().replace(".",","));
		price.subscribe(s -> holder.basePrice.setText(s.replace(".",",")), Throwable::printStackTrace);
		afterTax.subscribe(s -> holder.taxPrice.setText(s.replace(".",",")), Throwable::printStackTrace);
	}

	@Override
	protected int getDefaultLayout() {
		return R.layout.list_receipt_tax;
	}

	static class ReceiptHeaderHolder extends EpoxyHolder {
		@BindView(R.id.base_amount) TextView baseAmount;
		@BindView(R.id.base_price) TextView basePrice;
		@BindView(R.id.tax_amount) TextView taxAmount;
		@BindView(R.id.tax_price) TextView taxPrice;
		@BindView(R.id.total) LinearLayout total;

		@Override
		protected void bindView(View itemView) {
			ButterKnife.bind(this, itemView);
		}
	}
}

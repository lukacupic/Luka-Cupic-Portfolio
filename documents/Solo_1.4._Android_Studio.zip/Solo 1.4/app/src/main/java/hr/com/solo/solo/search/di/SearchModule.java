package hr.com.solo.solo.search.di;

import android.app.Activity;
import androidx.fragment.app.FragmentManager;

import hr.com.solo.solo.core.UserCatalogManager;
import hr.com.solo.solo.core.di.PerActivity;
import hr.com.solo.solo.navigation.Router;
import hr.com.solo.solo.navigation.RouterImpl;
import hr.com.solo.solo.networking.SoloService;
import hr.com.solo.solo.search.SearchContract;
import hr.com.solo.solo.search.SearchPresenter;
import hr.com.solo.solo.search.interactors.AddItemUseCase;
import hr.com.solo.solo.search.interactors.SearchRepositoriesUseCase;
import hr.com.solo.solo.search.mappers.SearchResultMapper;
import hr.com.solo.solo.search.repositories.SearchRepository;
import hr.com.solo.solo.search.repositories.SearchRepositoryInterface;
import hr.com.solo.solo.search.source.SearchNetworkSource;
import hr.com.solo.solo.search.source.SearchSource;
import hr.com.solo.solo.search.ui.adapters.SearchResultsAdapter;
import hr.com.solo.solo.search.ui.adapters.SearchResultsEpoxyAdapter;
import hr.com.solo.solo.utils.ImageLoader;

import javax.inject.Named;

import dagger.Module;
import dagger.Provides;
import io.reactivex.Scheduler;

// 2017-04-08 Ian Rumac

@Module
public class SearchModule {
	private final Activity activity;
	private final FragmentManager supportManger;

	public SearchModule(Activity activity, FragmentManager manager) {
		this.activity = activity;
		this.supportManger = manager;
	}

	@Provides
	@PerActivity
	SearchResultMapper provideResultMapper() {
		return new SearchResultMapper();
	}

	@Provides
	@PerActivity
	SearchSource provideSource(SoloService service, SearchResultMapper mapper) {
		return new SearchNetworkSource(service, mapper);
	}

	@Provides
	@PerActivity
	SearchRepositoryInterface provideRepository(UserCatalogManager source, @Named("io") Scheduler io) {
		return new SearchRepository(source, io);
	}

	@Provides
	@PerActivity
	SearchRepositoriesUseCase provideSearchRepositoryUseCase(SearchRepositoryInterface repository) {
		return new SearchRepositoriesUseCase(repository);
	}

	@Provides
	@PerActivity
	AddItemUseCase provideAddUsecase(SearchRepositoryInterface repository) {
		return new AddItemUseCase(repository);
	}


	@Provides
	@PerActivity
	SearchContract.SearchPresenter providePresenter(AddItemUseCase usecase, SearchRepositoriesUseCase repositoriesUseCase, @Named("post_execution") Scheduler postExecution) {
		return new SearchPresenter(repositoriesUseCase,usecase,  postExecution);
	}

	@Provides
	@PerActivity
	Router provideRouter() {
		return new RouterImpl(activity, supportManger);
	}

	@Provides
	@PerActivity
	SearchResultsAdapter provideAdapter(Router router, ImageLoader loader, UserCatalogManager manager) {
		return new SearchResultsEpoxyAdapter(router, loader,manager);
	}
}

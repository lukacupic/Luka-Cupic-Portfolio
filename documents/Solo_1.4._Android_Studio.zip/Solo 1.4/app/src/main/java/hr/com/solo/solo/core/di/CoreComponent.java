package hr.com.solo.solo.core.di;

import hr.com.solo.solo.core.CoreApplication;
import hr.com.solo.solo.base.RxModule;
import hr.com.solo.solo.core.UserCatalogManager;
import hr.com.solo.solo.core.UserReceiptManager;
import hr.com.solo.solo.networking.SoloService;
import hr.com.solo.solo.networking.NetworkModule;
import hr.com.solo.solo.utils.ImageLoader;

import javax.inject.Named;
import javax.inject.Singleton;

import dagger.Component;
import io.reactivex.Scheduler;

// 2017-04-08 Ian Rumac

@Singleton
@Component(modules = {CoreModule.class, NetworkModule.class, RxModule.class})
public interface CoreComponent {

	CoreApplication application();

	SoloService service();

	ImageLoader imageLoader();

	@Named("io")
	Scheduler schedulerIO();

	@Named("post_execution")
	Scheduler schedulerPostExecution();

	UserCatalogManager manager();

	UserReceiptManager receiptManager();
}

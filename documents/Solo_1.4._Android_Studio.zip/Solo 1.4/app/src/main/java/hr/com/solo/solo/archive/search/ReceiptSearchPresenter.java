package hr.com.solo.solo.archive.search;

import java.net.UnknownHostException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.inject.Named;

import hr.com.solo.solo.R;
import hr.com.solo.solo.archive.search.interactors.SearchReceiptsUseCase;
import hr.com.solo.solo.archive.search.network.ReceiptResponseItem;
import hr.com.solo.solo.core.CoreApplication;
import io.reactivex.Observable;
import io.reactivex.Scheduler;

// 2017-04-08 Ian Rumac

public class ReceiptSearchPresenter implements ReceiptSearchContract.ReceiptSearchPresenter {
	private ReceiptSearchContract.ReceiptSearchView view;
	private final SearchReceiptsUseCase useCase;
	private final Scheduler postExecution;
	final int THROTTLE = 400;

	@Inject
	public ReceiptSearchPresenter(SearchReceiptsUseCase useCase, @Named("post_execution") Scheduler postExecution) {
		this.postExecution = postExecution;
		this.useCase = useCase;
	}

	@Override
	public void attachView(ReceiptSearchContract.ReceiptSearchView view) {
		this.view = view;

		filterAndExecute(view.getSearchObservable()).subscribe(this::displayResults, this::handleError);
	}

	private Observable<List<ReceiptResponseItem>> filterAndExecute(Observable<String> params) {
		return params
				.debounce(THROTTLE, TimeUnit.MILLISECONDS)
				.flatMap(useCase::executeWithParams)
				.observeOn(postExecution);
	}

	private void displayResults(List<ReceiptResponseItem> results) {
		if (results.isEmpty()) {
			view.displayEmpty();
		} else {
			view.displayResults(results);
			view.hideLoading();
		}
	}

	@Override
	public void handleError(Throwable throwable) {
		if (throwable instanceof UnknownHostException) {
			view.displayError(CoreApplication.getInstance().getString(R.string.api_ded));
		} else {
			view.displayError(CoreApplication.getInstance().getString(R.string.conn_error));
		}
	}

	@Override
	public void detachView(ReceiptSearchContract.ReceiptSearchView view) {
		this.view = null;
	}
}

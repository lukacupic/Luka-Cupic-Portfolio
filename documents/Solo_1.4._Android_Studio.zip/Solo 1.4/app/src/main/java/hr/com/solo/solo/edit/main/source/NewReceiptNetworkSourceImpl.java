package hr.com.solo.solo.edit.main.source;

import javax.inject.Inject;

import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.networking.SoloService;
import io.reactivex.Single;

// 2017-04-09 Ian Rumac

public class NewReceiptNetworkSourceImpl implements NewReceiptNetworkSource {
	SoloService apiService;

	@Inject
	public NewReceiptNetworkSourceImpl(SoloService apiService) {
		this.apiService = apiService;
	}

	@Override
	public Single<CatalogItem> getRepositoryDetails(String owner, String repositoryName) {
		return null;/*mapper.mapResponseResultToList(apiService.getRepositoryByOwnerAndName(owner, repositoryName))*/
	}
}

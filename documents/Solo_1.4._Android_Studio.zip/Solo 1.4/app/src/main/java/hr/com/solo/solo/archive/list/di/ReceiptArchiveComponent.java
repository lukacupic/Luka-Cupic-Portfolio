package hr.com.solo.solo.archive.list.di;

import dagger.Component;
import hr.com.solo.solo.archive.list.ui.ReceiptArchiveActivity;
import hr.com.solo.solo.core.di.CoreComponent;
import hr.com.solo.solo.core.di.PerFragment;

// 2017-04-08 Ian Rumac

@PerFragment
@Component(dependencies = CoreComponent.class, modules = ReceiptArchiveModule.class)
public interface ReceiptArchiveComponent {
	void inject(ReceiptArchiveActivity newReceiptFragment);
}

package hr.com.solo.solo.main.mappers;

import hr.com.solo.solo.main.models.CatalogItem;

import hr.com.solo.solo.search.models.network.ItemListResponseWrapper;
import io.reactivex.Single;

// 2017-04-08 Ian Rumac

public class NewReceiptResponseMapper {
	public Single<CatalogItem> mapResponseResultToList(Single<ItemListResponseWrapper> details) {
		return null;
/*
		return details.map(response -> new CatalogItem.Builder()
				.id(response.getId()).build());
*/
	}
}

package hr.com.solo.solo.search.source;

import java.util.List;

import io.reactivex.Observable;

// 2017-04-08 Ian Rumac

public interface SearchSource {
/*
	public Observable<List<GithubRepository>> searchRepositoriesByQuery(String query, String sort, String order, int page);
*/
}

package hr.com.solo.solo.printer;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;

import com.rt.printerlibrary.bean.BluetoothEdrConfigBean;
import com.rt.printerlibrary.cmd.EscCmd;
import com.rt.printerlibrary.cmd.EscFactory;
import com.rt.printerlibrary.connect.PrinterInterface;
import com.rt.printerlibrary.enumerate.*;
import com.rt.printerlibrary.factory.connect.BluetoothFactory;
import com.rt.printerlibrary.factory.printer.PrinterFactory;
import com.rt.printerlibrary.factory.printer.UniversalPrinterFactory;
import com.rt.printerlibrary.printer.RTPrinter;
import com.rt.printerlibrary.setting.TextSetting;
import com.rt.printerlibrary.utils.ConnectListener;

import java.io.UnsupportedEncodingException;

// 2022-10-24 Dejan
// 2022-10-25 Matija (optimizacije)
// 2022-11-20 Luka

class RongtaPrinter extends BasePrinter {
    private RTPrinter rongtaPrinter;

    public RongtaPrinter(PrinterStatusCallback printerStatusCallback) {
        super(printerStatusCallback);
    }

    // INTERFACE METHODS

    @Override
    public void connectPrinter(String address, String name) {
        executeAsync(() -> {
            try {
                statusCallback.onStatus(PrinterStatusCallback.STATUS.CONNECTING);

                BluetoothDevice device = BluetoothAdapter.getDefaultAdapter().getRemoteDevice(address);
                BluetoothEdrConfigBean config = new BluetoothEdrConfigBean(device);

                PrinterInterface printerInterface = new BluetoothFactory().create();
                printerInterface.setConfigObject(config);

                PrinterFactory printerFactory = new UniversalPrinterFactory();
                rongtaPrinter = printerFactory.create();
                rongtaPrinter.setPrinterInterface(printerInterface);
                rongtaPrinter.setConnectListener(new RongtaConnectListener());
                rongtaPrinter.connect(config);

                Thread.sleep(3000); // timeout

                if (rongtaPrinter.getConnectState() == ConnectStateEnum.NoConnect) {
                    statusCallback.onStatus(PrinterStatusCallback.STATUS.NOT_SUPPORTED);
                }
            } catch (Exception ex) {
                statusCallback.onStatus(PrinterStatusCallback.STATUS.ERROR);
            }
        });
    }

    @Override
    public void printInvoice(Object invoice, Object qrCode) {
        if (rongtaPrinter == null) {
            return;
        }

        executeAsync(() -> {
            try {
                // Init
                EscFactory escFactory = new EscFactory();
                EscCmd escCmd = escFactory.create();

                escCmd.clear(); // Clear all commands
                escCmd.append(escCmd.getHeaderCmd());
                escCmd.setChartsetName("UTF-8"); // UTF-8, GBK, BIG5, UCS2
                escCmd.append(escCmd.setEscCodePage(30));
                rongtaPrinter.writeMsgAsync(escCmd.getAppendCmds());

                // Text settings
                TextSetting textSettings = new TextSetting();

                escCmd.append(escCmd.getTextCmd(textSettings, "test č ć ž š đ"));

                textSettings.setAlign(CommonEnum.ALIGN_MIDDLE);
                textSettings.setEscFontType(ESCFontTypeEnum.FONT_B_9x24);

                // Line feeds
                escCmd.append(escCmd.getLFCRCmd());
                escCmd.append(escCmd.getLFCRCmd());
                escCmd.append(escCmd.getLFCRCmd());

                // Run
                rongtaPrinter.writeMsgAsync(escCmd.getAppendCmds());
            } catch (UnsupportedEncodingException ex) {
                statusCallback.onStatus(PrinterStatusCallback.STATUS.ERROR);
            }
        });
    }

    @Override
    public void disconnectPrinter() {
        executeAsync(() -> {
            if (this.rongtaPrinter != null) {
                rongtaPrinter.disConnect();
            }
            rongtaPrinter = null;
            setConnected(false);
        });
    }

    // END OF INTERFACE METHODS

    class RongtaConnectListener implements ConnectListener {
        @Override
        public void onPrinterConnected(Object configObj) {
            setConnected(true);
            statusCallback.onStatus(PrinterStatusCallback.STATUS.CONNECTED);
        }

        @Override
        public void onPrinterDisconnect(Object configObj) {
        }

        @Override
        public void onPrinterWritecompletion(Object configObj) {
            try {
                statusCallback.onStatus(PrinterStatusCallback.STATUS.DONE);
                Thread.sleep(500);
            } catch (InterruptedException ex) {
            }
        }
    }
}
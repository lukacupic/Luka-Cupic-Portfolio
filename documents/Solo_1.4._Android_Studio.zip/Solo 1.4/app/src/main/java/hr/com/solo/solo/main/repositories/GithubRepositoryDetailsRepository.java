package hr.com.solo.solo.main.repositories;

import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.main.source.NewReceiptNetworkSource;

import javax.inject.Inject;
import javax.inject.Named;

import hr.com.solo.solo.search.models.network.ItemListResponseWrapper;
import io.reactivex.Scheduler;
import io.reactivex.Single;

// 2017-04-09 Ian Rumac

public class GithubRepositoryDetailsRepository implements CatalogDetailsRepository {
	NewReceiptNetworkSource dataSource;
	Scheduler executionScheduler;

	@Inject
	public GithubRepositoryDetailsRepository(NewReceiptNetworkSource dataSource, @Named("io") Scheduler execution) {
		this.dataSource = dataSource;
		this.executionScheduler = execution;
	}

	@Override
	public Single<ItemListResponseWrapper> fetchCatalog(String token) {
		return dataSource.getCatalog(token).subscribeOn(executionScheduler);
	}
}

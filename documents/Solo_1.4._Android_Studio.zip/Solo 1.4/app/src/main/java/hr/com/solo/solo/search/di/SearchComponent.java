package hr.com.solo.solo.search.di;

import hr.com.solo.solo.core.UserCatalogManager;
import hr.com.solo.solo.core.di.CoreComponent;
import hr.com.solo.solo.core.di.PerActivity;
import hr.com.solo.solo.navigation.Router;
import hr.com.solo.solo.networking.SoloService;
import hr.com.solo.solo.search.ui.SearchActivity;
import hr.com.solo.solo.utils.ImageLoader;

import javax.inject.Named;

import dagger.Component;
import io.reactivex.Scheduler;

// 2017-04-08 Ian Rumac

@PerActivity
@Component(dependencies = CoreComponent.class, modules = SearchModule.class)
public interface SearchComponent {
	void inject(SearchActivity mainActivity);

	Router provideRouter();

	SoloService service();

	ImageLoader imageLoader();

	UserCatalogManager manager();

	@Named("io")
	Scheduler schedulerIO();

	@Named("post_execution")
	Scheduler schedulerPostExecution();
}

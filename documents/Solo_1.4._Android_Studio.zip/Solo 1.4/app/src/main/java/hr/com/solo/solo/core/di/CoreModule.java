package hr.com.solo.solo.core.di;

import hr.com.solo.solo.core.CoreApplication;
import hr.com.solo.solo.core.UserCatalogManager;
import hr.com.solo.solo.core.UserReceiptManager;
import hr.com.solo.solo.utils.GlideImageLoader;
import hr.com.solo.solo.utils.ImageLoader;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

// 2017-04-08 Ian Rumac

@Module
public class CoreModule {
	private CoreApplication application;
	public CoreModule(CoreApplication application) {
		this.application = application;
	}

	@Provides
	@Singleton
	CoreApplication getApplication() {
		return application;
	}

	@Provides
	@Singleton
	ImageLoader provideImageLoader(CoreApplication application) {
		return new GlideImageLoader(application);
	}

	@Provides
	@Singleton
	UserCatalogManager manager(){
		return new UserCatalogManager();
	}

	@Provides
	@Singleton
	UserReceiptManager receiptManager(){
		return new UserReceiptManager();
	}
}

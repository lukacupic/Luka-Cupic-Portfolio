package hr.com.solo.solo.printer;

// 2017-07-16 Haris Kovacevic
// 2022-11-21 Luka

public abstract class BasePrinter implements IPrinter {

    protected PrinterStatusCallback statusCallback;
    protected boolean isConnected = false;

    public BasePrinter(PrinterStatusCallback printerStatusCallback) {
        this.statusCallback = printerStatusCallback;
    }

    @Override
    public boolean isConnected() {
        return isConnected;
    }

    @Override
    public void setConnected(boolean isConnected) {
        this.isConnected = isConnected;
    }

    @Override
    public void setPrinterStatusCallback(PrinterStatusCallback callback) {
        this.statusCallback = callback;
    }

    protected void executeAsync(Runnable runnable) {
        if (runnable != null) {
            new Thread(runnable).start();
        }
    }
}

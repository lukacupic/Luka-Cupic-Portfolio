package hr.com.solo.solo.archive.list;

import java.util.List;

import hr.com.solo.solo.archive.search.network.ReceiptResponseItem;
import hr.com.solo.solo.base.BaseView;
import hr.com.solo.solo.base.Presenter;

// 2017-04-09 Ian Rumac

public interface ReceiptArchiveContract {
	interface ReceiptArchiveView extends BaseView {
		void displayReceipts(List<ReceiptResponseItem> receiptResponseItemList);
		void displayEmpty();
		void removeItem();
	}

	interface ReceiptArchivePresenter extends Presenter<ReceiptArchiveView> {
		void getReceiptList(String token, boolean isRefreshing);
	}
}

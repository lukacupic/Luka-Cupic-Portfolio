package hr.com.solo.solo.adapters;

import android.content.Context;
import android.view.View;

import com.airbnb.epoxy.EpoxyAdapter;

import hr.com.solo.solo.adapters.viewmodels.PaymentTypeViewModel;
import hr.com.solo.solo.adapters.viewmodels.TotalViewModel;

// 2017-04-26 Ian Rumac

public class PaymentTypeAdapter extends EpoxyAdapter{
	public PaymentTypeAdapter(Context context,String price, View.OnClickListener clickListener) {
		addModel(new TotalViewModel(price));
		addModel(new PaymentTypeViewModel(context,"Gotovina",2, clickListener));
		addModel(new PaymentTypeViewModel(context,"Kartice",3, clickListener));
		addModel(new PaymentTypeViewModel(context,"Čekovi",4, clickListener));
		addModel(new PaymentTypeViewModel(context,"Ostalo",5, clickListener));
		addModel(new PaymentTypeViewModel(context,"Transakcijski račun",1, clickListener));
		notifyItemRangeInserted(0,6);
	}
}

package hr.com.solo.solo.core;

import com.annimon.stream.Collectors;
import com.annimon.stream.Stream;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import hr.com.solo.solo.archive.search.network.ReceiptItemListResponseWrapper;
import hr.com.solo.solo.archive.search.network.ReceiptResponseItem;

// 2017-04-22 Ian Rumac

public class UserReceiptManager {
	List<ReceiptResponseItem> catalogItems;

	public UserReceiptManager() {
		catalogItems = new ArrayList<>();
	}

	public boolean isEmpty(){
		return catalogItems.isEmpty();
	}

	public List<ReceiptResponseItem> getReceipts(){
		if(catalogItems==null)
			return new ArrayList<>();
		return catalogItems;
	}

	public void setCatalogItems(List<ReceiptResponseItem> catalogItems) {
		this.catalogItems = catalogItems;
	}

	public List<ReceiptResponseItem> getItemsForQuery(String query){
		return Stream.of(catalogItems).filter(value -> value.getBrojRacuna().replace("-","").toLowerCase().contains(query.toLowerCase()))
				.collect(Collectors.toList());
	}
}

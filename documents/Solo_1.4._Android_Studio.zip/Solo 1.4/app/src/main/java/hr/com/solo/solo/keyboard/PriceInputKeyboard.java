package hr.com.solo.solo.keyboard;

import android.app.Activity;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import androidx.annotation.XmlRes;
import androidx.appcompat.widget.AppCompatEditText;
import android.text.Editable;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import java.lang.ref.WeakReference;

import hr.com.solo.solo.R;

// 2017-05-01 Ian Rumac

public class PriceInputKeyboard {
	int sizeOfDecimals = 4;
	int sizeOfPredecimals = 8;
	WeakReference<Activity> parentActivity;
	KeyboardView keyboardView;

	public PriceInputKeyboard(Activity parent, KeyboardView view, @XmlRes int keyboardLayout) {
		parentActivity = new WeakReference<Activity>(parent);
		keyboardView = view;

		Keyboard mKeyboard = new Keyboard(parentActivity.get(), keyboardLayout);
		keyboardView.setKeyboard(mKeyboard);
		keyboardView.setPreviewEnabled(false);
		keyboardView.setOnKeyboardActionListener(new KeyboardView.OnKeyboardActionListener() {
			@Override
			public void onPress(int i) { }

			@Override
			public void onRelease(int i) { }

			@Override
			public void onKey(int primaryCode, int[] ints) {
				View focusCurrent = parentActivity.get().getWindow().getCurrentFocus();
				if (focusCurrent == null || focusCurrent.getClass() != AppCompatEditText.class) {
					return;
				}
				EditText edittext = (EditText) focusCurrent;
				if (edittext.getId() == R.id.item_price) {
					sizeOfDecimals = 2;
					sizeOfPredecimals = 18;
				} else {
					sizeOfDecimals = 4;
					sizeOfPredecimals = 8;
				}
				Editable editable = edittext.getText();
				int start = edittext.getSelectionStart();
				String value = String.valueOf(primaryCode);
				if (primaryCode == -1) {
					if (start - 1 >= 0) {
						editable.delete(start - 1, start);
					}
				} else if (primaryCode == 9001) {
					if (!editable.toString().contains(",")) {
						editable.insert(start, ",");
					}
				} else {
					int indexOfComma = editable.toString().indexOf(",");
					if (indexOfComma != -1 && start > indexOfComma) {
						if (!((editable.toString().length() - indexOfComma) > sizeOfDecimals)) {
							editable.insert(start, value);
						}
					} else {
						if(indexOfComma == -1){
							indexOfComma = editable.toString().length();
						}

						if (!(indexOfComma > sizeOfPredecimals)) {
							editable.insert(start, value);
						}
					}
				}
			}

			@Override
			public void onText(CharSequence charSequence) { }

			@Override
			public void swipeLeft() { }

			@Override
			public void swipeRight() { }

			@Override
			public void swipeDown() { }

			@Override
			public void swipeUp() { }
		});
	}

	public void hideCustomKeyboard() {
		keyboardView.setVisibility(View.GONE);
		keyboardView.setEnabled(false);
	}

	public void showCustomKeyboard(View v) {
		keyboardView.setVisibility(View.VISIBLE);
		keyboardView.setEnabled(true);
		if (v != null) {
			((InputMethodManager) parentActivity.get().getSystemService(Activity.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(), 0);
		}
	}

	public boolean isCustomKeyboardVisible() {
		return keyboardView.getVisibility() == View.VISIBLE;
	}

	View.OnFocusChangeListener onFocusChangeListener = new View.OnFocusChangeListener() {
		@Override
		public void onFocusChange(View view, boolean hasFocus) {
			if (hasFocus) {
				showCustomKeyboard(view);
			} else {
				hideCustomKeyboard();
			}
		}
	};

	View.OnClickListener onEditTextClick = new View.OnClickListener() {
		@Override
		public void onClick(View view) {
			showCustomKeyboard(view);

		}
	};

	public void registerEditText(EditText editText) {
		editText.setOnClickListener(onEditTextClick);
		editText.setOnFocusChangeListener(onFocusChangeListener);
	}
}

package hr.com.solo.solo.main;

import javax.inject.Inject;

import hr.com.solo.solo.core.UserCatalogManager;
import hr.com.solo.solo.main.interactors.NewReceiptUseCase;
import hr.com.solo.solo.search.models.network.ItemListResponseWrapper;
import hr.com.solo.solo.utils.RetrofitException;
import io.reactivex.android.schedulers.AndroidSchedulers;
import timber.log.Timber;

// 2017-04-09 Ian Rumac

public class NewReceiptPresenterImpl implements NewReceiptContract.NewReceiptPresenter {
	NewReceiptUseCase useCase;
	NewReceiptContract.NewReceiptView view;
	UserCatalogManager manager;

	@Inject
	public NewReceiptPresenterImpl(NewReceiptUseCase useCase, UserCatalogManager manager) {
		this.useCase = useCase;
		this.manager = manager;
	}

	@Override
	public void attachView(NewReceiptContract.NewReceiptView view) {
		this.view = view;
	}

	@Override
	public void detachView(NewReceiptContract.NewReceiptView view) {
		this.view = null;
	}

	@Override
	public void handleError(Throwable throwable) { }

	@Override
	public void getCatalogItems(String token, boolean isRefreshing) {
		if (!isRefreshing)
			view.showLoading();
		useCase.executeWithParams(token).observeOn(AndroidSchedulers.mainThread()).subscribe(this::displayResultsAndAddToManager, throwable -> {
			view.hideLoading();
			throwable.printStackTrace();
			if(throwable instanceof RetrofitException) {
				RetrofitException error = (RetrofitException) throwable;
				if (error.getResponse().code() > 500) {
					view.showMessageError("Solo trenutno nije dostupan. Pokušaj ponovo za par minuta.");
				} else {
					view.showMessageError("Došlo je do greške u prikazu. Pokušaj ponovo ili nas kontaktiraj.");
				}
				Timber.e(error.getResponse().code() + " code - body is: " + error.getResponse().message());
			} else {
				view.showMessageError("Solo trenutno nije dostupan. Pokušaj ponovo za par minuta.");
			}
		});
	}

	private void displayResultsAndAddToManager(ItemListResponseWrapper wrapper) {
		manager.setupCatalogItems(wrapper);
		if (view != null) {
			view.hideLoading();
			if(wrapper.itemList!=null && !wrapper.itemList.isEmpty()){
			view.addItems(wrapper.itemList);

			}else{
				view.displayEmpty();
			}
		}
	}
}

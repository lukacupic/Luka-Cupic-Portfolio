package hr.com.solo.solo.printer;

import android.content.Context;

import com.lvrenyang.io.BTPrinting;
import com.lvrenyang.io.Pos;

import hr.com.solo.solo.utils.PrinterUtils;

// 2020-12-17 Farhad Bhuiyan (SDK + QR code)
// 2022-10-25 Dejan (new SDK, not working)
// 2022-10-26 Matija (old SDK tweaks)
// 2022-11-14 Luka

public class XMJPrinter extends BasePrinter {

    private final Context mContext;
    private final Pos xmjPrinter = new Pos();
    private BTPrinting bluetoothAdapter = new BTPrinting();

    public XMJPrinter(Context context, PrinterStatusCallback printerStatusCallback) {
        super(printerStatusCallback);
        mContext = context;
    }

    // INTERFACE METHODS

    @Override
    public void connectPrinter(String address, String name) {
        executeAsync(() -> {
            statusCallback.onStatus(PrinterStatusCallback.STATUS.CONNECTING);

            xmjPrinter.Set(bluetoothAdapter);
            boolean isConnected = bluetoothAdapter.Open(address, mContext);

            statusCallback.onStatus(isConnected ? PrinterStatusCallback.STATUS.CONNECTED : PrinterStatusCallback.STATUS.NOT_SUPPORTED);
            setConnected(isConnected);
        });
    }

    @Override
    public void printInvoice(Object invoice, Object qrCode) {
        String text = (String) invoice;
        String qr = (String) qrCode;

        executeAsync(() -> {
            xmjPrinter.POS_Reset();
            xmjPrinter.POS_S_Align(0);
            xmjPrinter.POS_TextOut(text, 0, 0, 0, 0, 0, 0);
            xmjPrinter.POS_S_Align(1);
            if (qr != null) {
                xmjPrinter.POS_PrintPicture(PrinterUtils.createBitmapFromQR(qr), 220, 1, 0);
                xmjPrinter.POS_FeedLine();
            }
            boolean isConnected = xmjPrinter.POS_S_TextOut("- solo.com.hr mobilna fiskalna -", 0, 0, 0, 1, 0);
            xmjPrinter.POS_FeedLine();
            xmjPrinter.POS_FeedLine();
            xmjPrinter.POS_FeedLine();

            statusCallback.onStatus(isConnected ? PrinterStatusCallback.STATUS.DONE : PrinterStatusCallback.STATUS.NOT_SUPPORTED);
        });
    }

    @Override
    public void disconnectPrinter() {
        executeAsync(() -> {
            if (bluetoothAdapter != null) {
                bluetoothAdapter.Close();
            }
            bluetoothAdapter = null;
            setConnected(false);
        });
    }

    // END OF INTERFACE METHODS
}
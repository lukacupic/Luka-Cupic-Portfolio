package hr.com.solo.solo.archive.search.ui;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;
import android.view.View;
import android.widget.TextView;

import com.jakewharton.rxbinding2.widget.RxTextView;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import hr.com.solo.solo.R;
import hr.com.solo.solo.archive.search.ReceiptSearchContract;
import hr.com.solo.solo.archive.search.di.DaggerReceiptSearchComponent;
import hr.com.solo.solo.archive.search.di.ReceiptSearchComponent;
import hr.com.solo.solo.archive.search.di.ReceiptSearchComponentOwner;
import hr.com.solo.solo.archive.search.di.ReceiptSearchModule;
import hr.com.solo.solo.archive.search.network.ReceiptResponseItem;
import hr.com.solo.solo.archive.search.ui.adapters.ReceiptSearchResultsEpoxyAdapter;
import hr.com.solo.solo.base.BaseActivity;
import hr.com.solo.solo.core.CoreApplication;
import hr.com.solo.solo.core.UserReceiptManager;
import hr.com.solo.solo.navigation.Router;
import hr.com.solo.solo.utils.CustomEditText;
import io.reactivex.Observable;

public class ReceiptSearchActivity extends BaseActivity implements ReceiptSearchContract.ReceiptSearchView, ReceiptSearchComponentOwner {

	@BindView(R.id.recycler_result_list) RecyclerView recyclerResultList;
	@BindView(R.id.search_field) CustomEditText editText;
	@BindView(R.id.empty) TextView emptyText;
	@BindView(R.id.title) TextView title;
	@Inject ReceiptSearchContract.ReceiptSearchPresenter presenter;
	@Inject Router router;
	@Inject ReceiptSearchResultsEpoxyAdapter adapter;
	@Inject
	UserReceiptManager manager;

	ReceiptSearchComponent searchComponent;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_search);
		ButterKnife.bind(this);
		title.setText(R.string.trazi_racun);

		searchComponent = DaggerReceiptSearchComponent.builder()
				.coreComponent(CoreApplication.getInstance().getComponent())
				.receiptSearchModule(new ReceiptSearchModule(this, getSupportFragmentManager()))
				.build();
		searchComponent.inject(this);
		presenter.attachView(this);
		if (manager.isEmpty()) {
			emptyText.setText(R.string.archive_empty);
		} else {
			emptyText.setVisibility(View.GONE);
		}

		setupRecyclerViewWithAdapter();
	}

	@OnClick(R.id.ic_back)
	void goBack() {
		onBackPressed();
	}

	private void setupRecyclerViewWithAdapter() {
		recyclerResultList.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
		recyclerResultList.setAdapter(adapter);
		RecyclerView.ItemAnimator animator = recyclerResultList.getItemAnimator();
		if (animator instanceof SimpleItemAnimator) {
			((SimpleItemAnimator) animator).setSupportsChangeAnimations(false);
		}

	}

	@Override
	public void showLoading() { }

	@Override
	public void hideLoading() { }

	@Override
	public void displayResults(List<ReceiptResponseItem> results) {
		if (editText.getText().toString().isEmpty()) {
			displayEmpty();
		} else {
			if (recyclerResultList.getVisibility() != View.VISIBLE) {
				recyclerResultList.setVisibility(View.VISIBLE);
				emptyText.setVisibility(View.GONE);

			}
			adapter.updateModels(results, editText.getText().toString(), item -> {
			});
		}
	}

	@Override
	public Observable<String> getSearchObservable() {
		return RxTextView.textChanges(editText).map(CharSequence::toString);
	}


	@Override
	public void displayEmpty() {
		if (!editText.getText().toString().isEmpty()) {
			emptyText.setVisibility(View.VISIBLE);
			recyclerResultList.setVisibility(View.GONE);
			adapter.clearAndAddNewModels(new ArrayList<>(), "", item -> {
			});
		} else {
			if (manager.getReceipts().isEmpty()) {
				emptyText.setText(R.string.archive_empty);
			} else {
				emptyText.setText(R.string.receipt_not_found);
			}
		}
	}

	@Override
	public void displayError(String message) {
		showErrorWith(message);
	}

	@Override
	public void done() {
		finish();
	}

	@Override
	public ReceiptSearchComponent searchComponent() {
		return searchComponent;
	}
}

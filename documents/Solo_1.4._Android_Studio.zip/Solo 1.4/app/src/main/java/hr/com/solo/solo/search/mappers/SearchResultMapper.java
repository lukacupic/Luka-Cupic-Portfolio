package hr.com.solo.solo.search.mappers;

import com.annimon.stream.Stream;
import hr.com.solo.solo.search.models.Owner;
import java.util.LinkedList;
import java.util.List;

import io.reactivex.Observable;

// 2017-04-08 Ian Rumac

public class SearchResultMapper {
/*
	public Observable<List<GithubRepository>> mapResponseResultToList(Observable<GithubListResponseWrapper> resultWrapperObservable) {

		final List<GithubRepository> repositories = new LinkedList<>();
		return resultWrapperObservable.map(githubListResponseWrapper -> (Stream.of(githubListResponseWrapper.getItemList())
				.map(this::mapToRepository)
				.collect(() -> repositories, List::add)));
	}

	private GithubRepository mapToRepository(GithubRepositoryResponseItem item) {
		return new GithubRepository(item.getId(),
				item.getName(),
				ownerFromItemOwner(item.getOwner()),
				item.getWatchersCount(), item.getForksCount(), item.getIssuesCount());
	}

	private Owner ownerFromItemOwner(GithubRepositoryOwnerResponse itemOwner) {
		return new Owner(itemOwner.
				getLogin(),
				itemOwner.getId(), itemOwner.getAvatarUrl());
	}
*/
}

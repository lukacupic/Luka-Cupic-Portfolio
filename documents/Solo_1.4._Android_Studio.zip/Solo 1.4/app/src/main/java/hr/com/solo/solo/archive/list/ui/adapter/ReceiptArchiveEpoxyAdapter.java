package hr.com.solo.solo.archive.list.ui.adapter;

import com.airbnb.epoxy.EpoxyAdapter;

import java.util.List;

import javax.inject.Inject;

import hr.com.solo.solo.archive.list.ui.viewmodels.ReceiptArchiveItemViewModel;
import hr.com.solo.solo.archive.search.network.ReceiptResponseItem;
import hr.com.solo.solo.archive.search.ui.adapters.ReceiptSearchResultsAdapter;
import hr.com.solo.solo.archive.search.ui.viewmodels.ReceiptItemViewModel;
import hr.com.solo.solo.navigation.Router;
import hr.com.solo.solo.utils.ImageLoader;
import hr.com.solo.solo.utils.OnItemSelected;

// 2017-04-08 Ian Rumac

public class ReceiptArchiveEpoxyAdapter extends EpoxyAdapter implements ReceiptSearchResultsAdapter {
	public ReceiptArchiveEpoxyAdapter() {
		enableDiffing();
	}

	@Override
	public void clearAndAddNewModels(List<ReceiptResponseItem> githubRepositories, String query, OnItemSelected<ReceiptResponseItem> itemOnItemSelected) {
		final int modelsSize = models.size();
		models.clear();
		addModels(githubRepositories, query, itemOnItemSelected);
	}

	@Override
	public void addModels(List<ReceiptResponseItem> githubRepositories, String query,OnItemSelected<ReceiptResponseItem> itemSelected) {
		for (int i = 0; i < githubRepositories.size(); i++) {
			ReceiptResponseItem result = githubRepositories.get(i);

			addModel(new ReceiptArchiveItemViewModel(result,itemSelected));
		}

		notifyModelsChanged();
	}
}

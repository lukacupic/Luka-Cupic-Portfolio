package hr.com.solo.solo.login;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import android.os.Environment;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.R;
import hr.com.solo.solo.base.BaseActivity;
import hr.com.solo.solo.core.CoreApplication;
import hr.com.solo.solo.main.ui.NewReceiptActivity;
import hr.com.solo.solo.networking.SoloService;
import hr.com.solo.solo.utils.CustomEditText;
import hr.com.solo.solo.utils.PrefsUtils;
import hr.com.solo.solo.utils.PrinterUtils;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;

import static jpos.util.tracing.Tracing.print;

// 2017-04-22 Ian Rumac

public class LoginActivity extends BaseActivity implements LoginContract.LoginView {
	@BindView(R.id.logo) ImageView logo;
	@BindView(R.id.content_view) ScrollView contentView;
	@BindView(R.id.username) CustomEditText username;
	@BindView(R.id.password) CustomEditText password;
	@BindView(R.id.login_btn) TextView loginBtn;
	@BindView(R.id.container_layout) RelativeLayout containerLayout;
	@BindView(R.id.no_acount) TextView noAccount;
	@Inject SoloService service;

	LoginPresenter presenter;

	@Override
	protected void onCreate(@Nullable Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);

		service = CoreApplication.getInstance().getComponent().service();
		presenter = new LoginPresenter(service, this);
		ButterKnife.bind(this);
		if(!PrefsUtils.getToken().isEmpty()){
			goToMain();
		}
		loginBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				presenter.loginUser(username.getText().toString(),password.getText().toString());
			}
		});
		noAccount.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://solo.com.hr/paketi-i-cijene")));
			}
		});

		contentView.getViewTreeObserver().addOnGlobalLayoutListener(
				new ViewTreeObserver.OnGlobalLayoutListener() {
					@Override
					public void onGlobalLayout() {

						Rect r = new Rect();
						contentView.getWindowVisibleDisplayFrame(r);
						int screenHeight = contentView.getRootView().getHeight();

						// r.bottom is the position above soft keypad or device button.
						// if keypad is shown, the r.bottom is smaller than that before.
						int keypadHeight = screenHeight - r.bottom;

						if (keypadHeight > screenHeight * 0.15) { // 0.15 ratio is perhaps enough to determine keypad height.
							// keyboard is opened
							if (!isKeyboardShowing) {
								isKeyboardShowing = true;
								onKeyboardVisibilityChanged(true);
							}
						}
						else {
							// keyboard is closed
							if (isKeyboardShowing) {
								isKeyboardShowing = false;
								onKeyboardVisibilityChanged(false);
							}
						}
					}
				});
		}

	boolean isKeyboardShowing = false;
	void onKeyboardVisibilityChanged(boolean opened) {
		if (opened){
			logo.setVisibility(View.GONE);
		} else {
			logo.setVisibility(View.VISIBLE);
		}
	}

	@Override
	protected void attachBaseContext(Context newBase) {
		super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase));
	}

	@Override
	protected void onStart() {
		super.onStart();
	}

	@Override
	public void showMessageError(String error) {
		showErrorWith(error);
	}
	ProgressDialog dialog;
	public void showLoading() {

		dialog = new ProgressDialog(this);
		Spanned styledMessage;
		String  htmlStyling = "<font color='white'><big>Pričekaj trenutak</big></font>";
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
			styledMessage = Html.fromHtml(htmlStyling,Html.FROM_HTML_MODE_LEGACY);
		} else {
			styledMessage = Html.fromHtml(htmlStyling);
		}
		dialog.setMessage(styledMessage);
		dialog.show();
	}

	public void hideLoading() {
		if(dialog!=null){
			dialog.dismiss();
		}
	}

	@Override
	public void loginSuccessfully(String token) {
		PrefsUtils.saveToken(token);
		goToMain();
	}

	public void goToMain(){
		startActivity(new Intent(this,NewReceiptActivity.class));
		finish();
	}

	public void displayError(String message) {
		showErrorWith(message);
	}
}

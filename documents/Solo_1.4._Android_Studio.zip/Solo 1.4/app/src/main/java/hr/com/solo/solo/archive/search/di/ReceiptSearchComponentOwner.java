package hr.com.solo.solo.archive.search.di;

// 2017-04-10 Ian Rumac

public interface ReceiptSearchComponentOwner {
	ReceiptSearchComponent searchComponent();
}

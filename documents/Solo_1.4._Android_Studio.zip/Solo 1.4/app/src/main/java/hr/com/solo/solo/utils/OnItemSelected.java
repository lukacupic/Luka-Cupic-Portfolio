package hr.com.solo.solo.utils;

// 2017-04-24 Ian Rumac

public interface OnItemSelected<T> {
    void itemSelected(T item);
}

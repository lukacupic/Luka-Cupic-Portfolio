package hr.com.solo.solo.main.source;

import java.util.List;

import hr.com.solo.solo.main.models.CatalogItem;

import hr.com.solo.solo.search.models.network.ItemListResponseWrapper;
import io.reactivex.Single;

// 2017-04-09 Ian Rumac

public interface NewReceiptNetworkSource {
	Single<ItemListResponseWrapper> getCatalog(String token);
}

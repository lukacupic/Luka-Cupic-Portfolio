package hr.com.solo.solo.search.models;

// 2017-04-08 Ian Rumac

public class SearchParams {
	public final String query;
	public final Order orderType;
	public final SortBy sortByType;
	public final int page;

	public SearchParams(String query, SortBy sortByType, Order orderType, int page) {
		this.query = query;
		this.orderType = orderType;
		this.sortByType = sortByType;
		this.page = page;
	}
}

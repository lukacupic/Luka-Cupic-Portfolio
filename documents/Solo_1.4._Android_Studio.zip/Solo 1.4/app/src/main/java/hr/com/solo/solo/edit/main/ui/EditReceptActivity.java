package hr.com.solo.solo.edit.main.ui;

import android.content.Intent;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.main.ui.NewReceiptActivity;
import hr.com.solo.solo.models.CreateReceiptBody;
import hr.com.solo.solo.PaymentChoiceActivity;
import hr.com.solo.solo.R;
import hr.com.solo.solo.base.BaseActivity;
import hr.com.solo.solo.core.CoreApplication;
import hr.com.solo.solo.core.UserCatalogManager;
import hr.com.solo.solo.edit.main.EditReceiptContract;
import hr.com.solo.solo.edit.main.di.DaggerEditReceiptComponent;
import hr.com.solo.solo.edit.main.di.EditReceiptModule;
import hr.com.solo.solo.edit.main.ui.adapter.EditReceiptAdapter;
import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.utils.ImageLoader;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;

public class EditReceptActivity extends BaseActivity implements EditReceiptContract.EditReceiptView {
	@Inject
	EditReceiptContract.EditReceiptPresenter presenter;
	@Inject
	ImageLoader loader;
	@Inject
	UserCatalogManager manager;

	@BindView(R.id.recycler_result_list)
	RecyclerView recyclerResultList;
	@BindView(R.id.container_layout)
	FrameLayout containerLayout;
	@BindView(R.id.ic_back)
	ImageView btnBack;
	@BindView(R.id.total)
	TextView total;

	EditReceiptAdapter adapter;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.activity_edit);
		ButterKnife.bind(this);
		DaggerEditReceiptComponent.builder().coreComponent(CoreApplication.getInstance().getComponent()).editReceiptModule(new EditReceiptModule()).build().inject(this);

		btnBack.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				onBackPressed();
			}
		});
		adapter = new EditReceiptAdapter(manager);
		recyclerResultList.setAdapter(adapter);
		RecyclerView.ItemAnimator animator = recyclerResultList.getItemAnimator();
		if (animator instanceof SimpleItemAnimator) {
			((SimpleItemAnimator) animator).setSupportsChangeAnimations(false);
		}
		recyclerResultList.getItemAnimator().setChangeDuration(0);
		recyclerResultList.setItemAnimator(null);

		recyclerResultList.setRecycledViewPool(new RecyclerView.RecycledViewPool() {
			@Override
			public void setMaxRecycledViews(int viewType, int max) {
				super.setMaxRecycledViews(viewType, 20);
			}
		});
		recyclerResultList.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
		super.onCreate(savedInstanceState);
	}

	@Override
	public void showLoading() { }

	@Override
	public void hideLoading() { }

	@Override
	public void displayError(String message) {
		//Toast.makeText(this, R.string.error_msg, Toast.LENGTH_LONG).show();
	}

	@Override
	protected void onStop() {
		presenter.detachView(this);

		super.onStop();
	}

	@Override
	protected void onResume() {
		presenter.attachView(this);
		manager.getBrutoPrice().subscribeOn(AndroidSchedulers.mainThread()).observeOn(AndroidSchedulers.mainThread()).subscribe(new Consumer<String>() {
			@Override
			public void accept(String s) throws Exception {
				total.setText(s.replace(".", ","));
				if ("0.00".equals(s) || "0,00".equals(s))
					finish();
				adapter.notifyTaxesChanged();
			}
		}, Throwable::printStackTrace);

		super.onResume();
	}

	double totalPrice = 0;

	@Override
	public void addNewItems(List<CatalogItem> listItems) {
		adapter.displayEmpty();
		adapter.addItems(new ArrayList<>(manager.getChosenCatalogItems()),
				new View.OnClickListener() {
					@Override
					public void onClick(View view) {
						presenter.createReceiptBody(new ArrayList<>(manager.getChosenCatalogItems()));
					}
				});

		total.setText(manager.getTotalPriceString().replace(".", ","));
	}

	@Override
	public void displayEmpty() { }

	@Override
	public void setupReceipt(CreateReceiptBody body) {
		manager.setLastReceiptBody(body);
		Intent intent = new Intent(this, PaymentChoiceActivity.class);
		intent.putExtra(PaymentChoiceActivity.PRICE, total.getText());
		startActivity(intent);
	}

	@Override
	public void removeItem() { }
}

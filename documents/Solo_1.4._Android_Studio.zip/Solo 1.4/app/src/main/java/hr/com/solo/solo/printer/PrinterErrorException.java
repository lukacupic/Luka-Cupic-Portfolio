package hr.com.solo.solo.printer;

import java.io.IOException;

public class PrinterErrorException extends IOException {

    public PrinterErrorException() {
        super();
    }

    public PrinterErrorException(String message) {
        super(message);
    }
}

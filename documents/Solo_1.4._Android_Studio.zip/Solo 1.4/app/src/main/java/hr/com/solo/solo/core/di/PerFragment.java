package hr.com.solo.solo.core.di;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import javax.inject.Scope;

// 2017-04-08 Ian Rumac

@Scope
@Retention(RetentionPolicy.RUNTIME)
public @interface PerFragment { }
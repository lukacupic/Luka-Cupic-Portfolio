package hr.com.solo.solo.core;

import android.graphics.Typeface;

import androidx.multidex.MultiDexApplication;


import hr.com.solo.solo.BuildConfig;
import hr.com.solo.solo.R;
import hr.com.solo.solo.core.di.CoreComponent;
import hr.com.solo.solo.core.di.CoreModule;
import hr.com.solo.solo.base.RxModule;
import hr.com.solo.solo.core.di.DaggerCoreComponent;

import hr.com.solo.solo.main.ui.NewReceiptActivity;
import hr.com.solo.solo.networking.NetworkModule;
import hr.com.solo.solo.printer.PrinterFactory;
import hr.com.solo.solo.utils.PrefsUtils;
import io.github.inflationx.calligraphy3.CalligraphyConfig;
import io.github.inflationx.calligraphy3.CalligraphyInterceptor;
import io.github.inflationx.viewpump.ViewPump;
import timber.log.Timber;

// 2017-04-08 Ian Rumac
// 2022-11-18 Luka

public class CoreApplication extends MultiDexApplication {
    private static CoreApplication instance;
    private CoreComponent component;

    Typeface LatoRegular;
    Typeface LatoBold;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        component = DaggerCoreComponent.builder()
                .coreModule(new CoreModule(this))
                .networkModule(new NetworkModule())
                .rxModule(new RxModule())
                .build();

        if (BuildConfig.DEBUG) {
            Timber.plant(new Timber.DebugTree());
        }

        ViewPump.init(ViewPump.builder()
                .addInterceptor(new CalligraphyInterceptor(
                        new CalligraphyConfig.Builder()
                                .setDefaultFontPath("fonts/Lato-Light.ttf")
                                .setFontAttrId(R.attr.fontPath)
                                .build()))
                .build());

        LatoBold = Typeface.createFromAsset(getAssets(), "fonts/Lato-Bold.ttf");
        LatoRegular = Typeface.createFromAsset(getAssets(), "fonts/Lato-Regular.ttf");
    }

    public Typeface getLatoRegular() {
        return LatoRegular;
    }

    public Typeface getLatoBold() {
        return LatoBold;
    }

    public CoreComponent getComponent() {
        return component;
    }

    public static CoreApplication getInstance() {
        return instance;
    }
}

package hr.com.solo.solo.navigation;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import androidx.fragment.app.FragmentManager;
import android.view.inputmethod.InputMethodManager;

// 2017-04-09 Ian Rumac

public class RouterImpl implements Router {
	private final Activity activity;
	private final FragmentManager fragmentManager;

	public RouterImpl(final Activity activity, final FragmentManager fragmentManager) {
		this.activity = activity;
		this.fragmentManager = fragmentManager;
	}

	public void hideKeyboardWhenNavigating() {
		try {
			InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
		} catch (NullPointerException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void navigateToUserDetails(String username) {
		hideKeyboardWhenNavigating();
/*
		fragmentManager.beginTransaction()
				.add(R.id.container_layout, UserDetailsFragment.newInstance(username))
				.addToBackStack(username)
				.commit();
*/
	}

	@Override
	public void navigateToRepositoryDetails(String owner, String name) {
		hideKeyboardWhenNavigating();
/*
		fragmentManager.beginTransaction()
				.add(R.id.container_layout, NewReceiptActivity.newInstance(owner, name))
				.addToBackStack(owner.concat(name))
				.commit();
*/
	}

	@Override
	public void goBack() {
		fragmentManager.popBackStack();
	}

	@Override
	public void openLinkInBrowser(String link) {
		activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(link)));
	}

	@Override
	public void clearBackstack() { }
}

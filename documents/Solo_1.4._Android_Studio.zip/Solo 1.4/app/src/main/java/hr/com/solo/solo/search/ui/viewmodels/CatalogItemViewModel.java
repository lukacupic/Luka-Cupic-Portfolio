package hr.com.solo.solo.search.ui.viewmodels;

import androidx.cardview.widget.CardView;

import android.text.SpannableString;
import android.text.Spanned;
import android.view.View;
import android.widget.TextView;

import com.airbnb.epoxy.EpoxyHolder;
import com.airbnb.epoxy.EpoxyModelWithHolder;

import java.text.DecimalFormat;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.R;
import hr.com.solo.solo.core.CoreApplication;
import hr.com.solo.solo.core.UserCatalogManager;
import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.utils.CustomTypefaceSpan;
import hr.com.solo.solo.utils.MathUtils;
import hr.com.solo.solo.utils.OnItemSelected;

// 2017-04-08 Ian Rumac

public class CatalogItemViewModel extends EpoxyModelWithHolder<CatalogItemViewModel.SearchItemViewHolder> {
	String query;
	CatalogItem result;
	OnItemSelected<CatalogItem> itemOnItemSelected;
	final UserCatalogManager manager;
	boolean isSelected = false;
	public void setQuery(String query) {
		this.query = query;
	}

	public CatalogItemViewModel(CatalogItem result, String query, OnItemSelected<CatalogItem> itemOnItemSelected, UserCatalogManager manager) {
		this.itemOnItemSelected = itemOnItemSelected;
		this.result = result;
		this.query = query;
		this.manager = manager;

	}

	public CatalogItemViewModel(CatalogItem result, OnItemSelected<CatalogItem> itemOnItemSelected, UserCatalogManager manager) {
		this.itemOnItemSelected = itemOnItemSelected;
		this.result = result;
		this.manager = manager;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		if (!super.equals(o)) {
			return false;
		}

		CatalogItemViewModel that = (CatalogItemViewModel) o;
		return result != null ? result.equals(that.result) && (manager.getChosenCatalogItems().contains(that.result) && isSelected): that.result == null;
	}

	@Override
	public int hashCode() {
		int result1 = super.hashCode();
		result1 = 31 * result1 + (result != null ? result.hashCode() : 0);
		return result1;
	}

	public String getQuery() {
		return query;
	}

	public CatalogItem getResult() {
		return result;
	}

	@Override
	protected SearchItemViewHolder createNewHolder() {
		return new SearchItemViewHolder();
	}

	@Override
	protected int getDefaultLayout() {
		return R.layout.receipt_list_viewmodel;
	}

	private static final DecimalFormat formatter = new DecimalFormat("#0.00");

	@Override
	public void bind(SearchItemViewHolder holder) {
		holder.parentLayout.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if (manager != null) {
					isSelected = true;
					holder.sideColor.setVisibility(View.VISIBLE);
				}
				itemOnItemSelected.itemSelected(result);
			}
		});
		if (query != null && !query.isEmpty()) {
			int positionStart = result.getDescription().toLowerCase().indexOf(query.toLowerCase());
			int positionEnd = positionStart + query.length();
			String description = result.getDescription();
			try {
				SpannableString span = new SpannableString(result.getDescription());
				span.setSpan(new CustomTypefaceSpan("", CoreApplication.getInstance().getLatoBold()), positionStart, positionEnd, Spanned.SPAN_EXCLUSIVE_INCLUSIVE);
				holder.description.setText(span);
			} catch (Exception e) {
				holder.description.setText(result.getDescription());
			}
		} else {
			holder.description.setText(result.getDescription());
		}
		holder.unitNumber.setText(formatter.format(Double.valueOf(result.getAmount().replace(",", "."))).replace(".", ","));
		holder.unitNumber.setText(result.getAmount());

		if (!Double.valueOf(result.getDiscount().replace(",", ".")).equals(0.0)) {
			holder.discount.setText(result.getDiscount() + "%");
		} else {
			holder.discount.setText("");
		}
		if (manager != null && manager.getChosenCatalogItems().contains(result)) {
			isSelected = true;
			holder.sideColor.setVisibility(View.VISIBLE);
		} else {
			isSelected = false;
			holder.sideColor.setVisibility(View.INVISIBLE);
		}

		holder.unit.setText((" ").concat(result.getAmountUnit()));
		holder.price.setText(MathUtils.getPriceForItemString(result).replace(".", ","));
	}

	static class SearchItemViewHolder extends EpoxyHolder {
		@BindView(R.id.unit)
		TextView unit;
		@BindView(R.id.price)
		TextView price;
		@BindView(R.id.description)
		TextView description;
		@BindView(R.id.parent_layout)
		CardView parentLayout;
		@BindView(R.id.discount)
		TextView discount;
		@BindView(R.id.unit_number)
		TextView unitNumber;
		@BindView(R.id.side_color_selector)
		View sideColor;

		@Override
		protected void bindView(View itemView) {
			ButterKnife.bind(this, itemView);
		}
	}
}

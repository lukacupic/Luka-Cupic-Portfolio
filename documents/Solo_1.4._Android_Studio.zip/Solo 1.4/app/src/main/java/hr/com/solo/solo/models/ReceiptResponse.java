package hr.com.solo.solo.models;

import java.util.List;

// 2017-05-01 Ian Rumac
// 2020-12-17 Farhad Bhuiyan (QR code)

public class ReceiptResponse {
	/**
	 * status : 0
	 * racun : {"id":"8791cae3c9b02bb8d88bf626247b4e67dfbe20e35fc0342b448f39c9264c591d","broj_racuna":"1-1-1","tip_usluge":"1","prikazi_porez":"1","tip_racuna":"R1","kupac_naziv":"COAX d.o.o.","kupac_adresa":"Kralja Držislava 4, 10000 Zagreb","kupac_oib":"58981111611","usluge":[{"broj":"1","opis_usluge":"Kruške","jed_mjera":"kom","kolicina":"1","cijena":"9,99","popust":"0","porez_stopa":"25","suma":"9,99"},{"broj":"2","opis_usluge":"Jabuke","jed_mjera":"kom","kolicina":"2","cijena":"5,00","popust":"0","porez_stopa":"25","suma":"10,00"}],"neto_suma":"19,99","porezi":[{"stopa":"25","osnovica":"19,99","porez":"5,00"}],"bruto_suma":"24,99","nacin_placanja":"1","operater":"Ime Prezime","racun_izdao":"Ime Prezime","likvidator":"Ime Prezime","datum_racuna":"1.8.2016. 13:00:00","rok_placanja":"","datum_isporuke":"1.8.2016","napomene":"Hvala","ponavljanje":"0","iban":"HR3823400091160392212","jezik_racuna":"1","valuta_racuna":"HRK","tecaj":"1","status":"1","boja":"#ffcf03","zki":"e4d909c290d0fb1ca068ffaddf22cbd0","jir":"2cf55235-9470-4b5c-a539-463f52b109d2","pdf":"https://solo.com.hr/download/8791cae3c9b02bb8d88bf626247b4e67dfbe20e35fc0342b448f39c9264c591d"}
	 * message : Račun uspješno kreiran.
	 */

	private int status;
	private RacunBean racun;
	private String message;

	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}

	public RacunBean getRacun() { return racun; }
	public void setRacun(RacunBean racun) {
		this.racun = racun;
	}

	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	public static class RacunBean {
		/**
		 * id : 8791cae3c9b02bb8d88bf626247b4e67dfbe20e35fc0342b448f39c9264c591d
		 * broj_racuna : 1-1-1
		 * tip_usluge : 1
		 * prikazi_porez : 1
		 * tip_racuna : R1
		 * kupac_naziv : COAX d.o.o.
		 * kupac_adresa : Kralja Držislava 4, 10000 Zagreb
		 * kupac_oib : 58981111611
		 * usluge : [{"broj":"1","opis_usluge":"Kruške","jed_mjera":"kom","kolicina":"1","cijena":"9,99","popust":"0","porez_stopa":"25","suma":"9,99"},{"broj":"2","opis_usluge":"Jabuke","jed_mjera":"kom","kolicina":"2","cijena":"5,00","popust":"0","porez_stopa":"25","suma":"10,00"}]
		 * neto_suma : 19,99
		 * porezi : [{"stopa":"25","osnovica":"19,99","porez":"5,00"}]
		 * bruto_suma : 24,99
		 * nacin_placanja : 1
		 * operater : Ime Prezime
		 * racun_izdao : Ime Prezime
		 * likvidator : Ime Prezime
		 * datum_racuna : 1.8.2016. 13:00:00
		 * rok_placanja :
		 * datum_isporuke : 1.8.2016
		 * napomene : Hvala
		 * ponavljanje : 0
		 * iban : HR3823400091160392212
		 * jezik_racuna : 1
		 * valuta_racuna : HRK
		 * tecaj : 1
		 * status : 1
		 * boja : #ffcf03
		 * zki : e4d909c290d0fb1ca068ffaddf22cbd0
		 * jir : 2cf55235-9470-4b5c-a539-463f52b109d2
		 * qr : https://porezna.gov.hr/rn?zki=e4d909c290d0fb1ca068ffaddf22cbd0&datv=20201203_1629&izn=12500
		 * pdf : https://solo.com.hr/download/8791cae3c9b02bb8d88bf626247b4e67dfbe20e35fc0342b448f39c9264c591d
		 */

		private String id;
		private String broj_racuna;
		private String tip_usluge;
		private String prikazi_porez;
		private String tip_racuna;
		private String kupac_naziv;
		private String kupac_adresa;
		private String kupac_oib;
		private String neto_suma;
		private String bruto_suma;
		private String nacin_placanja;
		private String operater;
		private String racun_izdao;
		private String likvidator;
		private String datum_racuna;
		private String rok_placanja;
		private String datum_isporuke;
		private String napomene;
		private String ponavljanje;
		private String iban;
		private String jezik_racuna;
		private String valuta_racuna;
		private String tecaj;
		private String status;
		private String boja;
		private String zki;
		private String jir;
		private String qr;
		private String pdf;
		private List<UslugeBean> usluge;
		private List<PoreziBean> porezi;

		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}

		public String getBroj_racuna() {
			return broj_racuna;
		}
		public void setBroj_racuna(String broj_racuna) {
			this.broj_racuna = broj_racuna;
		}

		public String getTip_usluge() { return tip_usluge; }
		public void setTip_usluge(String tip_usluge) {
			this.tip_usluge = tip_usluge;
		}

		public String getPrikazi_porez() {
			return prikazi_porez;
		}
		public void setPrikazi_porez(String prikazi_porez) {
			this.prikazi_porez = prikazi_porez;
		}

		public String getTip_racuna() {
			return tip_racuna;
		}
		public void setTip_racuna(String tip_racuna) {
			this.tip_racuna = tip_racuna;
		}

		public String getKupac_naziv() {
			return kupac_naziv;
		}
		public void setKupac_naziv(String kupac_naziv) {
			this.kupac_naziv = kupac_naziv;
		}

		public String getKupac_adresa() {
			return kupac_adresa;
		}
		public void setKupac_adresa(String kupac_adresa) {
			this.kupac_adresa = kupac_adresa;
		}

		public String getKupac_oib() {
			return kupac_oib;
		}
		public void setKupac_oib(String kupac_oib) {
			this.kupac_oib = kupac_oib;
		}

		public String getNeto_suma() {
			return neto_suma;
		}
		public void setNeto_suma(String neto_suma) {
			this.neto_suma = neto_suma;
		}

		public String getBruto_suma() {
			return bruto_suma;
		}
		public void setBruto_suma(String bruto_suma) {
			this.bruto_suma = bruto_suma;
		}

		public String getNacin_placanja() {
			return nacin_placanja;
		}
		public void setNacin_placanja(String nacin_placanja) {
			this.nacin_placanja = nacin_placanja;
		}

		public String getOperater() {
			return operater;
		}
		public void setOperater(String operater) {
			this.operater = operater;
		}

		public String getRacun_izdao() {
			return racun_izdao;
		}
		public void setRacun_izdao(String racun_izdao) {
			this.racun_izdao = racun_izdao;
		}

		public String getLikvidator() {
			return likvidator;
		}
		public void setLikvidator(String likvidator) {
			this.likvidator = likvidator;
		}

		public String getDatum_racuna() {
			return datum_racuna;
		}
		public void setDatum_racuna(String datum_racuna) {
			this.datum_racuna = datum_racuna;
		}

		public String getRok_placanja() {
			return rok_placanja;
		}
		public void setRok_placanja(String rok_placanja) {
			this.rok_placanja = rok_placanja;
		}

		public String getDatum_isporuke() {
			return datum_isporuke;
		}
		public void setDatum_isporuke(String datum_isporuke) {
			this.datum_isporuke = datum_isporuke;
		}

		public String getNapomene() {
			return napomene;
		}
		public void setNapomene(String napomene) {
			this.napomene = napomene;
		}

		public String getPonavljanje() {
			return ponavljanje;
		}
		public void setPonavljanje(String ponavljanje) {
			this.ponavljanje = ponavljanje;
		}

		public String getIban() {
			return iban;
		}
		public void setIban(String iban) {
			this.iban = iban;
		}

		public String getJezik_racuna() {
			return jezik_racuna;
		}
		public void setJezik_racuna(String jezik_racuna) {
			this.jezik_racuna = jezik_racuna;
		}

		public String getValuta_racuna() {
			return valuta_racuna;
		}
		public void setValuta_racuna(String valuta_racuna) {
			this.valuta_racuna = valuta_racuna;
		}

		public String getTecaj() {
			return tecaj;
		}
		public void setTecaj(String tecaj) {
			this.tecaj = tecaj;
		}

		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}

		public String getBoja() {
			return boja;
		}
		public void setBoja(String boja) {
			this.boja = boja;
		}

		public String getZki() {
			return zki;
		}
		public void setZki(String zki) {
			this.zki = zki;
		}

		public String getJir() {
			return jir;
		}
		public void setJir(String jir) {
			this.jir = jir;
		}

		public String getQr() {
			return qr;
		}
		public void setQr(String qr) {
			this.qr = qr;
		}

		public String getPdf() { return pdf; }
		public void setPdf(String pdf) {
			this.pdf = pdf;
		}

		public List<UslugeBean> getUsluge() {
			return usluge;
		}
		public void setUsluge(List<UslugeBean> usluge) {
			this.usluge = usluge;
		}

		public List<PoreziBean> getPorezi() {
			return porezi;
		}
		public void setPorezi(List<PoreziBean> porezi) {
			this.porezi = porezi;
		}

		public static class UslugeBean {
			/**
			 * broj : 1
			 * opis_usluge : Kruške
			 * jed_mjera : kom
			 * kolicina : 1
			 * cijena : 9,99
			 * popust : 0
			 * porez_stopa : 25
			 * suma : 9,99
			 */

			private String broj;
			private String opis_usluge;
			private String jed_mjera;
			private String kolicina;
			private String cijena;
			private String popust;
			private String porez_stopa;
			private String suma;

			public String getBroj() {
				return broj;
			}
			public void setBroj(String broj) {
				this.broj = broj;
			}

			public String getOpis_usluge() {
				return opis_usluge;
			}
			public void setOpis_usluge(String opis_usluge) {
				this.opis_usluge = opis_usluge;
			}

			public String getJed_mjera() {
				return jed_mjera;
			}
			public void setJed_mjera(String jed_mjera) {
				this.jed_mjera = jed_mjera;
			}

			public String getKolicina() {
				return kolicina;
			}
			public void setKolicina(String kolicina) {
				this.kolicina = kolicina;
			}

			public String getCijena() {
				return cijena;
			}
			public void setCijena(String cijena) {
				this.cijena = cijena;
			}

			public String getPopust() {
				return popust;
			}
			public void setPopust(String popust) {
				this.popust = popust;
			}

			public String getPorez_stopa() {
				return porez_stopa;
			}
			public void setPorez_stopa(String porez_stopa) {
				this.porez_stopa = porez_stopa;
			}

			public String getSuma() {
				return suma;
			}
			public void setSuma(String suma) {
				this.suma = suma;
			}
		}

		public static class PoreziBean {
			/**
			 * stopa : 25
			 * osnovica : 19,99
			 * porez : 5,00
			 */

			private String stopa;
			private String osnovica;
			private String porez;

			public String getStopa() {
				return stopa;
			}
			public void setStopa(String stopa) {
				this.stopa = stopa;
			}

			public String getOsnovica() {
				return osnovica;
			}
			public void setOsnovica(String osnovica) {
				this.osnovica = osnovica;
			}

			public String getPorez() {
				return porez;
			}
			public void setPorez(String porez) {
				this.porez = porez;
			}
		}
	}
}

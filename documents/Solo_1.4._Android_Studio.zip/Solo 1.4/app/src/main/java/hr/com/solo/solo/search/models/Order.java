package hr.com.solo.solo.search.models;

// 2017-04-08 Ian Rumac

public enum Order {
	ASCENDING("asc"),
	DESCENDING("desc");

	private final String type;

	Order(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}
}

package hr.com.solo.solo.printreceipt;

import androidx.lifecycle.ViewModel;

public class PrintReceiptViewModel extends ViewModel {

}

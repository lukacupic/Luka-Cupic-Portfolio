package hr.com.solo.solo.archive.list.repositories;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import hr.com.solo.solo.archive.list.source.GetReceiptsNetworkSource;
import hr.com.solo.solo.archive.search.network.ReceiptItemListResponseWrapper;
import hr.com.solo.solo.archive.search.network.ReceiptResponseItem;
import hr.com.solo.solo.core.UserReceiptManager;
import io.reactivex.Scheduler;
import io.reactivex.Single;

// 2017-04-09 Ian Rumac

public class ReceiptArchiveRepositoryImpl implements ReceiptArchiveRepository {
	UserReceiptManager dataSource;
	GetReceiptsNetworkSource network;
	Scheduler executionScheduler;

	@Inject
	public ReceiptArchiveRepositoryImpl(GetReceiptsNetworkSource network, UserReceiptManager dataSource, @Named("io") Scheduler execution) {
		this.network = network;
		this.dataSource = dataSource;
		this.executionScheduler = execution;
	}

	@Override
	public Single<ReceiptItemListResponseWrapper> fetchReceipts(String token) {
		return network.getReceipts(token).doAfterSuccess( wrapper ->dataSource.setCatalogItems(wrapper.itemList));
	}
}

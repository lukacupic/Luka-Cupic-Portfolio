package hr.com.solo.solo.archive.list.ui;

import android.content.Intent;
import android.os.Bundle;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.R;
import hr.com.solo.solo.archive.list.ReceiptArchiveContract;
import hr.com.solo.solo.archive.list.di.DaggerReceiptArchiveComponent;
import hr.com.solo.solo.archive.list.di.ReceiptArchiveModule;
import hr.com.solo.solo.archive.list.ui.adapter.ReceiptArchiveEpoxyAdapter;
import hr.com.solo.solo.archive.search.network.ReceiptResponseItem;
import hr.com.solo.solo.archive.search.ui.ReceiptSearchActivity;
import hr.com.solo.solo.base.BaseActivity;
import hr.com.solo.solo.core.CoreApplication;
import hr.com.solo.solo.utils.ImageLoader;
import hr.com.solo.solo.utils.PrefsUtils;

public class ReceiptArchiveActivity extends BaseActivity implements ReceiptArchiveContract.ReceiptArchiveView {
	@Inject ReceiptArchiveContract.ReceiptArchivePresenter presenter;
	@Inject ImageLoader loader;

	@BindView(R.id.recycler_result_list) RecyclerView recyclerResultList;
	@BindView(R.id.container_layout) FrameLayout containerLayout;
	@BindView(R.id.search_button) ImageView search;
	@BindView(R.id.ic_back) ImageView backBtn;

	@BindView(R.id.swipe_refresh)
	SwipeRefreshLayout swipeRefreshLayout;

	LinearLayout menu;
	ReceiptArchiveEpoxyAdapter adapter;
	@BindView(R.id.progress_bar)
	ProgressBar progressBar;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.activity_archive);
		ButterKnife.bind(this);
		DaggerReceiptArchiveComponent.builder().coreComponent(CoreApplication.getInstance().getComponent())
				.receiptArchiveModule(new ReceiptArchiveModule()).build().inject(this);

		adapter = new ReceiptArchiveEpoxyAdapter();
		backBtn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				onBackPressed();
			}
		});
		swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
			@Override
			public void onRefresh() {
				PrefsUtils.clearReceiptLastDownload();
				presenter.getReceiptList(PrefsUtils.getToken(), true);
			}
		});

		presenter.attachView(this);
		presenter.getReceiptList(PrefsUtils.getToken(), false);

		recyclerResultList.setAdapter(adapter);
		recyclerResultList.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
		search.setOnClickListener(view -> startActivity(new Intent(ReceiptArchiveActivity.this, ReceiptSearchActivity.class)));
		super.onCreate(savedInstanceState);
	}

	@Override
	public void showLoading() {
		progressBar.setVisibility(View.VISIBLE);
		progressBar.setVisibility(View.GONE);
	}

	@Override
	public void hideLoading() { }

	@Override
	public void displayError(String message) {
		showErrorWith(message);
	}

    @Override
    protected void onDestroy() {
	    presenter.detachView(this);
        super.onDestroy();
    }

	@Override
	public void displayReceipts(List<ReceiptResponseItem> receiptResponseItemList) {
			swipeRefreshLayout.setRefreshing(false);
			adapter.clearAndAddNewModels(receiptResponseItemList,"",item -> {});
			recyclerResultList.scrollToPosition(0);
	}

	@Override
	public void displayEmpty() { }

	@Override
	public void removeItem() { }
}

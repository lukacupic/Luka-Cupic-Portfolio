package hr.com.solo.solo.utils;

import android.content.Context;

import com.google.gson.Gson;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import hr.com.solo.solo.archive.search.network.ReceiptItemListResponseWrapper;
import hr.com.solo.solo.core.CoreApplication;
import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.models.ReceiptResponse;
import hr.com.solo.solo.search.models.network.ItemListResponseWrapper;

// 2017-04-22 Ian Rumac
// 2022-11-16 Luka

public class PrefsUtils {
    public static final String PREFS_FILE = "prefs";
    public static final String CATALOG_SAVETIME = "catalog-save-time";

    public static final String RECEIPT_CATALOG_SAVETIME = "receipt-catalog-save-time";
    public static final String CATALOG = "catalog";
    public static final String RECEIPT_CATALOG = "receipt-catalog";

    public static final String TOKEN = "token";
    public static final String FISCAL = "fiscal";

    public static boolean isFiscalEnabled() {
        String fiscal = CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
                .getString(FISCAL, "0");

        return !fiscal.equals("0");
    }

    public static String getFiscal() {
        return CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
                .getString(FISCAL, "0");
    }

    public static void setFiscalEnabled(boolean enabled) {
        String value = "0";
        if (enabled) {
            value = "1";
        }
        CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).edit().putString(FISCAL, value).commit();
    }

    public static List<CatalogItem> returnCatalogItems() {
        return new Gson().fromJson(CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
                .getString(CATALOG, ""), ItemListResponseWrapper.class).itemList;
    }

    public static long returnLastDownload() {
        return CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
                .getLong(CATALOG_SAVETIME, 0);
    }

    public static void logout() {
        CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).edit().clear().commit();
    }

    public static void clearToken() {
        saveToken(null);
    }

    public static void saveToken(String token) {
        CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
                .edit().putString(TOKEN, token).commit();
    }

    public static String getToken() {
        return CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
                .getString(TOKEN, "");
    }

    public static void saveData(ItemListResponseWrapper wrapper) {
        String json = new Gson().toJson(wrapper);
        CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).edit().putString(CATALOG, json).commit();
        CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).edit().putLong(CATALOG_SAVETIME, System.currentTimeMillis()).commit();
    }

    public static void clearCacheTimestamp() {
        CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).edit().putLong(CATALOG_SAVETIME, 0).commit();
    }

    public static void saveData(ReceiptItemListResponseWrapper wrapper) {
        String json = new Gson().toJson(wrapper);
        CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).edit().putString(RECEIPT_CATALOG, json).commit();
        CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).edit().putLong(RECEIPT_CATALOG_SAVETIME, System.currentTimeMillis()).commit();
    }

    public static final String RECEIPT = "receipt";

    public static void saveReceipt(ReceiptResponse response) {
        CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).edit().putString(RECEIPT, new Gson().toJson(response)).commit();
    }

    public static ReceiptResponse getReceipt() {
        return new Gson().fromJson(CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).getString(RECEIPT, ""), ReceiptResponse.class);
    }

    public static final String PRINTER_MAC = "printer-mac";
    public static final String PRINTER_name = "printer-name";
    public static final String PRINTER_type = "printer-type";
    public static final String PRINTER_retailer = "printer-retailer";

    public static void savePrinter(String printer, String name, int type, String retailer) {
        CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).edit().putString(PRINTER_MAC, printer).commit();
        CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).edit().putString(PRINTER_name, name).commit();
        CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).edit().putInt(PRINTER_type, type).commit();
        CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).edit().putString(PRINTER_retailer, retailer).commit();
    }

    public static String getPrinterMac() {
        return CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).getString(PRINTER_MAC, "");
    }

    public static String getPrinterName() {
        return CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).getString(PRINTER_name, "");
    }

    public static int getPrinterType() {
        return CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).getInt(PRINTER_type, 0);
    }

    public static String getPrinterRetailer() {
        return CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).getString(PRINTER_retailer, "");
    }

    public static ReceiptItemListResponseWrapper returnReceiptCatalogItems() {
        return new Gson().fromJson(CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
                .getString(RECEIPT_CATALOG, ""), ReceiptItemListResponseWrapper.class);
    }

    public static long returnReceiptLastDownload() {
        return CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
                .getLong(RECEIPT_CATALOG_SAVETIME, 0);
    }

    public static void clearReceiptLastDownload() {
        CoreApplication.getInstance().getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE).edit()
                .putLong(RECEIPT_CATALOG_SAVETIME, 0).commit();
    }

}

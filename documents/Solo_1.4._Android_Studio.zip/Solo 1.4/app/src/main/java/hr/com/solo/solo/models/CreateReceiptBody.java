package hr.com.solo.solo.models;

import java.util.LinkedHashMap;

import hr.com.solo.solo.utils.PrefsUtils;
import okhttp3.FormBody;
import okhttp3.RequestBody;

// 2017-05-01 Ian Rumac

public class CreateReceiptBody {
	LinkedHashMap<String, String> itemMap = new LinkedHashMap<>();
	FormBody.Builder body = new FormBody.Builder();
	RequestBody requestBody;
	public void put(String key, String value) {
		body.add(key,value);
	}

	public CreateReceiptBody() {
		body.add("token", PrefsUtils.getToken());
		body.add("fiskalizacija", PrefsUtils.getFiscal());
		body.add("pos","1");
		body.add("tip_usluge","0");
	}

	public void finish(int payment){
		body.add("nacin_placanja",String.valueOf(payment));
		body.add("prikazi_porez","1");
		body.add("tip_racuna","1");
		requestBody = body.build();
	}

	public RequestBody getRequestBody() {
		return requestBody;
	}
}

package hr.com.solo.solo.printer;

// 2017-07-16 Haris Kovacevic
// 2022-11-14 Luka

public interface IPrinter {

    void connectPrinter(String address, String name);

    void printInvoice(Object invoice, Object qrCode);

    void disconnectPrinter();

    boolean isConnected();

    void setConnected(boolean isConnected);

    void setPrinterStatusCallback(PrinterStatusCallback callback);
}
package hr.com.solo.solo.main.source;

import com.google.gson.Gson;
import java.util.List;

import hr.com.solo.solo.main.mappers.NewReceiptResponseMapper;
import hr.com.solo.solo.networking.SoloService;
import hr.com.solo.solo.main.models.CatalogItem;

import javax.inject.Inject;

import hr.com.solo.solo.search.models.network.ItemListResponseWrapper;
import io.reactivex.Single;

// 2017-04-09 Ian Rumac

public class NewReceiptNetworkSourceImpl implements NewReceiptNetworkSource {
	SoloService apiService;
	NewReceiptResponseMapper mapper;

	@Inject
	public NewReceiptNetworkSourceImpl(SoloService apiService, NewReceiptResponseMapper mapper) {
		this.apiService = apiService;
		this.mapper = mapper;
	}

	@Override
	public Single<ItemListResponseWrapper> getCatalog(String token) {
		return apiService.getItemsForUser(token);
	}
}

package hr.com.solo.solo.utils;

import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.util.Log;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.text.DecimalFormat;

import hr.com.solo.solo.main.models.CatalogItem;

// 2017-05-11 Ian Rumac
// 2022-11-18 Luka

public class MathUtils {
    private static final DecimalFormat df = new DecimalFormat("#0.00");

    public static BigDecimal roundUp(String number, int dec) {
        BigDecimal decimal = new BigDecimal(number.replace(",", "."));

        int len = number.length() - number.indexOf(".") - 1;

        if (len > 1) {
            for (int i = len; i >= 2; i--) {
                decimal = decimal.setScale(i, BigDecimal.ROUND_HALF_UP);
            }

        } else if (len == 1) {
            return decimal.setScale(2);
        }
        return decimal;
    }

    public static String getDiscountedPrice(String price, String discount) {
        if (Double.valueOf(discount.replace(",", ".")).equals(0.0d)) {
            return df.format(Double.valueOf(price.replace(",", ".")));
        }
        double discountAmount = Double.parseDouble(price.replace(",", ".")) * (Double.parseDouble(discount.replace(",", ".")) / 100);
        discountAmount = MathUtils.roundUp(String.valueOf(discountAmount), 2).doubleValue();
        return df.format(Double.parseDouble(price.replace(",", ".")) - (discountAmount));
    }

    public static String getPriceForItemString(CatalogItem result) {
        return MathUtils.getBrutoPriceString(MathUtils.getDiscountedPrice(result.getPrice(), result.getDiscount()), result.getTax());
    }

    public static Double getPriceForItemSet(CatalogItem item) {
        return MathUtils.roundUp(String.valueOf(Double.parseDouble(MathUtils.getDiscountedPrice(item.getPriceValid(),
                item.getDiscount().replace(",", ".")).replace(",", ".")) * Double.parseDouble(item.getAmount().replace(",", ".")))
                .replace(",", "."), 2).doubleValue();
    }

    public static Double getBrutoPriceForItemSet(CatalogItem item) {
        return MathUtils.roundUp(getBrutoPriceString(String.valueOf(getPriceForItemSet(item)), item.getTax()), 2).doubleValue();
    }

    public static Double getBrutoPrice(String price, String tax) {
        double taxAmount = Double.parseDouble(price.replace(",", ".")) * (Double.parseDouble(tax.replace(",", ".")) / 100);
        taxAmount = MathUtils.roundUp(String.valueOf(taxAmount), 2).doubleValue();
        return MathUtils.roundUp(String.valueOf(Double.parseDouble(price.replace(",", ".")) + taxAmount), 2).doubleValue();
    }

    public static String getBrutoPriceString(String price, String tax) {
        return df.format(getBrutoPrice(price, tax));
    }

    public static float convertDpToPixel(float dp) {
        DisplayMetrics metrics = Resources.getSystem().getDisplayMetrics();
        float px = dp * (metrics.densityDpi / 160f);
        return Math.round(px);
    }
}

package hr.com.solo.solo.search;

import hr.com.solo.solo.R;
import hr.com.solo.solo.core.CoreApplication;
import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.search.interactors.AddItemUseCase;
import hr.com.solo.solo.search.interactors.SearchRepositoriesUseCase;

import java.net.UnknownHostException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;
import javax.inject.Named;

import io.reactivex.Observable;
import io.reactivex.Scheduler;

// 2017-04-08 Ian Rumac

public class SearchPresenter implements SearchContract.SearchPresenter {
	private SearchContract.SearchView view;
	private final AddItemUseCase addItemUseCase;
	private final SearchRepositoriesUseCase useCase;
	private final Scheduler postExecution;
	final int THROTTLE = 400;

	@Inject
	public SearchPresenter(SearchRepositoriesUseCase useCase, AddItemUseCase addItemUseCase,
						   @Named("post_execution") Scheduler postExecution) {
		this.postExecution = postExecution;
		this.useCase = useCase;
		this.addItemUseCase = addItemUseCase;
	}

	@Override
	public void attachView(SearchContract.SearchView view) {
		this.view = view;

		filterAndExecute(view.getSearchObservable())
				.subscribe(this::displayResults, this::handleError);
	}

	private Observable<List<CatalogItem>> filterAndExecute(Observable<String> params) {
		return params
				.debounce(THROTTLE, TimeUnit.MILLISECONDS)
				.flatMap(useCase::executeWithParams)
				.observeOn(postExecution);
	}

	private void displayResults(List<CatalogItem> results) {
		if (results.isEmpty()) {
			view.displayEmpty();
		} else {
			view.displayResults(results);
			view.hideLoading();
		}
	}

	@Override
	public void addItemToBasket(CatalogItem item) {
		addItemUseCase.executeWithParams(item,bool -> {
			view.done();
		}, this::handleError);
	}

	@Override
	public void handleError(Throwable throwable) {
		if (throwable instanceof UnknownHostException) {
			view.displayError(CoreApplication.getInstance().getString(R.string.api_ded));
		} else {
			view.displayError(CoreApplication.getInstance().getString(R.string.conn_error));
		}
	}

	@Override
	public void detachView(SearchContract.SearchView view) {
		this.view = null;
	}
}

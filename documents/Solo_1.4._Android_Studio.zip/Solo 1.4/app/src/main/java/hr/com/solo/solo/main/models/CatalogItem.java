package hr.com.solo.solo.main.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import hr.com.solo.solo.search.models.Owner;
import hr.com.solo.solo.utils.MathUtils;

// 2017-04-09 Ian Rumac

public class CatalogItem implements Serializable {
	/**
	 * sifra : 0001
	 * opis : Jabuke
	 * jed_mjera : kg
	 * kolicina : 1
	 * cijena : 7,00
	 * popust : 0
	 * porez_stopa : 25
	 */

	@SerializedName("sifra") private String id;
	@SerializedName("opis") private String description;
	@SerializedName("jed_mjera") private String amountUnit;
	@SerializedName("kolicina") private final String defaultAmount;
	private String amount;
	@SerializedName("cijena") private String price;
	@SerializedName("popust") private String discount;
	@SerializedName("porez_stopa") private String tax;
	public CatalogItem(String id, String description, String amountUnit, String amount, String defaultAmount, String price, String discount, String tax) {
		this.id = id;
		this.description = description;
		this.amountUnit = amountUnit;
		this.amount = amount;
		this.defaultAmount = defaultAmount;
		this.price = price;
		this.discount = discount;
		this.tax = tax;
	}

	public String getId() { return id; }
	public void setId(String id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	public String getAmountUnit() {
		return amountUnit;
	}
	public void setAmountUnit(String amountUnit) {
		this.amountUnit = amountUnit;
	}
	public String getDefaultAmount() {
		return defaultAmount;
	}
	public String getAmount() {
		if(amount==null|| amount.isEmpty())
			amount = defaultAmount;
		return amount;
	}
	public String getAmountParsable(){
		return amount.replace(",",".");
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getPrice() {
		return price;
	}
	public String getPriceValid() {
		return price.replace(",",".");
	}
	public void setPrice(String price) {
		this.price = price;
	}

	public String getDiscount() {
		return discount;
	}
	public void setDiscount(String discount) {
		this.discount = discount;
	}

	public String getTax() {
		return tax;
	}
	public void setTax(String tax) {
		this.tax = tax;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		CatalogItem that = (CatalogItem) o;
		return(that.getHashedValue().equals(this.getHashedValue()));
	}

	public String getHashedValue(){
		MessageDigest messageDigest = null;
		try {
			messageDigest = MessageDigest.getInstance("SHA-256");
			messageDigest.update(description.concat(defaultAmount).getBytes());
			return  new String(messageDigest.digest());

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return String.valueOf(hashCode());
		}
	}

	@Override
	public int hashCode() {
		int result = description.hashCode();
		result = 31 * result + defaultAmount.hashCode();
		return result;
	}
}

package hr.com.solo.solo.archive.search.ui.adapters;

import java.util.List;

import hr.com.solo.solo.archive.search.network.ReceiptResponseItem;
import hr.com.solo.solo.utils.OnItemSelected;

// 2017-04-10 Ian Rumac

public interface ReceiptSearchResultsAdapter {
	void clearAndAddNewModels(List<ReceiptResponseItem> githubRepositories, String query, OnItemSelected<ReceiptResponseItem> itemSelected);
	void addModels(List<ReceiptResponseItem> githubRepositories, String query, OnItemSelected<ReceiptResponseItem> itemSelected);
}

package hr.com.solo.solo.main.repositories;

import hr.com.solo.solo.main.models.CatalogItem;

import hr.com.solo.solo.search.models.network.ItemListResponseWrapper;
import io.reactivex.Single;

// 2017-04-10 Ian Rumac

public interface CatalogDetailsRepository {
	Single<ItemListResponseWrapper> fetchCatalog(String token);
}

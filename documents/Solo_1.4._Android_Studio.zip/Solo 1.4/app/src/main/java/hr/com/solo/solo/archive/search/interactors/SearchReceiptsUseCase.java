package hr.com.solo.solo.archive.search.interactors;

import java.util.List;

import javax.inject.Inject;

import hr.com.solo.solo.archive.search.network.ReceiptResponseItem;
import hr.com.solo.solo.archive.search.repositories.ReceiptSearchRepositoryInterface;
import hr.com.solo.solo.base.UseCase;
import io.reactivex.Observable;

// 2017-04-08 Ian Rumac

public class SearchReceiptsUseCase extends UseCase<List<ReceiptResponseItem>, String> {
	private final ReceiptSearchRepositoryInterface repository;

	@Inject
	public SearchReceiptsUseCase(ReceiptSearchRepositoryInterface repository) {
		this.repository = repository;
	}

	@Override
	public Observable<List<ReceiptResponseItem>> executeWithParams(String query) {
		return repository.getItemsByQuery(query);
	}
}

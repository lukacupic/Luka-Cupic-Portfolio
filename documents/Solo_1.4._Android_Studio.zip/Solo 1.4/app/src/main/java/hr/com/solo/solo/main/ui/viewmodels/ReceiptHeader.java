package hr.com.solo.solo.main.ui.viewmodels;

import android.view.View;
import android.widget.TextView;

import com.airbnb.epoxy.EpoxyAdapter;
import com.airbnb.epoxy.EpoxyHolder;
import com.airbnb.epoxy.EpoxyModelWithHolder;

import java.math.BigInteger;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.R;
import hr.com.solo.solo.utils.OnItemSelected;

// 2017-04-21 Ian Rumac

public class ReceiptHeader extends EpoxyModelWithHolder<ReceiptHeader.ReceiptHeaderHolder>{
	double price;
	OnItemSelected<Boolean> onItemSelected;
	public ReceiptHeader(double price, OnItemSelected<Boolean> onItemSelected) {
		this.price = price;
		this.onItemSelected = onItemSelected;
	}

	@Override
	protected ReceiptHeaderHolder createNewHolder() {
		return new ReceiptHeaderHolder();
	}

	@Override
	public void bind(ReceiptHeaderHolder holder) {
		holder.total.setText(String.valueOf(price).concat("kn"));
		holder.total.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				onItemSelected.itemSelected(true);
			}
		});
	}

	@Override
	protected int getDefaultLayout() {
		return R.layout.list_header;
	}

	static class ReceiptHeaderHolder extends EpoxyHolder{
		@BindView(R.id.total)
		TextView total;
		@Override
		protected void bindView(View itemView) {
			ButterKnife.bind(this,itemView);
		}
	}
}

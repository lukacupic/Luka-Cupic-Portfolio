package hr.com.solo.solo.edit.main.ui.viewmodels;

import androidx.cardview.widget.CardView;
import android.view.View;

import com.airbnb.epoxy.EpoxyHolder;
import com.airbnb.epoxy.EpoxyModelWithHolder;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.R;

// 2017-04-21 Ian Rumac

public class ReceiptButton extends EpoxyModelWithHolder<ReceiptButton.ReceiptButtonHolder>{
	View.OnClickListener clickListener;
	public ReceiptButton(View.OnClickListener clickListener) {
		this.clickListener = clickListener;
	}

	@Override
	protected ReceiptButtonHolder createNewHolder() {
		return new ReceiptButtonHolder();
	}

	@Override
	public void bind(ReceiptButtonHolder holder) {
		holder.parent.setOnClickListener(clickListener);
	}

	@Override
	protected int getDefaultLayout() {
		return R.layout.edit_receipt_list_button;
	}

	static class ReceiptButtonHolder extends EpoxyHolder{
		@BindView(R.id.parent_layout)
		CardView parent;
		@Override
		protected void bindView(View itemView) {
			ButterKnife.bind(this,itemView);
		}
	}
}

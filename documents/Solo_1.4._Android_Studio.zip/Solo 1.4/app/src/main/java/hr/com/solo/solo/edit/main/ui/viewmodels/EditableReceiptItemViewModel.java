package hr.com.solo.solo.edit.main.ui.viewmodels;

import androidx.cardview.widget.CardView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.airbnb.epoxy.EpoxyHolder;
import com.airbnb.epoxy.EpoxyModelWithHolder;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.R;
import hr.com.solo.solo.edititem.EditItemActivity;
import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.utils.MathUtils;
import hr.com.solo.solo.utils.OnItemSelected;

// 2017-04-08 Ian Rumac

public class EditableReceiptItemViewModel extends EpoxyModelWithHolder<EditableReceiptItemViewModel.ReceiptItemViewHolder> {
	CatalogItem result;
	OnItemSelected<CatalogItem> itemOnItemSelected;

	public EditableReceiptItemViewModel(CatalogItem result, String query, OnItemSelected<CatalogItem> itemOnItemSelected) {
		this.itemOnItemSelected = itemOnItemSelected;
		this.result = result;
	}

	public EditableReceiptItemViewModel(CatalogItem result, OnItemSelected<CatalogItem> itemOnItemSelected) {
		this.result = result;
		this.itemOnItemSelected = itemOnItemSelected;
	}

	public CatalogItem getResult() {
		return result;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		if (!super.equals(o)) {
			return false;
		}

		EditableReceiptItemViewModel that = (EditableReceiptItemViewModel) o;

		return result != null ? result.equals(that.result) : that.result == null;
	}

	@Override
	public int hashCode() {
		int result1 = super.hashCode();
		result1 = 31 * result1 + (result != null ? result.hashCode() : 0);
		return result1;
	}

	@Override
	protected ReceiptItemViewHolder createNewHolder() {
		return new ReceiptItemViewHolder();
	}

	@Override
	protected int getDefaultLayout() {
		return R.layout.edit_receipt_list_viewmodel;
	}

	@Override
	public void bind(ReceiptItemViewHolder holder) {
		holder.description.setText(result.getDescription());
		holder.delete.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				itemOnItemSelected.itemSelected(result);
			}
		});
		holder.parentLayout.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				view.getContext().startActivity(EditItemActivity.startWithItem(result,view.getContext()));
			}
		});
		holder.unitNumber.setText(result.getAmount());
		if (!Double.valueOf(result.getDiscount().replace(",",".")).equals(0.0)) {
			holder.discount.setText(result.getDiscount().replace(".",",") + "%");
		}else{
			holder.discount.setText("");
		}
		holder.unit.setText((" ").concat(result.getAmountUnit()));
		holder.price.setText(MathUtils.getPriceForItemString(result).replace(".",","));
	}

	static class ReceiptItemViewHolder extends EpoxyHolder {
		@BindView(R.id.unit) TextView unit;
		@BindView(R.id.price) TextView price;
		@BindView(R.id.description) TextView description;
		@BindView(R.id.parent_layout) CardView parentLayout;
		@BindView(R.id.discount) TextView discount;
		@BindView(R.id.unit_number) TextView unitNumber;

		@BindView(R.id.delete)
		ImageView delete;

		@Override
		protected void bindView(View itemView) {
			ButterKnife.bind(this, itemView);
		}
	}
}

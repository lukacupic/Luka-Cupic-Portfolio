package hr.com.solo.solo.archive.search.repositories;

import java.util.List;

import hr.com.solo.solo.archive.search.network.ReceiptResponseItem;
import io.reactivex.Observable;

// 2017-04-10 Ian Rumac

public interface ReceiptSearchRepositoryInterface {
	Observable<List<ReceiptResponseItem>> getItemsByQuery(String query);
}

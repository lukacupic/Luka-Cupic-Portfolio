package hr.com.solo.solo.archive.search.ui.viewmodels;

import androidx.cardview.widget.CardView;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

import com.airbnb.epoxy.EpoxyHolder;
import com.airbnb.epoxy.EpoxyModelWithHolder;

import java.text.DecimalFormat;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.PrintReceiptActivity;
import hr.com.solo.solo.R;
import hr.com.solo.solo.archive.search.network.ReceiptResponseItem;
import hr.com.solo.solo.utils.OnItemSelected;

// 2017-04-08 Ian Rumac

public class ReceiptItemViewModel extends EpoxyModelWithHolder<ReceiptItemViewModel.ReceiptItemViewHolder> {
	String query;
	ReceiptResponseItem result;
	OnItemSelected<ReceiptResponseItem> itemOnItemSelected;
	public ReceiptItemViewModel(ReceiptResponseItem result, String query, OnItemSelected<ReceiptResponseItem> itemOnItemSelected) {
		this.itemOnItemSelected = itemOnItemSelected;
		this.result = result;
		this.query = query;
	}

	public ReceiptItemViewModel(ReceiptResponseItem result, OnItemSelected<ReceiptResponseItem> itemOnItemSelected) {
		this.itemOnItemSelected = itemOnItemSelected;
		this.result = result;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		if (!super.equals(o)) {
			return false;
		}

		ReceiptItemViewModel that = (ReceiptItemViewModel) o;

		return result != null ? result.equals(that.result) : that.result == null;
	}

	@Override
	public int hashCode() {
		int result1 = super.hashCode();
		result1 = 31 * result1 + (result != null ? result.hashCode() : 0);
		return result1;
	}

	public String getQuery() {
		return query;
	}

	private static DecimalFormat decimalFormat = new DecimalFormat("#0.00");
	public ReceiptResponseItem getResult() {
		return result;
	}

	@Override
	protected ReceiptItemViewHolder createNewHolder() {
		return new ReceiptItemViewHolder();
	}

	@Override
	protected int getDefaultLayout() {
		return R.layout.search_list_viewmodel;
	}

	@Override
	public void bind(ReceiptItemViewHolder holder) {
		holder.parentLayout.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				PrintReceiptActivity.startWithID(result.getId(),view.getContext());
			}
		});
		if (query != null && !query.isEmpty()) {
			int positionStart = result.getBrojRacuna().toLowerCase().indexOf(query.toLowerCase());
			int positionEnd = positionStart + query.length();
			String description = result.getBrojRacuna();
			try {
				String endString = description.substring(0, positionStart).concat("<b><u>")
						.concat(
								description.substring(positionStart, positionEnd))
						.concat("</b></u>")
						.concat(
								description.substring(positionEnd, description.length()));
			holder.description.setText(Html.fromHtml(endString));
			}catch (Exception e){
				holder.description.setText(result.getBrojRacuna());
			}
		} else {
			holder.description.setText(result.getBrojRacuna());
		}
		holder.unit.setText(result.getDatumRacuna());
		//holder.price.setText(result.getBrutoSuma());
		holder.price.setText(decimalFormat.format(Double.valueOf(result.getBrutoSuma().replace(",","."))).replace(".",","));
	}

	public void setQuery(String query) {
		this.query = query;
	}

	static class ReceiptItemViewHolder extends EpoxyHolder {
		@BindView(R.id.unit) TextView unit;
		@BindView(R.id.price) TextView price;
		@BindView(R.id.description) TextView description;
		@BindView(R.id.parent_layout) CardView parentLayout;

		@Override
		protected void bindView(View itemView) {
			ButterKnife.bind(this, itemView);
		}
	}
}

package hr.com.solo.solo.edit.main.repositories;

import java.util.List;

import hr.com.solo.solo.main.models.CatalogItem;
import io.reactivex.Single;

// 2017-04-10 Ian Rumac

public interface EditReceiptRepository {
	Single<List<CatalogItem>> fetchChosenItems();
}

package hr.com.solo.solo.edititem;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.R;
import hr.com.solo.solo.adapters.PaymentTypeAdapter;
import hr.com.solo.solo.base.BaseActivity;
import hr.com.solo.solo.core.CoreApplication;
import hr.com.solo.solo.core.UserCatalogManager;
import hr.com.solo.solo.keyboard.PriceInputKeyboard;
import hr.com.solo.solo.main.models.CatalogItem;

public class EditItemActivity extends BaseActivity {
	@BindView(R.id.ic_back) ImageView btnBack;
	PaymentTypeAdapter adapter;

	public static final String ITEM = "item";
	@BindView(R.id.toolbar) FrameLayout toolbar;
	@BindView(R.id.item_name) EditText itemName;
	@BindView(R.id.item_amount) EditText itemAmount;
	@BindView(R.id.item_price) EditText itemPrice;
	@BindView(R.id.discount) EditText discount;
	@BindView(R.id.item_tax) EditText itemTax;
	/*
		@BindView(R.id.keyboardview)
		KeyboardView keyboardView;
	*/
	@BindView(R.id.btn_check)
	ImageView itemCheck;

	public static Intent startWithItem(CatalogItem item, Context ctx) {

		Intent intent = new Intent(ctx, EditItemActivity.class);
		intent.putExtra(ITEM, item);
		return intent;
	}

	CatalogItem item;
	PriceInputKeyboard keyboard;
	UserCatalogManager manager;
	public static final String AMOUNT_REGEX = "^(?:0|[1-9]\\d{0,2}(?:\\.?\\d{3})*)(?:,\\d{1,4})?$";
	public static final String PRICE_REGEX = "^-?(?:0|[1-9]\\d{0,2}(?:\\.?\\d{3})*)(?:\\,\\d{1,2})?$";
	public static final String DISCOUNT_REGEX = "^(?:0|[1-9]\\d{0,2}(?:\\.?\\d{3})*)(?:\\,\\d{1,4})?$";
	public static final String TAX_REGEX = "^[0-9]{1,2}$";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		manager = CoreApplication.getInstance().getComponent().manager();
		setContentView(R.layout.activity_edit_item);
		ButterKnife.bind(this);
		item = (CatalogItem) getIntent().getSerializableExtra(ITEM);
		itemName.setText(item.getDescription());
		itemAmount.setText(item.getAmount());
		itemPrice.setText(item.getPrice());
		discount.setText(item.getDiscount());
		itemTax.setText(item.getTax());


		itemAmount.setFilters(new InputFilter[]{getInputFilterFor(itemAmount, AMOUNT_REGEX)});

		itemPrice.setFilters(new InputFilter[]{getInputFilterFor(itemPrice, PRICE_REGEX)});
		discount.setFilters(new InputFilter[]{getInputFilterFor(discount, DISCOUNT_REGEX)});
		itemTax.setFilters(new InputFilter[]{getInputFilterFor(itemTax, TAX_REGEX)});
		btnBack.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				onBackPressed();
			}
		});

		itemCheck.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {

				if (checkAllowSaving()) {
					manager.remove(item);
					item.setDescription(itemName.getText().toString());
					item.setAmount(itemAmount.getText().toString());
					item.setPrice(itemPrice.getText().toString());
					item.setTax(itemTax.getText().toString());
					item.setDiscount(discount.getText().toString());
					manager.add(item);
					finish();
				}
			}
		});
	}

	public InputFilter getInputFilterFor(TextView view, String regex) {
		InputFilter commaFilter = new InputFilter() {
			@Override
			public CharSequence filter(CharSequence charSequence, int start, int end, Spanned spanned, int dstart, int dend) {

				String currentText = view.getText().toString();
				if (charSequence.toString().contains(",")) {
					if (currentText.contains(",")) {
						return "";
					} else {
						return null;
					}

				} else if (currentText.substring(0, dstart).concat(charSequence.toString()).concat(currentText.substring(dend, currentText.length())).matches(regex)) {
					return null;
				} else {
					return "";
				}
			}
		};
		return commaFilter;
	}

	boolean checkAllowSaving() {
		return checkIfViewFits(itemAmount, AMOUNT_REGEX)
				&& checkIfViewFits(itemPrice, PRICE_REGEX)
				&& checkIfViewFits(itemTax, TAX_REGEX)
				&& checkIfViewFits(discount, DISCOUNT_REGEX)
				&& checkIfViewFits(itemName, "");
	}

	boolean checkIfViewFits(EditText editText, String regex) {
		if (editText.getText().toString().isEmpty()) {
			showViewIsEmpty(editText.getId());
			return false;
		} else if (!regex.isEmpty() && !editText.getText().toString().matches(regex)) {
			showViewInvalid(editText.getId());
			return false;
		} else {
			return true;
		}
	}

	public void showViewInvalid(int id) {
		String string = "";
		if (id == R.id.item_amount) {
			string = "količina";
		} else if (id == R.id.item_tax) {
			string = "porez";
		}
		else if (id == R.id.discount) {
			string = "popust";
		}
		else if (id == R.id.price) {
			string = "cijena";
		} else if( id == R.id.item_name){
			string = "ime";
		}

		Toast.makeText(this, "Polje " + string + " nije ispravno!", Toast.LENGTH_SHORT).show();
	}

	void showViewIsEmpty(int id) {
		String string = "";
		if (id == R.id.item_amount) {
			string = "količina";
		} else if (id == R.id.item_tax) {
			string = "porez";
		}
		else if (id == R.id.discount) {
			string = "popust";
		}
		else if (id == R.id.price) {
			string = "cijena";
		} else if( id == R.id.item_name){
			string = "ime";
		}

		Toast.makeText(this, "Polje " + string + " je prazno!", Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onBackPressed() {
/*
		if (keyboard.isCustomKeyboardVisible()) {
			keyboard.hideCustomKeyboard();
		} else {
			this.finish();
		}
*/
		finish();
	}

	@Override
	public void showLoading() { }

	@Override
	public void hideLoading() { }

	@Override
	public void displayError(String message) { }

	@Override
	protected void onStop() {
		super.onStop();
	}

	@Override
	protected void onResume() {
		super.onResume();
	}

/*
	@OnClick(R.id.back)
	public void goBack() {
		router.goBack();
	}
*/
}

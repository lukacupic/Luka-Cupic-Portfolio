package hr.com.solo.solo.base;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;

// 2017-04-09 Ian Rumac

public abstract class BaseToolbarActivity extends BaseActivity implements BaseView {

}

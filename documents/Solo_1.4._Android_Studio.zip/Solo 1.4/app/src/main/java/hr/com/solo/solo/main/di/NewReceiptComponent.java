package hr.com.solo.solo.main.di;

import hr.com.solo.solo.core.di.CoreComponent;
import hr.com.solo.solo.core.di.PerFragment;
import hr.com.solo.solo.main.ui.NewReceiptActivity;
import hr.com.solo.solo.search.di.SearchComponent;

import dagger.Component;

// 2017-04-08 Ian Rumac

@PerFragment
@Component(dependencies = CoreComponent.class, modules = NewReceiptModule.class)
public interface NewReceiptComponent {
	void inject(NewReceiptActivity newReceiptFragment);
}

package hr.com.solo.solo.utils;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.AsyncTask;
import android.webkit.WebView;

// 2017-07-20 Haris Kovacevic

public class ScreenshotUtil {
    public static Bitmap screenshot(WebView webView) {
        try {
            float scale = webView.getScale();
            int height = (int) (webView.getContentHeight() * scale + 0.5);
            Bitmap bitmap = Bitmap.createBitmap(webView.getWidth(), height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            webView.draw(canvas);
            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void getScreenshot(WebView webView,Callback callback){
        new AsyncTask<WebView, Void, Bitmap>() {
            @Override
            protected Bitmap doInBackground(WebView... params) {
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                return screenshot(params[0]);
            }

            @Override
            protected void onPostExecute(Bitmap bitmap) {
                callback.onScreenshot(bitmap);
            }
        }.execute(webView);
    }

    public interface Callback{
        void onScreenshot(Bitmap bitmap);
    }
}

package hr.com.solo.solo.utils;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.Log;

import androidx.annotation.NonNull;

import com.bxl.config.editor.BXLConfigLoader;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.starmicronics.starioextension.ICommandBuilder;
import com.starmicronics.starioextension.StarIoExt;

import java.nio.charset.Charset;

import hr.com.solo.solo.printer.PrinterFactory;

import static android.content.ContentValues.TAG;

// 2017-07-16 Haris Kovacevic
// 2022-09-27 Matija
// 2022-11-14 Luka

public class PrinterUtils {
    private static final String[] SUPPORTED_DEVICES_BIXOLON = new String[]{"srp", "spp", "stp"};
    private static final String[] SUPPORTED_DEVICES_DATECS = new String[]{"dpp-", "cmp-", "ep-", "lp-", "fp-", "tm-", "fmp-", "dk1-"};
    private static final String[] SUPPORTED_DEVICES_STAR = new String[]{"mpop", "fvp10", "tsp", "sm-s", "sm-t", "sm-l", "bsc10", "starprnt", "star"};
    private static final String[] SUPPORTED_DEVICES_ZJ = new String[]{"zj", "printer"};
    private static final String[] SUPPORTED_DEVICES_XMJ = new String[]{"mtp", "pt-"};
    private static final String[] SUPPORTED_DEVICES_RONGTA = new String[]{"rpp"};

    public static boolean isSupported(String modelName) {
        if (modelName == null)
            return false;

        for (String model : SUPPORTED_DEVICES_BIXOLON) {
            if (modelName.toLowerCase().contains(model))
                return true;
        }

        for (String model : SUPPORTED_DEVICES_DATECS) {
            if (modelName.toLowerCase().contains(model))
                return true;
        }

        for (String model : SUPPORTED_DEVICES_STAR) {
            if (modelName.toLowerCase().contains(model))
                return true;
        }

        for (String model : SUPPORTED_DEVICES_ZJ) {
            if (modelName.toLowerCase().contains(model)) {
                return true;
            }
        }

        for (String model : SUPPORTED_DEVICES_XMJ) {
            if (modelName.toLowerCase().contains(model)) {
                return true;
            }
        }

        for (String model : SUPPORTED_DEVICES_RONGTA) {
            if (modelName.toLowerCase().contains(model)) {
                return true;
            }
        }

        return false;
    }

    public static String getRetailer(String modelName) {
        if (modelName == null)
            return "Nepoznato";

        for (String model : SUPPORTED_DEVICES_BIXOLON) {
            if (modelName.toLowerCase().contains(model))
                return PrinterFactory.RETAILER_BIXOLON;
        }

        for (String model : SUPPORTED_DEVICES_DATECS) {
            if (modelName.toLowerCase().contains(model))
                return PrinterFactory.RETAILER_DATECS;
        }

        for (String model : SUPPORTED_DEVICES_STAR) {
            if (modelName.toLowerCase().contains(model))
                return PrinterFactory.RETAILER_STAR;
        }

        for (String model : SUPPORTED_DEVICES_ZJ) {
            if (modelName.toLowerCase().contains(model)) {
                return PrinterFactory.RETAILER_ZJ;
            }
        }

        for (String model : SUPPORTED_DEVICES_XMJ) {
            if (modelName.toLowerCase().contains(model)) {
                return PrinterFactory.RETAILER_XMJ;
            }
        }

        for (String model : SUPPORTED_DEVICES_RONGTA) {
            if (modelName.toLowerCase().contains(model)) {
                return PrinterFactory.RETAILER_RONGTA;
            }
        }

        return "Nepoznato";
    }

    public static @NonNull
    Bitmap createBitmapFromQR(String data) {
        try {
            BitMatrix bitMatrix = new QRCodeWriter().encode(data, BarcodeFormat.QR_CODE, 250, 250);
            int width = bitMatrix.getWidth();
            int height = bitMatrix.getHeight();
            Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    bmp.setPixel(x, y, bitMatrix.get(x, y) ? Color.BLACK : Color.WHITE);
                }
            }
            return bmp;
        } catch (WriterException e) {
            return Bitmap.createBitmap(250, 250, Bitmap.Config.RGB_565);
        }
    }
}

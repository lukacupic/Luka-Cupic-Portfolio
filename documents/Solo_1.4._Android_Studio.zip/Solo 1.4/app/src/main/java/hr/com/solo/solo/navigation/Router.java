package hr.com.solo.solo.navigation;

// 2017-04-09 Ian Rumac

public interface Router {
	public void navigateToUserDetails(String username);
	public void navigateToRepositoryDetails(String owner, String name);
	public void goBack();
	public void openLinkInBrowser(String link);
	public void clearBackstack();
}

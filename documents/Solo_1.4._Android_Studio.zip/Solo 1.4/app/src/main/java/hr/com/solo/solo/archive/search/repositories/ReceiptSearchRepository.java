package hr.com.solo.solo.archive.search.repositories;

import java.util.List;

import javax.inject.Named;

import hr.com.solo.solo.archive.search.network.ReceiptResponseItem;
import hr.com.solo.solo.core.UserReceiptManager;
import io.reactivex.Observable;
import io.reactivex.Scheduler;

// 2017-04-08 Ian Rumac

public class ReceiptSearchRepository implements ReceiptSearchRepositoryInterface {
	private final UserReceiptManager source;
	private final Scheduler schedulerExecution;

	public ReceiptSearchRepository(UserReceiptManager source, @Named("io") Scheduler execution) {
		this.source = source;
		this.schedulerExecution = execution;
	}

	@Override
	public Observable<List<ReceiptResponseItem>> getItemsByQuery(String query) {
		return Observable.just(source.getItemsForQuery(query));
	}

/*
	@Override
	public Observable<List<GithubRepository>> getRepositoriesByQuery(String query, String sort, String order, int page) {
		return source.searchRepositoriesByQuery(query, sort, order, page).subscribeOn(schedulerExecution);
	}
*/
}

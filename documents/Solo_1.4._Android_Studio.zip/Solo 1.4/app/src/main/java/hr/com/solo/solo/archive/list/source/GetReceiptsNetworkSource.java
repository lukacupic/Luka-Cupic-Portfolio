package hr.com.solo.solo.archive.list.source;

import hr.com.solo.solo.archive.search.network.ReceiptItemListResponseWrapper;
import hr.com.solo.solo.archive.search.network.ReceiptResponseItem;
import io.reactivex.Single;

// 2017-04-09 Ian Rumac

public interface GetReceiptsNetworkSource {
	 Single<ReceiptItemListResponseWrapper> getReceipts(String token);
}

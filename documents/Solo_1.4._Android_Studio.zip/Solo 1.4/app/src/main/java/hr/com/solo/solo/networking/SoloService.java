package hr.com.solo.solo.networking;

import java.util.Map;

import hr.com.solo.solo.archive.search.network.ReceiptItemListResponseWrapper;
import hr.com.solo.solo.login.models.LoginModel;
import hr.com.solo.solo.models.ReceiptResponse;
import hr.com.solo.solo.search.models.network.ItemListResponseWrapper;
import hr.com.solo.solo.utils.Constants;
import io.reactivex.Observable;
import io.reactivex.Single;
import okhttp3.ResponseBody;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;
import retrofit2.http.Url;

// 2017-04-08 Ian Rumac

public interface SoloService {
	@GET(Constants.Endpoints.KATALOG)
	Single<ItemListResponseWrapper> getItemsForUser(
			@Query("token") String token
	);

	@GET(Constants.Endpoints.PRIJAVA)
	Observable<LoginModel> loginUser(
			@Query("kor_ime") String name,
			@Query("lozinka") String password);

	@FormUrlEncoded
	@POST(Constants.Endpoints.RACUN)
	Single<ReceiptResponse> createReceipt(
			@FieldMap Map<String, String> map
	);

	@GET(Constants.Endpoints.RACUN)
	Single<ReceiptItemListResponseWrapper> getReceipt(
			@Query("pos") int pos,
			@Query("token") String token,
			@Query("id") String id
	);

	@GET(Constants.Endpoints.RACUN)
	Single<ReceiptResponse> getSingleReceipt(
			@Query("pos") int pos,
			@Query("token") String token,
			@Query("id") String id
	);

	@FormUrlEncoded
	@POST(Constants.Endpoints.STORNO)
	Single<ReceiptResponse> stopReceipt(
			@FieldMap Map<String,String> map
	);

	@GET
	Single<ResponseBody> downloadFileWithDynamicUrl(@Url String fileUrl);
}

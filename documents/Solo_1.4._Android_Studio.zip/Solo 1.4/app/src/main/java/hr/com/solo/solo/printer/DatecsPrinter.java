package hr.com.solo.solo.printer;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import com.datecs.api.printer.Printer;
import com.datecs.api.printer.ProtocolAdapter;
import com.datecs.api.universalreader.UniversalReader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

// 2017-07-16 Haris Kovacevic
// 2018-09-10 Ishaq Sandouqa
// 2020-12-17 Farhad Bhuiyan (QR code)
// 2022-11-20 Luka

public class DatecsPrinter extends BasePrinter {

    private Printer datecsPrinter;
    private BluetoothSocket mBtSocket;
    private ProtocolAdapter mProtocolAdapter;

    public DatecsPrinter(PrinterStatusCallback printerStatusCallback) {
        super(printerStatusCallback);
    }

    // INTERFACE METHODS

    @Override
    public void connectPrinter(String address, String name) {
        executeAsync(() -> {
            try {
                closeConnection();
            } catch (PrinterErrorException e) {
                statusCallback.onStatus(PrinterStatusCallback.STATUS.ERROR);
            }

            statusCallback.onStatus(PrinterStatusCallback.STATUS.CONNECTING);
            final BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();

            btAdapter.cancelDiscovery();

            UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
            BluetoothDevice btDevice = btAdapter.getRemoteDevice(address);

            InputStream in;
            OutputStream out;

            try {
                BluetoothSocket btSocket = btDevice.createRfcommSocketToServiceRecord(uuid);
                btSocket.connect();

                mBtSocket = btSocket;
                in = mBtSocket.getInputStream();
                out = mBtSocket.getOutputStream();
            } catch (IOException e) {
                statusCallback.onStatus(PrinterStatusCallback.STATUS.NOT_SUPPORTED);
                return;
            }

            try {
                initPrinter(in, out);
            } catch (IOException e) {
                statusCallback.onStatus(PrinterStatusCallback.STATUS.NOT_SUPPORTED);
            }
        });
    }

    @Override
    public void printInvoice(Object invoice, Object qrCode) {
        executeAsync(() -> {
            try {
                datecsPrinter.reset();
                datecsPrinter.setLineSpace(29);
                datecsPrinter.printText((String) invoice, "Windows-1250");

                if (qrCode != null) {
                    datecsPrinter.feedPaper(29);
                    datecsPrinter.setBarcode(Printer.ALIGN_CENTER, false, 2, Printer.HRI_NONE, 1);
                    datecsPrinter.printQRCode(10, 1, (String) qrCode);
                }

                datecsPrinter.setAlign(2);
                datecsPrinter.feedPaper(29);
                datecsPrinter.printText("- solo.com.hr mobilna fiskalna -");
                datecsPrinter.feedPaper(140);

                datecsPrinter.flush();
                statusCallback.onStatus(PrinterStatusCallback.STATUS.DONE);
            } catch (IOException e) {
                statusCallback.onStatus(PrinterStatusCallback.STATUS.ERROR);
            }
        });
    }

    @Override
    public void disconnectPrinter() {
        executeAsync(() -> {
            try {
                closeConnection();
                setConnected(false);

            } catch (PrinterErrorException ex) {
                statusCallback.onStatus(PrinterStatusCallback.STATUS.ERROR);
            }
        });
    }

    // END OF INTERFACE METHODS

    // PRIVATE METHODS

    private synchronized void closeConnection() throws PrinterErrorException {
        closeBluetoothConnection();
        closePrinterConnection();
    }

    private synchronized void closeBluetoothConnection() throws PrinterErrorException {
        try {
            BluetoothSocket s = mBtSocket;
            mBtSocket = null;
            if (s != null) {
                s.close();
            }
        } catch (IOException ex) {
            throw new PrinterErrorException();
        }
    }

    private synchronized void closePrinterConnection() {
        if (datecsPrinter != null) {
            datecsPrinter.close();
        }

        if (mProtocolAdapter != null) {
            mProtocolAdapter.close();
        }
    }

    // END OF PRIVATE METHODS

    // PROTECTED METHODS

    protected void initPrinter(InputStream inputStream, OutputStream outputStream) throws PrinterErrorException {
        try {        // Here you can enable various debug information
            //ProtocolAdapter.setDebug(true);
            Printer.setDebug(true);

            // Check if printer is into protocol mode. Ones the object is created it can not be released
            // without closing base streams.
            mProtocolAdapter = new ProtocolAdapter(inputStream, outputStream);

            if (mProtocolAdapter.isProtocolEnabled()) {
                // Get printer instance
                ProtocolAdapter.Channel mPrinterChannel = mProtocolAdapter.getChannel(ProtocolAdapter.CHANNEL_PRINTER);
                datecsPrinter = new Printer(mPrinterChannel.getInputStream(), mPrinterChannel.getOutputStream());
                // Check if printer has encrypted magnetic head
                ProtocolAdapter.Channel mUniversalChannel = mProtocolAdapter.getChannel(ProtocolAdapter.CHANNEL_UNIVERSAL_READER);
                new UniversalReader(mUniversalChannel.getInputStream(), mUniversalChannel.getOutputStream());

            } else {
                datecsPrinter = new Printer(mProtocolAdapter.getRawInputStream(), mProtocolAdapter.getRawOutputStream());
            }

            statusCallback.onStatus(PrinterStatusCallback.STATUS.CONNECTED);
            setConnected(true);
            datecsPrinter.setConnectionListener(() -> {
            });
        } catch (IOException ex) {
            throw new PrinterErrorException();
        }
    }

    // END OF PROTECTED METHODS
}

package hr.com.solo.solo.printer;

import android.content.Context;

import com.bxl.config.editor.BXLConfigLoader;

import jpos.JposConst;
import jpos.JposException;
import jpos.POSPrinter;
import jpos.POSPrinterConst;
import jpos.config.JposEntry;
import jpos.events.DataEvent;
import jpos.events.DataListener;
import jpos.events.DirectIOEvent;
import jpos.events.DirectIOListener;
import jpos.events.ErrorEvent;
import jpos.events.ErrorListener;
import jpos.events.OutputCompleteEvent;
import jpos.events.OutputCompleteListener;
import jpos.events.StatusUpdateEvent;
import jpos.events.StatusUpdateListener;

// 2018-09-09 Ishaq Sandouqa
// 2020-12-17 Farhad Bhuiyan (QR code)
// 2022-11-26 Luka

public class BixolonPrinter extends BasePrinter {
    private final BixolonPrinterController bxController;

    public BixolonPrinter(Context context, PrinterStatusCallback callback) {
        super(callback);
        bxController = new BixolonPrinterController(context, callback);
    }

    // INTERFACE METHODS

    @Override
    public void connectPrinter(String address, String name) {
        executeAsync(() -> {
            statusCallback.onStatus(PrinterStatusCallback.STATUS.CONNECTING);
            boolean isConnectionSucceed = bxController.openPrinter(BXLConfigLoader.DEVICE_BUS_BLUETOOTH, name, address, true);
            setConnected(isConnectionSucceed);
        });
    }

    @Override
    public void printInvoice(Object invoice, Object qrCode) {
        executeAsync(() -> {
            try {
                bxController.setCharacterSet(BixolonPrinterController.CS_1250);
                bxController.printText((String) invoice, BixolonPrinterController.ALIGNMENT_LEFT, BixolonPrinterController.ATTRIBUTE_FONT_A, 10);

                if (qrCode != null) {
                    bxController.printBarcode((String) qrCode, POSPrinterConst.PTR_BCS_QRCODE, 5, 5, BixolonPrinterController.ALIGNMENT_CENTER, POSPrinterConst.PTR_BC_TEXT_NONE);
                }

                bxController.printText("- solo.com.hr mobilna fiskalna -", BixolonPrinterController.ALIGNMENT_CENTER, BixolonPrinterController.ATTRIBUTE_FONT_B, 10);
                bxController.printText("\n", BixolonPrinterController.ALIGNMENT_LEFT, BixolonPrinterController.ATTRIBUTE_FONT_A, 10);
            } catch (PrinterErrorException ex) {
                statusCallback.onStatus(PrinterStatusCallback.STATUS.ERROR);
            }
        });
    }

    @Override
    public void setPrinterStatusCallback(PrinterStatusCallback callback) {
        super.setPrinterStatusCallback(callback);
        bxController.setCallback(callback);
    }

    @Override
    public void disconnectPrinter() {
        executeAsync(() -> {
            try {
                if (bxController != null) {
                    bxController.closePrinter();
                    setConnected(false);
                }
            } catch (PrinterErrorException ex) {
            }
        });

    }

    // END OF INTERFACE METHODS

    static class BixolonPrinterController implements ErrorListener, OutputCompleteListener, StatusUpdateListener, DirectIOListener, DataListener {
        public static int ALIGNMENT_LEFT = 1;
        public static int ALIGNMENT_CENTER = 2;
        public static int ALIGNMENT_RIGHT = 4;

        public static int ATTRIBUTE_FONT_A = 1;
        public static int ATTRIBUTE_FONT_B = 2;
        public static int ATTRIBUTE_FONT_C = 4;
        public static int ATTRIBUTE_FONT_D = 64;
        public static int ATTRIBUTE_BOLD = 8;
        public static int ATTRIBUTE_UNDERLINE = 16;
        public static int ATTRIBUTE_REVERSE = 32;

        public static int CS_1250 = 1250;

        private final BXLConfigLoader bxlConfigLoader;
        private final POSPrinter posPrinter;

        private PrinterStatusCallback callback;

        public BixolonPrinterController(Context context, PrinterStatusCallback callback) {
            this.callback = callback;
            posPrinter = new POSPrinter(context);
            posPrinter.addStatusUpdateListener(this);
            posPrinter.addErrorListener(this);
            posPrinter.addOutputCompleteListener(this);
            posPrinter.addDirectIOListener(this);

            bxlConfigLoader = new BXLConfigLoader(context);
            try {
                bxlConfigLoader.openFile();
            } catch (Exception e) {
                bxlConfigLoader.newFile();
            }
        }

        // INTERFACE METHODS

        @Override
        public void directIOOccurred(DirectIOEvent directIOEvent) {
        }

        @Override
        public void errorOccurred(ErrorEvent errorEvent) {
            callback.onMessage(getERMessage(errorEvent.getErrorCode()));
        }

        @Override
        public void outputCompleteOccurred(OutputCompleteEvent outputCompleteEvent) {
            callback.onStatus(PrinterStatusCallback.STATUS.DONE);
        }

        @Override
        public void statusUpdateOccurred(StatusUpdateEvent statusUpdateEvent) {
        }

        @Override
        public void dataOccurred(DataEvent dataEvent) {
        }

        // END OF INTERFACE METHODS

        // PUBLIC METHODS

        public boolean openPrinter(int portType, String logicalName, String address, boolean isAsyncMode) {
            if (setTargetDevice(portType, logicalName, address)) {
                try {
                    posPrinter.open(logicalName);
                    if (!posPrinter.getClaimed()) {
                        posPrinter.claim(5000);
                    }
                    posPrinter.setDeviceEnabled(true);
                    posPrinter.setAsyncMode(isAsyncMode);

                    callback.onStatus(PrinterStatusCallback.STATUS.CONNECTED);
                } catch (JposException e) {
                    try {
                        posPrinter.close();
                    } catch (JposException e1) {
                        return false;
                    }
                    callback.onStatus(PrinterStatusCallback.STATUS.NOT_SUPPORTED);
                    return false;
                }
            } else {
                callback.onStatus(PrinterStatusCallback.STATUS.NOT_SUPPORTED);
                return false;
            }
            return true;
        }

        public void closePrinter() throws PrinterErrorException {
            try {
                if (posPrinter.getClaimed()) {
                    posPrinter.setDeviceEnabled(false);
                    posPrinter.release();
                    posPrinter.close();
                }
            } catch (JposException e) {
                throw new PrinterErrorException();
            }
        }

        public void printText(String data, int alignment, int attribute, int textSize) throws PrinterErrorException {
            try {
                if (!posPrinter.getDeviceEnabled()) {
                    return;
                }

                String strOption = getBixolonEscapeSequence(0);

                if ((alignment & ALIGNMENT_LEFT) == ALIGNMENT_LEFT) {
                    strOption += getBixolonEscapeSequence(4);
                }

                if ((alignment & ALIGNMENT_CENTER) == ALIGNMENT_CENTER) {
                    strOption += getBixolonEscapeSequence(5);
                }

                if ((alignment & ALIGNMENT_RIGHT) == ALIGNMENT_RIGHT) {
                    strOption += getBixolonEscapeSequence(6);
                }

                if ((attribute & ATTRIBUTE_FONT_A) == ATTRIBUTE_FONT_A) {
                    strOption += getBixolonEscapeSequence(1);
                }

                if ((attribute & ATTRIBUTE_FONT_B) == ATTRIBUTE_FONT_B) {
                    strOption += getBixolonEscapeSequence(2);
                }

                if ((attribute & ATTRIBUTE_FONT_C) == ATTRIBUTE_FONT_C) {
                    strOption += getBixolonEscapeSequence(3);
                }

                if ((attribute & ATTRIBUTE_FONT_D) == ATTRIBUTE_FONT_D) {
                    strOption += getBixolonEscapeSequence(33);
                }

                if ((attribute & ATTRIBUTE_BOLD) == ATTRIBUTE_BOLD) {
                    strOption += getBixolonEscapeSequence(7);
                }

                if ((attribute & ATTRIBUTE_UNDERLINE) == ATTRIBUTE_UNDERLINE) {
                    strOption += getBixolonEscapeSequence(9);
                }

                if ((attribute & ATTRIBUTE_REVERSE) == ATTRIBUTE_REVERSE) {
                    strOption += getBixolonEscapeSequence(11);
                }

                switch (textSize) {
                    case 1:
                        strOption += getBixolonEscapeSequence(17);
                        strOption += getBixolonEscapeSequence(25);
                        break;
                    case 2:
                        strOption += getBixolonEscapeSequence(18);
                        strOption += getBixolonEscapeSequence(26);
                        break;
                    case 3:
                        strOption += getBixolonEscapeSequence(19);
                        strOption += getBixolonEscapeSequence(27);
                        break;
                    case 4:
                        strOption += getBixolonEscapeSequence(20);
                        strOption += getBixolonEscapeSequence(28);
                        break;
                    case 5:
                        strOption += getBixolonEscapeSequence(21);
                        strOption += getBixolonEscapeSequence(29);
                        break;
                    case 6:
                        strOption += getBixolonEscapeSequence(22);
                        strOption += getBixolonEscapeSequence(30);
                        break;
                    case 7:
                        strOption += getBixolonEscapeSequence(23);
                        strOption += getBixolonEscapeSequence(31);
                        break;
                    case 8:
                        strOption += getBixolonEscapeSequence(24);
                        strOption += getBixolonEscapeSequence(32);
                        break;
                    default:
                        strOption += getBixolonEscapeSequence(17);
                        strOption += getBixolonEscapeSequence(25);
                        break;
                }
                posPrinter.printNormal(POSPrinterConst.PTR_S_RECEIPT, strOption + data);
            } catch (JposException e) {
                throw new PrinterErrorException();
            }
        }

        public void printBarcode(String data, int symbology, int width, int height, int alignment, int hri) throws PrinterErrorException {
            try {
                if (!posPrinter.getDeviceEnabled()) {
                    return;
                }

                if (alignment == ALIGNMENT_LEFT) {
                    alignment = POSPrinterConst.PTR_BC_LEFT;

                } else if (alignment == ALIGNMENT_CENTER) {
                    alignment = POSPrinterConst.PTR_BC_CENTER;

                } else {
                    alignment = POSPrinterConst.PTR_BC_RIGHT;
                }

                posPrinter.printBarCode(POSPrinterConst.PTR_S_RECEIPT, data, symbology, height, width, alignment, hri);
            } catch (JposException e) {
                throw new PrinterErrorException();
            }
        }

        public void setCharacterSet(int cs) throws PrinterErrorException {
            try {
                posPrinter.setCharacterSet(cs);
            } catch (JposException e) {
                throw new PrinterErrorException();
            }
        }

        public void setCallback(PrinterStatusCallback callback) {
            this.callback = callback;
        }

        // END OF PUBLIC METHODS

        // PRIVATE METHODS

        private boolean setTargetDevice(int portType, String logicalName, String address) {
            try {
                for (Object entry : bxlConfigLoader.getEntries()) {
                    JposEntry jposEntry = (JposEntry) entry;
                    if (jposEntry.getLogicalName().equals(logicalName)) {
                        bxlConfigLoader.removeEntry(jposEntry.getLogicalName());
                        break;
                    }
                }

                int deviceCategory = BXLConfigLoader.DEVICE_CATEGORY_POS_PRINTER;
                String productName = getBixolonProductName(logicalName);

                bxlConfigLoader.addEntry(logicalName, deviceCategory, productName, portType, address);
                bxlConfigLoader.saveFile();
            } catch (Exception e) {
                return false;
            }
            return true;
        }

        private String getERMessage(int status) {
            switch (status) {
                case POSPrinterConst.JPOS_EPTR_COVER_OPEN:
                    return "Cover open";

                case POSPrinterConst.JPOS_EPTR_REC_EMPTY:
                    return "Paper empty";

                case POSPrinterConst.JPOS_EPTR_OFF_LINE:
                    return "Printer Off-line";

                case JposConst.JPOS_SUE_POWER_OFF_OFFLINE:
                    return "Power off";

                default:
                    return "Unknown";
            }
        }

        private String getBixolonProductName(String name) {
            String productName = BXLConfigLoader.PRODUCT_NAME_SPP_R200II;

            if ((name.equals("SPP-R200III"))) {
                productName = BXLConfigLoader.PRODUCT_NAME_SPP_R200III;

            } else if ((name.equals("SPP-R210"))) {
                productName = BXLConfigLoader.PRODUCT_NAME_SPP_R210;

            } else if ((name.equals("SPP-R215"))) {
                productName = BXLConfigLoader.PRODUCT_NAME_SPP_R215;

            } else if ((name.equals("SPP-R220"))) {
                productName = BXLConfigLoader.PRODUCT_NAME_SPP_R220;
            }

            return productName;
        }

        private String getBixolonEscapeSequence(int selectedPosition) {
            String ESCAPE_CHARACTERS = new String(new byte[]{0x1b, 0x7c});

            switch (selectedPosition) {
                case 0:    // Normal
                    return ESCAPE_CHARACTERS + "N";

                case 1:    // Font A (12x24)
                    return ESCAPE_CHARACTERS + "aM";

                case 2:    // Font B (9x17)
                    return ESCAPE_CHARACTERS + "bM";

                case 3:    // Font C (9x24)
                    return ESCAPE_CHARACTERS + "cM";

                case 4:    // Left justify
                    return ESCAPE_CHARACTERS + "lA";

                case 5:    // Center
                    return ESCAPE_CHARACTERS + "cA";

                case 6:    // Right justify
                    return ESCAPE_CHARACTERS + "rA";

                case 7:    // Bold
                    return ESCAPE_CHARACTERS + "bC";

                case 8:    // Disabled bold
                    return ESCAPE_CHARACTERS + "!bC";

                case 9:    // Underline
                    return ESCAPE_CHARACTERS + "uC";

                case 10:    // Disabled underline
                    return ESCAPE_CHARACTERS + "!uC";

                case 11:    // Reverse video
                    return ESCAPE_CHARACTERS + "rvC";

                case 12:    // Disabled reverse video
                    return ESCAPE_CHARACTERS + "!rvC";

                case 13:    // Single high and wide
                    return ESCAPE_CHARACTERS + "1C";

                case 14:    // Double wide
                    return ESCAPE_CHARACTERS + "2C";

                case 15:    // Double high
                    return ESCAPE_CHARACTERS + "3C";

                case 16:    // Double high and wide
                    return ESCAPE_CHARACTERS + "4C";

                case 17:    // Scale 1 time horizontally
                    return ESCAPE_CHARACTERS + "1hC";

                case 18:    // Scale 2 times horizontally
                    return ESCAPE_CHARACTERS + "2hC";

                case 19:    // Scale 3 times horizontally
                    return ESCAPE_CHARACTERS + "3hC";

                case 20:    // Scale 4 times horizontally
                    return ESCAPE_CHARACTERS + "4hC";

                case 21:    // Scale 5 times horizontally
                    return ESCAPE_CHARACTERS + "5hC";

                case 22:    // Scale 6 times horizontally
                    return ESCAPE_CHARACTERS + "6hC";

                case 23:    // Scale 7 times horizontally
                    return ESCAPE_CHARACTERS + "7hC";

                case 24:    // Scale 8 times horizontally
                    return ESCAPE_CHARACTERS + "8hC";

                case 25:    // Scale 1 time vertically
                    return ESCAPE_CHARACTERS + "1vC";

                case 26:    // Scale 2 times vertically
                    return ESCAPE_CHARACTERS + "2vC";

                case 27:    // Scale 3 times vertically
                    return ESCAPE_CHARACTERS + "3vC";

                case 28:    // Scale 4 times vertically
                    return ESCAPE_CHARACTERS + "4vC";

                case 29:    // Scale 5 times vertically
                    return ESCAPE_CHARACTERS + "5vC";

                case 30:    // Scale 6 times vertically
                    return ESCAPE_CHARACTERS + "6vC";

                case 31:    // Scale 7 times vertically
                    return ESCAPE_CHARACTERS + "7vC";

                case 32:    // Scale 8 times vertically
                    return ESCAPE_CHARACTERS + "8vC";

                case 33:
                    return ESCAPE_CHARACTERS + "dM";

                default:
                    return "";
            }
        }

        // END OF PRIVATE METHODS
    }
}
package hr.com.solo.solo.utils;

import android.content.Context;
import androidx.annotation.DrawableRes;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

import javax.inject.Inject;

// 2017-04-10 Ian Rumac

public class GlideImageLoader implements ImageLoader {
	Context application;

	@Inject
	public GlideImageLoader(Context application) {
		this.application = application;
	}

	@Override
	public void loadImage(ImageView view, String url) {
		Glide.with(application).load(url).into(view);
	}

	@Override
	public void loadImageWithPlaceHolder(ImageView view, String url, @DrawableRes int placeHolderResource) {
		Glide.with(application).load(url).placeholder(placeHolderResource).into(view);
	}

	@Override
	public void loadImageWithPlaceHolderCenterCrop(ImageView view, String url, @DrawableRes int placeHolderResource) {
		Glide.with(application).load(url).centerCrop().placeholder(placeHolderResource).into(view);
	}
}

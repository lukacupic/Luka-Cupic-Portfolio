package hr.com.solo.solo.base;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.text.TextUtils;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import hr.com.solo.solo.R;
import io.github.inflationx.viewpump.ViewPumpContextWrapper;

// 2017-04-09 Ian Rumac

public abstract class BaseActivity extends AppCompatActivity implements BaseView {
    static {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransitionExit();
    }

    @Override
    public void startActivity(Intent intent) {
        super.startActivity(intent);
        overridePendingTransitionEnter();
    }

    /**
     * Overrides the pending Activity transition by performing the "Enter" animation.
     */
    protected void overridePendingTransitionEnter() {
        overridePendingTransition(R.anim.slide_from_right, R.anim.slide_to_left);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransitionExit();
    }

    /**
     * Overrides the pending Activity transition by performing the "Exit" animation.
     */
    protected void overridePendingTransitionExit() {
        overridePendingTransition(R.anim.side_from_left, R.anim.slide_to_right);
    }

    public void setTextIfNotEmptyOrElse(@Nullable String text, TextView view, @NonNull String textIfEmpty) {
        if (!TextUtils.isEmpty(text)) {
            view.setText(text);
        } else if (!textIfEmpty.isEmpty()) {
            view.setText(textIfEmpty);
        }
    }

    public void setTextIfNotEmptyOrElse(@Nullable String text, TextView view, @StringRes int textIfEmpty) {
        setTextIfNotEmptyOrElse(text, view, getString(textIfEmpty));
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase));
    }

    public void showErrorWith(String message) {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_error);
        TextView textMessage = (TextView) dialog.findViewById(R.id.message);
        textMessage.setText(message);
        TextView btn = (TextView) dialog.findViewById(R.id.btn_close);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}

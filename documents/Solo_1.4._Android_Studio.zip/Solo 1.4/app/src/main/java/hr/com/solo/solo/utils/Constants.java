package hr.com.solo.solo.utils;

// 2017-04-08 Ian Rumac

public interface Constants {
	int PER_PAGE_MAX = 30;

	interface Endpoints {
		String PRIJAVA = "prijava";
		String KATALOG = "katalog";
		String RACUN = "racun";
		String STORNO = "storno";
	}
}

package hr.com.solo.solo.archive.search.source;

import javax.inject.Inject;

import hr.com.solo.solo.networking.SoloService;

// 2017-04-08 Ian Rumac

public class SearchNetworkSource implements SearchSource {
	private final SoloService apiService;

	@Inject
	public SearchNetworkSource(SoloService apiService) {
		this.apiService = apiService;
	}

/*
	@Override
	public Observable<List<GithubRepository>> searchRepositoriesByQuery(String query, String sort, String order, int page) {

		return mapper.mapResponseResultToList(apiService.getItemsForUser(query, sort, order, page, Constants.PER_PAGE_MAX));
	}
*/
}

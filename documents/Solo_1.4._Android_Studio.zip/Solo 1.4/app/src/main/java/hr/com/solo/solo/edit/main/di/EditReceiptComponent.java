package hr.com.solo.solo.edit.main.di;

import dagger.Component;
import hr.com.solo.solo.core.di.CoreComponent;
import hr.com.solo.solo.core.di.PerFragment;
import hr.com.solo.solo.edit.main.ui.EditReceptActivity;

// 2017-04-08 Ian Rumac

@PerFragment
@Component(dependencies = CoreComponent.class, modules = EditReceiptModule.class)
public interface EditReceiptComponent {
	void inject(EditReceptActivity newReceiptFragment);
}

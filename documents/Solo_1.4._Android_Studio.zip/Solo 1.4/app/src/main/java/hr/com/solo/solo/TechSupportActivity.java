package hr.com.solo.solo;

import android.os.Bundle;
import androidx.annotation.Nullable;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.base.BaseActivity;

// 2017-04-25 Ian Rumac

public class TechSupportActivity extends BaseActivity {

	@BindView(R.id.container_layout) FrameLayout containerLayout;
	@BindView(R.id.ic_back) ImageView backBn;
	LinearLayout menu;
	@BindView(R.id.webview) WebView webView;
	@Override
	protected void onCreate(@Nullable Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_support);
		ButterKnife.bind(this);

		backBn.setOnClickListener(v->onBackPressed());
		webView.getSettings().setJavaScriptEnabled(true);
		webView.loadUrl("https://solo.com.hr/app/");
	}

	@Override
	public void showLoading() { }

	@Override
	public void hideLoading() { }

	@Override
	public void displayError(String message) { }
}

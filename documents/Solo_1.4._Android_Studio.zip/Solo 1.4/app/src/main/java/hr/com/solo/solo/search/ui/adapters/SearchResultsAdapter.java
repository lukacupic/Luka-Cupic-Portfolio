package hr.com.solo.solo.search.ui.adapters;

import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.utils.OnItemSelected;

import java.util.List;

// 2017-04-10 Ian Rumac

public interface SearchResultsAdapter {
	void clearAndAddNewModels(List<CatalogItem> githubRepositories, String query, OnItemSelected<CatalogItem> itemSelected);
	void addModels(List<CatalogItem> githubRepositories, String query, OnItemSelected<CatalogItem> itemSelected);
	void updateModels(List<CatalogItem> githubRepositories, String query, OnItemSelected<CatalogItem> itemSelected);
}

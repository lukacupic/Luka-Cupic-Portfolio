package hr.com.solo.solo.edit.main;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import hr.com.solo.solo.R;
import hr.com.solo.solo.core.CoreApplication;
import hr.com.solo.solo.models.CreateReceiptBody;
import hr.com.solo.solo.edit.main.interactors.EditReceiptUseCase;
import hr.com.solo.solo.main.models.CatalogItem;
import io.reactivex.Scheduler;

// 2017-04-08 Ian Rumac

public class EditReceiptPresenter implements EditReceiptContract.EditReceiptPresenter {
	private EditReceiptContract.EditReceiptView view;
	private final EditReceiptUseCase useCase;
	private final Scheduler postExecution;
	final int THROTTLE = 200;

	@Inject
	public EditReceiptPresenter(EditReceiptUseCase useCase, @Named("post_execution") Scheduler postExecution) {
		this.postExecution = postExecution;
		this.useCase = useCase;
	}

	private void displayResults(List<CatalogItem> results) {
		if (results.isEmpty()) {
			view.displayEmpty();
		} else {
			displayItems(results);
			view.hideLoading();
		}
	}

	@Override
	public void attachView(EditReceiptContract.EditReceiptView view) {
		this.view = view;
		useCase.executeWithParams(true).subscribe(this::displayResults, this::handleError);
	}

	@Override
	public void detachView(EditReceiptContract.EditReceiptView view) {
		this.view = null;
	}

	@Override
	public void handleError(Throwable throwable) {
		throwable.printStackTrace();
		view.displayError(CoreApplication.getInstance().getString(R.string.conn_error));
	}

	@Override
	public void displayItems(List<CatalogItem> itemList) {
		view.addNewItems(itemList);
	}

	@Override
	public void createReceiptBody(List<CatalogItem> catalogItems) {
		CreateReceiptBody receiptBody = new CreateReceiptBody();
/*  "usluga" = "1"; <- nedostajalo ti je ovo
  "opis_usluge_1" = "Jaja";
  "jed_mjera_1" = "1"; <- nedostajalo ti je ovo
  "cijena_1" = "1,5"; <- decimale _moraju_ biti odvojene zarezom jer API briše točke
  "kolicina_1" = "10" <- količina također može imati decimale odvojene zarezom
  "popust_1" = "0"; <- popust također može imati decimale odvojene zarezom
  "porez_stopa_1" = "25";
*/
		for (int i = 0; i < catalogItems.size(); i++) {
			CatalogItem currItem = catalogItems.get(i);
			String itemNumber = String.valueOf(i + 1);
			receiptBody.put("usluga", itemNumber);
			receiptBody.put("jed_mjera_".concat(itemNumber), currItem.getAmountUnit());
			receiptBody.put("opis_usluge_".concat(itemNumber), currItem.getDescription());
			receiptBody.put("cijena_".concat(itemNumber), currItem.getPrice());
			receiptBody.put("kolicina_".concat(itemNumber), currItem.getAmount());
			receiptBody.put("popust_".concat(itemNumber), currItem.getDiscount());
			receiptBody.put("porez_stopa_".concat(itemNumber), currItem.getTax());
		}

		view.setupReceipt(receiptBody);
	}
}

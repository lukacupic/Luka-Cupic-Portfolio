package hr.com.solo.solo.archive.search.network;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

// 2017-04-08 Ian Rumac

public class ReceiptItemListResponseWrapper implements Serializable{
	@SerializedName("status") public final int status;
	@SerializedName("racuni") public final List<ReceiptResponseItem> itemList;
	@SerializedName("message") public final String message;
	public ReceiptItemListResponseWrapper(int status, boolean incompleteResults, List<ReceiptResponseItem> itemList, String message) {
		this.status = status;
		this.itemList = itemList;
		this.message = message;
	}
}

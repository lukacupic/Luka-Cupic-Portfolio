package hr.com.solo.solo.edit.main.repositories;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import hr.com.solo.solo.core.UserCatalogManager;
import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.main.source.NewReceiptNetworkSource;
import io.reactivex.Scheduler;
import io.reactivex.Single;

// 2017-04-09 Ian Rumac

public class EditReceiptDetailsRepository implements EditReceiptRepository {
	Scheduler executionScheduler;
	UserCatalogManager dataSource;
	@Inject
	public EditReceiptDetailsRepository(UserCatalogManager dataSource, @Named("io") Scheduler execution) {
		this.dataSource = dataSource;
		this.executionScheduler = execution;
	}

	@Override
	public Single<List<CatalogItem>> fetchChosenItems() {
		return Single.just(new ArrayList<>(dataSource.getChosenCatalogItems()));
	}
}

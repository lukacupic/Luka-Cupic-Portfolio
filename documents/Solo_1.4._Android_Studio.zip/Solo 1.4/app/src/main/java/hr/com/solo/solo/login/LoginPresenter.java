package hr.com.solo.solo.login;

import java.net.UnknownHostException;

import hr.com.solo.solo.login.models.LoginModel;
import hr.com.solo.solo.networking.SoloService;
import hr.com.solo.solo.utils.RetrofitException;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import timber.log.Timber;

// 2017-05-01 Ian Rumac

public class LoginPresenter {
	SoloService service;
	LoginContract.LoginView view;
	public LoginPresenter(SoloService service, LoginContract.LoginView view) {
		this.service = service;
		this.view = view;
	}

	public void loginUser(String name, String password){
		view.showLoading();
		service.loginUser(name, password).observeOn(AndroidSchedulers.mainThread())
				.subscribeOn(Schedulers.io())
				.subscribe(new Consumer<LoginModel>() {
					@Override
					public void accept(LoginModel loginModel) throws Exception {
						view.hideLoading();

						switch (loginModel.getStatus()){
							case 101:
							case 102:
								view.showMessageError(loginModel.getMessage());
								break;
							case 0:
								view.loginSuccessfully(loginModel.getToken());
								break;
						}
					}
				}, new Consumer<Throwable>() {
					@Override
					public void accept(Throwable throwable) throws Exception {
						view.hideLoading();
						throwable.printStackTrace();
						try{
						if(throwable instanceof RetrofitException) {
							RetrofitException error = (RetrofitException) throwable;
							if (error.getResponse().code() > 500) {
								view.showMessageError("Solo trenutno nije dostupan. Pokušaj ponovo za par minuta.");
							} else {
								view.showMessageError("Došlo je do greške u prikazu. Pokušaj ponovo ili nas kontaktiraj.");
							}
							Timber.e(error.getResponse().code() + " code - body is: " + error.getResponse().message());

						}else{
							view.showMessageError("Solo trenutno nije dostupan. Pokušaj ponovo za par minuta.");

						}}catch (Exception e	){
							view.showMessageError("Solo trenutno nije dostupan. Pokušaj ponovo za par minuta.");
						}
					}
				});
	}
}

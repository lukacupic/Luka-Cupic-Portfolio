package hr.com.solo.solo.printer;

import com.starmicronics.stario.StarIOPort;
import com.starmicronics.stario.StarIOPortException;
import com.starmicronics.stario.StarPrinterStatus;
import com.starmicronics.starioextension.ICommandBuilder;
import com.starmicronics.starioextension.StarIoExt;

import java.nio.charset.Charset;

// 2018-09-10 Ishaq Sandouqa
// 2020-12-17 Farhad Bhuiyan (QR code)
// 2022-11-15 Luka

public class StarPrinter extends BasePrinter {

    private StarIOPort mPort;

    public StarPrinter(PrinterStatusCallback printerStatusCallback) {
        super(printerStatusCallback);
    }

    // INTERFACE METHODS

    @Override
    public void connectPrinter(String address, String name) {
        executeAsync(() -> {
            try {
                statusCallback.onStatus(PrinterStatusCallback.STATUS.CONNECTING);
                int model = StarModelCapability.getModel(name);
                String portSettings = StarModelCapability.getPortSettings(model);

                mPort = StarIOPort.getPort("BT:", portSettings, 10000);
                statusCallback.onStatus(PrinterStatusCallback.STATUS.CONNECTED);
                setConnected(true);
            } catch (StarIOPortException ex) {
                statusCallback.onStatus(PrinterStatusCallback.STATUS.ERROR);
            }
        });
    }

    @Override
    public void printInvoice(Object invoice, Object qrCode) {
        executeAsync(() -> {
            StarIoExt.Emulation emulation = StarIoExt.Emulation.None;
            byte[] textReceiptData = createTextReceiptData(emulation, (String) invoice, (String) qrCode);
            SendCommandThread sendCommandThread = new SendCommandThread(new Object(), textReceiptData, mPort);
            sendCommandThread.start();
        });
    }

    @Override
    public void disconnectPrinter() {
        setConnected(false);
    }

    // END OF INTERFACE METHODS

    // PRIVATE METHODS

    private static byte[] createTextReceiptData(StarIoExt.Emulation emulation, String text, String qr) {
        ICommandBuilder builder = StarIoExt.createCommandBuilder(emulation);
        Charset encoding = Charset.forName("Windows-1250");
        builder.beginDocument();
        builder.appendCodePage(ICommandBuilder.CodePageType.CP1250);
        builder.appendCharacterSpace(0);
        builder.appendAlignment(ICommandBuilder.AlignmentPosition.Left);
        builder.append(text.getBytes(encoding));
        builder.appendLineFeed(1);
        if (qr != null) {
            builder.appendQrCodeWithAlignment(
                    qr.getBytes(),
                    ICommandBuilder.QrCodeModel.No2,
                    ICommandBuilder.QrCodeLevel.L,
                    5,
                    ICommandBuilder.AlignmentPosition.Center
            );
            builder.appendLineFeed(3);
        }
        builder.endDocument();
        return builder.getCommands();
    }

    // END OF PRIVATE METHODS

    class SendCommandThread extends Thread {
        private final Object mLock;
        private final byte[] mCommands;
        private final StarIOPort mPort;

        SendCommandThread(Object lock, byte[] commands, StarIOPort port) {
            mCommands = commands;
            mPort = port;
            mLock = lock;
        }

        @Override
        public void run() {
            synchronized (mLock) {
                try {
                    if (mPort == null) {
                        statusCallback.onStatus(PrinterStatusCallback.STATUS.NOT_SUPPORTED);
                        return;
                    }

                    StarPrinterStatus status = mPort.beginCheckedBlock();

                    if (status.offline) {
                        statusCallback.onStatus(PrinterStatusCallback.STATUS.NOT_SUPPORTED);
                        return;
                    }

                    mPort.writePort(mCommands, 0, mCommands.length);
                    mPort.setEndCheckedBlockTimeoutMillis(30000); // 30000 ms!!!
                    status = mPort.endCheckedBlock();

                    if (status.coverOpen || status.receiptPaperEmpty || status.offline) {
                        statusCallback.onStatus(PrinterStatusCallback.STATUS.ERROR);
                        return;
                    }

                } catch (StarIOPortException e) {
                    statusCallback.onStatus(PrinterStatusCallback.STATUS.NOT_SUPPORTED);
                    return;
                }

                statusCallback.onStatus(PrinterStatusCallback.STATUS.DONE);
            }
        }
    }
}

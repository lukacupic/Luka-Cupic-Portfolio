package hr.com.solo.solo.edit.main.ui.viewmodels;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

import com.airbnb.epoxy.EpoxyAdapter;
import com.airbnb.epoxy.EpoxyHolder;
import com.airbnb.epoxy.EpoxyModel;
import com.airbnb.epoxy.EpoxyModelWithHolder;

import java.util.Iterator;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.R;
import hr.com.solo.solo.models.TaxCategoryContainer;

// 2017-06-14 Ian Rumac

public class TaxCotainerBig extends EpoxyModelWithHolder<TaxCotainerBig.CompleteTaxHolder> {
	Map<String, TaxCategoryContainer> taxCategoryContainerMap;
	TaxAdapter taxAdapter;

	public TaxCotainerBig(Map<String, TaxCategoryContainer> taxCategoryContainerMap) {
		this.taxCategoryContainerMap = taxCategoryContainerMap;
		this.taxAdapter = new TaxAdapter();
		for (Map.Entry<String, TaxCategoryContainer> item : taxCategoryContainerMap.entrySet()) {
			taxAdapter.add(new ReceiptTaxViewModel(item.getKey(), item.getValue(), boo -> {
			}));
		}
	}

	public void notifyTaxesChanged(Map<String, TaxCategoryContainer> taxCategoryContainerMap) {
		if (taxAdapter != null)
			taxAdapter.notifyTaxesChanged(taxCategoryContainerMap);
	}

	@Override
	protected TaxCotainerBig.CompleteTaxHolder createNewHolder() {
		return new CompleteTaxHolder();
	}

	@Override
	public void bind(CompleteTaxHolder holder) {
		holder.recycler.setLayoutManager(new LinearLayoutManager(holder.recycler.getContext(), LinearLayoutManager.VERTICAL, false));
		holder.recycler.setAdapter(taxAdapter);
	}

	@Override
	protected int getDefaultLayout() {
		return R.layout.tax_container_big;
	}

	static class CompleteTaxHolder extends EpoxyHolder {
		@BindView(R.id.recycler)
		RecyclerView recycler;

		@Override
		protected void bindView(View itemView) {
			ButterKnife.bind(this, itemView);
		}
	}

	public class TaxAdapter extends EpoxyAdapter {

		public void add(EpoxyModel model) {
			addModel(model);
		}

		public void notifyTaxesChanged(Map<String, TaxCategoryContainer> taxCategoryContainerMap) {
			Iterator itr = models.iterator();
			while (itr.hasNext()) {
				EpoxyModel model = (EpoxyModel) itr.next();
				if (model instanceof ReceiptTaxViewModel)
					itr.remove();
			}

			for (Map.Entry<String, TaxCategoryContainer> item : taxCategoryContainerMap.entrySet()) {
				addModel(new ReceiptTaxViewModel(item.getKey(), item.getValue(), boo -> {
				}));
			}
			notifyModelsChanged();
		}
	}
}

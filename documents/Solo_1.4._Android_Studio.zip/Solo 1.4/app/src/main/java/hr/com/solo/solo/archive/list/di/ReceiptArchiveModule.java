package hr.com.solo.solo.archive.list.di;

import javax.inject.Named;

import dagger.Module;
import dagger.Provides;
import hr.com.solo.solo.archive.list.ReceiptArchiveContract;
import hr.com.solo.solo.archive.list.interactors.GetReceiptArchiveUseCase;
import hr.com.solo.solo.archive.list.repositories.ReceiptArchiveRepository;
import hr.com.solo.solo.archive.list.repositories.ReceiptArchiveRepositoryImpl;
import hr.com.solo.solo.archive.list.source.GetReceiptsNetworkSource;
import hr.com.solo.solo.archive.list.source.GetReceiptNetworkSourceImpl;
import hr.com.solo.solo.archive.list.ui.ReceiptArchivePresenterImpl;
import hr.com.solo.solo.core.UserReceiptManager;
import hr.com.solo.solo.core.di.PerFragment;
import hr.com.solo.solo.networking.SoloService;
import io.reactivex.Scheduler;

// 2017-04-08 Ian Rumac

@Module
public class ReceiptArchiveModule {
	@Provides
	@PerFragment
	GetReceiptsNetworkSource provideSource(SoloService service) {
		return new GetReceiptNetworkSourceImpl(service);
	}

	@Provides
	@PerFragment
	ReceiptArchiveRepository provideRepositoryDetailsRepository(GetReceiptsNetworkSource network,UserReceiptManager source, @Named("io") Scheduler io) {
		return new ReceiptArchiveRepositoryImpl(network,source, io);
	}

	@Provides
	@PerFragment
	GetReceiptArchiveUseCase provideGetRepositoryDetailsUseCase(ReceiptArchiveRepository repository) {
		return new GetReceiptArchiveUseCase(repository);
	}

	@Provides
	@PerFragment
	ReceiptArchiveContract.ReceiptArchivePresenter providePresenter(GetReceiptArchiveUseCase repositoriesUseCase, @Named("post_execution") Scheduler postExecution) {
		return new ReceiptArchivePresenterImpl(repositoriesUseCase,postExecution);
	}
}

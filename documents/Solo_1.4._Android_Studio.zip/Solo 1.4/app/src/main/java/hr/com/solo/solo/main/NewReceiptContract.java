package hr.com.solo.solo.main;

import java.util.List;

import hr.com.solo.solo.base.BaseView;
import hr.com.solo.solo.base.Presenter;
import hr.com.solo.solo.main.models.CatalogItem;

// 2017-04-09 Ian Rumac

public interface NewReceiptContract {
	interface NewReceiptView extends BaseView {
		void addNewItem(CatalogItem githubRepositoryInfo);
		void addItems(List<CatalogItem> items);
		void displayEmpty();
		void removeItem();
		void showMessageError(String error);
	}

	interface NewReceiptPresenter extends Presenter<NewReceiptView> {
		void getCatalogItems(String token, boolean isRefresh);
	}
}

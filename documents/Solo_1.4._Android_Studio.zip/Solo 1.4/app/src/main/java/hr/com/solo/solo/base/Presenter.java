package hr.com.solo.solo.base;

// 2017-04-08 Ian Rumac

public interface Presenter<T extends BaseView> {
	void attachView(T view);
	void detachView(T view);
	void handleError(Throwable throwable);
}

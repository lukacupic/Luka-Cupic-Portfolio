package hr.com.solo.solo.edit.main.source;

import hr.com.solo.solo.main.models.CatalogItem;
import io.reactivex.Single;

// 2017-04-09 Ian Rumac

public interface NewReceiptNetworkSource {
	Single<CatalogItem> getRepositoryDetails(String owner, String repositoryName);
}

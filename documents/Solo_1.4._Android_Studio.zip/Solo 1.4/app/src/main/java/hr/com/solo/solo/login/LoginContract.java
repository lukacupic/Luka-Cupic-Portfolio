package hr.com.solo.solo.login;

import hr.com.solo.solo.login.models.LoginModel;

// 2017-05-01 Ian Rumac

public interface LoginContract {
	public interface LoginView{
		void showMessageError(String error);
		void showLoading();
		void hideLoading();
		void loginSuccessfully(String token);
	}
}

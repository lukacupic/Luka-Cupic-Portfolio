package hr.com.solo.solo.search;

import hr.com.solo.solo.base.BaseView;
import hr.com.solo.solo.base.Presenter;
import hr.com.solo.solo.main.models.CatalogItem;

import java.util.List;

import io.reactivex.Observable;

// 2017-04-08 Ian Rumac

public interface SearchContract {
	interface SearchView extends BaseView {
		void displayResults(List<CatalogItem> results);
		Observable<String> getSearchObservable();
		void displayEmpty();
		void displayError(String message);
		void done();
	}

	interface SearchPresenter extends Presenter<SearchView> {
		void addItemToBasket(CatalogItem item);
	}
}

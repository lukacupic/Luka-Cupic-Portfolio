package hr.com.solo.solo.main.interactors;

import hr.com.solo.solo.base.UseCase;
import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.main.repositories.CatalogDetailsRepository;

import javax.inject.Inject;

import hr.com.solo.solo.search.models.network.ItemListResponseWrapper;
import io.reactivex.Observable;

// 2017-04-09 Ian Rumac

public class NewReceiptUseCase extends UseCase<ItemListResponseWrapper, String> {
	private final CatalogDetailsRepository repository;

	@Inject
	public NewReceiptUseCase(CatalogDetailsRepository repository) {
		this.repository = repository;
	}

	@Override
	public Observable<ItemListResponseWrapper> executeWithParams(String query) {
		return repository.fetchCatalog(query).toObservable();
	}
}

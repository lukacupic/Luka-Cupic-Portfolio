package hr.com.solo.solo.archive.search.network;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

// 2017-04-08 Ian Rumac

public class ReceiptResponseItem implements Serializable{

	/**
	 * id : 8791cae3c9b02bb8d88bf626247b4e67dfbe20e35fc0342b448f39c9264c591d
	 * broj_racuna : 1-1-1
	 * datum_racuna : 1.8.2016. 13:00:00
	 * bruto_suma : 24,99
	 * status : 1
	 * boja : #ffcf03
	 */

	@SerializedName("id") private String id;
	@SerializedName("broj_racuna") private String brojRacuna;
	@SerializedName("datum_racuna") private String datumRacuna;
	@SerializedName("bruto_suma") private String brutoSuma;
	@SerializedName("status") private String status;
	@SerializedName("boja") private String boja;

	public String getId() { return id; }
	public void setId(String id) { this.id = id; }

	public String getBrojRacuna() {
		return brojRacuna;
	}
	public void setBrojRacuna(String brojRacuna) {
		this.brojRacuna = brojRacuna;
	}

	public String getDatumRacuna() {
		return datumRacuna;
	}
	public void setDatumRacuna(String datumRacuna) {
		this.datumRacuna = datumRacuna;
	}

	public String getBrutoSuma() {
		return brutoSuma;
	}
	public void setBrutoSuma(String brutoSuma) {
		this.brutoSuma = brutoSuma;
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public String getBoja() {
		return boja;
	}
	public void setBoja(String boja) {
		this.boja = boja;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		ReceiptResponseItem that = (ReceiptResponseItem) o;

		return brojRacuna != null ? brojRacuna.equals(that.brojRacuna) : that.brojRacuna == null;
	}

	@Override
	public int hashCode() {
		return brojRacuna != null ? brojRacuna.hashCode() : 0;
	}
}


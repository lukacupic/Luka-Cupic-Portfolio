package hr.com.solo.solo.search.source;

import hr.com.solo.solo.networking.SoloService;
import hr.com.solo.solo.search.mappers.SearchResultMapper;
import hr.com.solo.solo.utils.Constants;

import java.util.List;

import javax.inject.Inject;

import io.reactivex.Observable;

// 2017-04-08 Ian Rumac

public class SearchNetworkSource implements SearchSource {
	private final SoloService apiService;
	private final SearchResultMapper mapper;

	@Inject
	public SearchNetworkSource(SoloService apiService, SearchResultMapper mapper) {
		this.apiService = apiService;
		this.mapper = mapper;
	}

/*
	@Override
	public Observable<List<GithubRepository>> searchRepositoriesByQuery(String query, String sort, String order, int page) {

		return mapper.mapResponseResultToList(apiService.getItemsForUser(query, sort, order, page, Constants.PER_PAGE_MAX));
	}
*/
}

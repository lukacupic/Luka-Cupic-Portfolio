package hr.com.solo.solo;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Set;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.base.BaseActivity;
import hr.com.solo.solo.main.ui.NewReceiptActivity;
import hr.com.solo.solo.models.PrinterItem;
import hr.com.solo.solo.printer.IPrinter;
import hr.com.solo.solo.printer.PrinterFactory;
import hr.com.solo.solo.printer.PrinterStatusCallback;
import hr.com.solo.solo.utils.OnItemSelected;
import hr.com.solo.solo.utils.PrefsUtils;
import hr.com.solo.solo.utils.PrinterUtils;

// 2017-04-25 Ian Rumac
// 2022-11-27 Luka

public class SettingsActivity extends BaseActivity implements OnItemSelected<PrinterItem>,
        CompoundButton.OnCheckedChangeListener, PrinterStatusCallback {

    @BindView(R.id.ic_back)
    ImageView mIVBackButton;

    @BindView(R.id.text_empty)
    TextView mTVEmptyDevices;

    @BindView(R.id.listViewPairedDevices)
    RecyclerView mLVPairedDevices;

    @BindView(R.id.fiscal_switch)
    Switch mSWFiscalSwitch;

    @BindView(R.id.tv_no_devices)
    TextView mTVNoDevices;

    private final ArrayList<PrinterItem> mPairedDevices = new ArrayList<>();
    private SettingsListAdapter mListAdapter;
    private BluetoothAdapter mBtAdapter;
    private IPrinter mPrinter;

    private void getPairedDevices() {
        if (mBtAdapter != null && mBtAdapter.isEnabled()) {
            // Get a set of currently paired devices
            Set<BluetoothDevice> pairedDevices = mBtAdapter.getBondedDevices();
            // If there are paired devices, add each one to the ArrayAdapter
            if (pairedDevices.size() > 0) {
                mPairedDevices.clear();
                for (BluetoothDevice device : pairedDevices) {
                    if (PrinterUtils.isSupported(device.getName())) {
                        mPairedDevices.add(new PrinterItem(device.getName(), device.getAddress(), PrinterItem.BT));
                    }
                }
                showHideNoPairedDevicesMessage(false);
                setupPairedDevicesList();
            } else {
                PrefsUtils.savePrinter(null, null, 0, null);
                showHideNoPairedDevicesMessage(true);
            }
        } else {
            PrefsUtils.savePrinter(null, null, 0, null);
            showHideNoPairedDevicesMessage(true);
        }
    }

    private void showHideNoPairedDevicesMessage(boolean show) {
        mTVNoDevices.setVisibility(show ? View.VISIBLE : View.GONE);
        mLVPairedDevices.setVisibility(show ? View.GONE : View.VISIBLE);
    }

    private void setupPairedDevicesList() {
        mListAdapter = new SettingsListAdapter(mPairedDevices, this);
        mLVPairedDevices.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        mLVPairedDevices.setVisibility(mPairedDevices.isEmpty() ? View.GONE : View.VISIBLE);
        mTVEmptyDevices.setVisibility(mPairedDevices.isEmpty() ? View.VISIBLE : View.GONE);
        mLVPairedDevices.setAdapter(mListAdapter);

        if (mListAdapter != null) {
            mListAdapter.notifyDataSetChanged();
        }
    }

    public void connectPrinter(String printerName, String macAddress, String printerRetailer) {
        NewReceiptActivity.printer = PrinterFactory.getPrinter(printerRetailer, this, this);
        if (NewReceiptActivity.printer != null) {
            mListAdapter.enableButtons(false);
            NewReceiptActivity.printer.connectPrinter(macAddress, printerName);
        }
    }

    private void firstConnect() {
        String mac = PrefsUtils.getPrinterMac();
        if (mac != null) {
            String name = PrefsUtils.getPrinterName();
            String retailer = PrefsUtils.getPrinterRetailer();

            if (NewReceiptActivity.printer == null) {
                connectPrinter(name, mac, retailer);
            }
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        ButterKnife.bind(this);

        mBtAdapter = BluetoothAdapter.getDefaultAdapter();

        mIVBackButton.setOnClickListener(view -> onBackPressed());
        mSWFiscalSwitch.setChecked(PrefsUtils.isFiscalEnabled());
        mSWFiscalSwitch.setOnCheckedChangeListener(this);

        getPairedDevices();
        firstConnect();
    }

    @Override
    public void showLoading() {
    }

    @Override
    public void hideLoading() {
    }

    @Override
    public void displayError(String message) {
    }

    @Override
    public void itemSelected(PrinterItem printer) {
        // if some printer is already connected, disconnect it
        if (NewReceiptActivity.printer != null) {
            if (NewReceiptActivity.printer.isConnected()) {
                NewReceiptActivity.printer.disconnectPrinter();
            }
            NewReceiptActivity.printer = null;
        }

        if (printer != null && printer.isActive()) {
            String name = printer.getName();
            String address = printer.getMacAddress();
            String retailer = PrinterUtils.getRetailer(name);
            PrefsUtils.savePrinter(address, name, printer.getType(), retailer);

            if (mPrinter != null) {
                mPrinter.disconnectPrinter();
            }
            mPrinter = PrinterFactory.getPrinter(retailer, this, this);

            connectPrinter(name, address, retailer);

            if (mPrinter == null) {
                onStatus(STATUS.NOT_SUPPORTED);
            }
        } else {
            PrefsUtils.savePrinter(null, null, 0, null);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mPrinter != null) {
            if (mPrinter.isConnected()) {
                mPrinter.disconnectPrinter();
            }
            mPrinter = null;
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        PrefsUtils.setFiscalEnabled(isChecked);
    }

    @Override
    public void onStatus(STATUS status) {
        runOnUiThread(() -> {
            if (status != STATUS.CONNECTING) {
                mListAdapter.enableButtons(true);
            }

            if (status == STATUS.NOT_SUPPORTED) {
                PrefsUtils.savePrinter(null, null, 0, null);
                mListAdapter.notifyDataSetChanged();
            }

            Toast.makeText(SettingsActivity.this, status.getMessage(), Toast.LENGTH_LONG).show();
        });
    }

    @Override
    public void onMessage(String message) {
        runOnUiThread(() -> Toast.makeText(SettingsActivity.this, message, Toast.LENGTH_LONG).show());
    }
}

package hr.com.solo.solo.archive.list.source;

import javax.inject.Inject;

import hr.com.solo.solo.archive.search.network.ReceiptItemListResponseWrapper;
import hr.com.solo.solo.networking.SoloService;
import hr.com.solo.solo.utils.PrefsUtils;
import io.reactivex.Single;
import io.reactivex.schedulers.Schedulers;

// 2017-04-09 Ian Rumac

public class GetReceiptNetworkSourceImpl implements GetReceiptsNetworkSource {
	SoloService apiService;

	@Inject
	public GetReceiptNetworkSourceImpl(SoloService apiService) {
		this.apiService = apiService;
	}

	@Override
	public Single<ReceiptItemListResponseWrapper> getReceipts(String token) {
		if (System.currentTimeMillis() - 60 * 1000 > PrefsUtils.returnReceiptLastDownload()) {
			return apiService.getReceipt(1, token, null).subscribeOn(Schedulers.io());
		} else {
			return Single.just(PrefsUtils.returnReceiptCatalogItems());
		}
	}
}

package hr.com.solo.solo.base;

import io.reactivex.Observable;
import io.reactivex.functions.Consumer;

// 2017-04-08 Ian Rumac

public abstract class UseCase<T, Params> {
	protected abstract Observable<T> executeWithParams(Params query);

	public void executeWithParams(Params query, Consumer<T> onNext, Consumer<Throwable> onError) {
		executeWithParams(query).subscribe(onNext, onError);

	}
}

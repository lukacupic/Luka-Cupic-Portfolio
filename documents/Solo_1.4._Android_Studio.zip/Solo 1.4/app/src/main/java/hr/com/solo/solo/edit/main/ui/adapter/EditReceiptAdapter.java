package hr.com.solo.solo.edit.main.ui.adapter;

import android.util.Pair;
import android.view.View;

import com.airbnb.epoxy.EpoxyAdapter;
import com.airbnb.epoxy.EpoxyModel;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import hr.com.solo.solo.core.UserCatalogManager;
import hr.com.solo.solo.edit.main.ui.viewmodels.EditableReceiptItemViewModel;
import hr.com.solo.solo.edit.main.ui.viewmodels.ReceiptButton;
import hr.com.solo.solo.edit.main.ui.viewmodels.ReceiptHeader;
import hr.com.solo.solo.edit.main.ui.viewmodels.ReceiptTaxViewModel;
import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.models.TaxCategoryContainer;
import hr.com.solo.solo.utils.OnItemSelected;

// 2017-04-21 Ian Rumac

public class EditReceiptAdapter extends EpoxyAdapter {

	Set<CatalogItem> catalogItems;
	OnItemSelected<Double> doubleOnItemSelected;
	UserCatalogManager manager;

	public EditReceiptAdapter(UserCatalogManager manager) {
		this.manager = manager;
		catalogItems = new HashSet<>();
		enableDiffing();
	}

	public void displayEmpty() {
		int size = models.size();
		models.clear();
		notifyItemRangeRemoved(0, size);
	}

	public void addItems(List<CatalogItem> itemList, View.OnClickListener clickListener) {
		models.clear();
		for (CatalogItem item : itemList) {
			addItem(item);
		}

		for(Map.Entry<String, TaxCategoryContainer> item: manager.getChosenCatalogItemsByTax().entrySet()) {
			models.add(new ReceiptTaxViewModel(item.getKey(),item.getValue(), boo -> {}));
		}

		models.add(new ReceiptButton(clickListener));
		notifyModelsChanged();
	}

	public void notifyTaxesChanged(){
		Iterator itr = models.iterator();
		while(itr.hasNext()){
			EpoxyModel model = (EpoxyModel) itr.next();
			if(model instanceof ReceiptTaxViewModel)
				itr.remove();
		}

		for(Map.Entry<String, TaxCategoryContainer> item: manager.getChosenCatalogItemsByTax().entrySet()) {
			models.add(models.size()-1,new ReceiptTaxViewModel(item.getKey(),item.getValue(), boo -> {}));
		}
		notifyModelsChanged();
	}

	public void addItem(CatalogItem item) {
		models.add(new EditableReceiptItemViewModel(item, new OnItemSelected<CatalogItem>() {
			@Override
			public void itemSelected(CatalogItem item) {
				manager.remove(item);
				for (EpoxyModel model : models) {
					if (model instanceof EditableReceiptItemViewModel) {
						if (((EditableReceiptItemViewModel) model).getResult().equals(item)) {
							removeModel(model);
							break;
						}

					}
				}
			}
		}));
	}
}

package hr.com.solo.solo.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

// 2017-04-10 Ian Rumac

public class DateTimeUtils {
	private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault());
	private static final SimpleDateFormat output = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());

	public static String dayMonthYearFromISODateTime(String date) {
		Date d = new Date();
		try {
			if (date != null) {
				d = sdf.parse(date);
			}
			return output.format(d);
		} catch (ParseException e) {
			e.printStackTrace();
			return date;
		}
	}
}

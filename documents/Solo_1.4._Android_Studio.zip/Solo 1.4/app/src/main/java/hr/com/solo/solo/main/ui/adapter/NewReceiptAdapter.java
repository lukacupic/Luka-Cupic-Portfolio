package hr.com.solo.solo.main.ui.adapter;

import com.airbnb.epoxy.EpoxyAdapter;
import com.airbnb.epoxy.EpoxyModel;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

import hr.com.solo.solo.core.UserCatalogManager;
import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.main.ui.viewmodels.ReceiptHeader;
import hr.com.solo.solo.search.ui.viewmodels.CatalogItemViewModel;
import hr.com.solo.solo.utils.OnItemSelected;

// 2017-04-21 Ian Rumac

public class NewReceiptAdapter extends EpoxyAdapter {
	Set<CatalogItem> catalogItems;
	UserCatalogManager manager;

	public NewReceiptAdapter(UserCatalogManager manager) {
		catalogItems = new HashSet<>();
		this.manager = manager;
	}

	public void displayEmpty() {
		int size = models.size();
		models.clear();
		notifyItemRangeRemoved(0, size);
	}

	public void addItems(List<CatalogItem> itemList, OnItemSelected<CatalogItem> itemOnItemSelected) {
		models.clear();
		for (CatalogItem item : itemList) {
			addItem(item, itemOnItemSelected);
		}

		notifyDataSetChanged();
	}

	public void notifyModelsChanged() {
		notifyDataSetChanged();
	}

	public void addItem(CatalogItem item, OnItemSelected<CatalogItem> itemOnItemSelected) {
		models.add(new CatalogItemViewModel(item, itemOnItemSelected, manager));
	}
}

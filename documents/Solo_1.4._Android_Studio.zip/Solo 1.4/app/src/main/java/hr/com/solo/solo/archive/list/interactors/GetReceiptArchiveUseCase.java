package hr.com.solo.solo.archive.list.interactors;

import java.util.List;

import javax.inject.Inject;

import hr.com.solo.solo.archive.list.repositories.ReceiptArchiveRepository;
import hr.com.solo.solo.archive.list.repositories.ReceiptArchiveRepositoryImpl;
import hr.com.solo.solo.archive.search.network.ReceiptItemListResponseWrapper;
import hr.com.solo.solo.archive.search.network.ReceiptResponseItem;
import hr.com.solo.solo.base.UseCase;
import io.reactivex.Observable;

// 2017-04-09 Ian Rumac

public class GetReceiptArchiveUseCase extends UseCase<ReceiptItemListResponseWrapper, String> {
	private final ReceiptArchiveRepository repository;

	@Inject
	public GetReceiptArchiveUseCase(ReceiptArchiveRepository repository) {
		this.repository = repository;
	}

	@Override
	public Observable<ReceiptItemListResponseWrapper> executeWithParams(String token) {
		return repository.fetchReceipts(token).toObservable();
	}
}

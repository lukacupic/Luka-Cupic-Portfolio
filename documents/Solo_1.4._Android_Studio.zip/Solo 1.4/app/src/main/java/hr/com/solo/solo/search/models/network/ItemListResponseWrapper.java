package hr.com.solo.solo.search.models.network;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

import hr.com.solo.solo.main.models.CatalogItem;

// 2017-04-08 Ian Rumac

public class ItemListResponseWrapper implements Serializable{
	@SerializedName("status") public final int status;
	@SerializedName("katalog") public final List<CatalogItem> itemList;
	@SerializedName("message")
	private String message;

	public ItemListResponseWrapper(int status, boolean incompleteResults, List<CatalogItem> itemList) {
		this.status = status;
		this.itemList = itemList;
	}
}

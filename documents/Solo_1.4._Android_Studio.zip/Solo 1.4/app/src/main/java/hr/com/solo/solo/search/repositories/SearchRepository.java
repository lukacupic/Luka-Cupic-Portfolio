package hr.com.solo.solo.search.repositories;

import hr.com.solo.solo.core.UserCatalogManager;
import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.search.source.SearchSource;

import java.util.List;

import javax.inject.Named;

import io.reactivex.Observable;
import io.reactivex.Scheduler;

// 2017-04-08 Ian Rumac

public class SearchRepository implements SearchRepositoryInterface {
	private final UserCatalogManager source;
	private final Scheduler schedulerExecution;

	public SearchRepository(UserCatalogManager source,
							@Named("io") Scheduler execution) {
		this.source = source;
		this.schedulerExecution = execution;
	}

	@Override
	public Observable<List<CatalogItem>> getItemsByQuery(String query) {
		return Observable.just(source.getItemsForQuery(query));
	}

	@Override
	public void addItem(CatalogItem item) {
		source.add(item);
	}

/*
	@Override
	public Observable<List<GithubRepository>> getRepositoriesByQuery(String query, String sort, String order, int page) {
		return source.searchRepositoriesByQuery(query, sort, order, page).subscribeOn(schedulerExecution);
	}
*/
}

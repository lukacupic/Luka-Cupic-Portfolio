package hr.com.solo.solo.edit.main;

import java.util.List;

import hr.com.solo.solo.models.CreateReceiptBody;
import hr.com.solo.solo.base.BaseView;
import hr.com.solo.solo.base.Presenter;
import hr.com.solo.solo.main.models.CatalogItem;

// 2017-04-09 Ian Rumac

public interface EditReceiptContract {
	interface EditReceiptView extends BaseView {
		void addNewItems(List<CatalogItem> listItems);
		void displayEmpty();
		void setupReceipt(CreateReceiptBody body);
		void removeItem();
	}

	interface EditReceiptPresenter extends Presenter<EditReceiptView> {
		void displayItems(List<CatalogItem> itemList);
		void createReceiptBody(List<CatalogItem> itemList);
	}
}

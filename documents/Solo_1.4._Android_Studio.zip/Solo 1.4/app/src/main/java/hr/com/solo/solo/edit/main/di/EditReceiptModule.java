package hr.com.solo.solo.edit.main.di;

import javax.inject.Named;

import dagger.Module;
import dagger.Provides;
import hr.com.solo.solo.core.UserCatalogManager;
import hr.com.solo.solo.core.di.PerFragment;
import hr.com.solo.solo.edit.main.EditReceiptContract;
import hr.com.solo.solo.edit.main.EditReceiptPresenter;
import hr.com.solo.solo.edit.main.interactors.EditReceiptUseCase;
import hr.com.solo.solo.edit.main.repositories.EditReceiptDetailsRepository;
import hr.com.solo.solo.edit.main.repositories.EditReceiptRepository;
import hr.com.solo.solo.edit.main.source.NewReceiptNetworkSource;
import hr.com.solo.solo.edit.main.source.NewReceiptNetworkSourceImpl;
import hr.com.solo.solo.networking.SoloService;
import io.reactivex.Scheduler;

// 2017-04-08 Ian Rumac

@Module
public class EditReceiptModule {
	@Provides
	@PerFragment
	NewReceiptNetworkSource provideSource(SoloService service) {
		return new NewReceiptNetworkSourceImpl(service);
	}

	@Provides
	@PerFragment
	EditReceiptRepository provideRepositoryDetailsRepository(UserCatalogManager source, @Named("io") Scheduler io) {
		return new EditReceiptDetailsRepository(source, io);
	}

	@Provides
	@PerFragment
	EditReceiptContract.EditReceiptPresenter providePresenter(EditReceiptUseCase repositoriesUseCase, @Named("post_execution") Scheduler postExecution) {
		return new EditReceiptPresenter(repositoriesUseCase,postExecution);
	}
}

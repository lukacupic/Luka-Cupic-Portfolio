package hr.com.solo.solo;

import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import hr.com.solo.solo.models.PrinterItem;
import hr.com.solo.solo.utils.OnItemSelected;
import hr.com.solo.solo.utils.PrefsUtils;

// 2017-06-13 Ian Rumac
// 2022-11-17 Luka

public class SettingsListAdapter extends RecyclerView.Adapter<SettingsListAdapter.ViewHolder> {
    private ArrayList<PrinterItem> printerItems;
    private OnItemSelected<PrinterItem> settingsActivity;
    private List<ViewHolder> mViewHolders;
    private boolean mButtonsEnabled = true;

    public SettingsListAdapter(ArrayList<PrinterItem> printerList, OnItemSelected<PrinterItem> settingsActivity) {
        this.printerItems = new ArrayList<>();
        this.printerItems.addAll(printerList);
        this.settingsActivity = settingsActivity;
        this.mViewHolders = new ArrayList<>();
    }

    private void updatePrinter(PrinterItem printer) {
        notifyDataSetChanged();
        settingsActivity.itemSelected(printer);
    }

    /**
     * Enable or disable all the buttons while the application is trying to connect to a printer.
     * The purpose of this method is to prevent the user from messing with the buttons.
     *
     * @param enable whether to enable the switch/toggle buttons
     */
    public synchronized void enableButtons(boolean enable) {
        mButtonsEnabled = enable;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.choice_check, parent, false);
        ViewHolder viewHolder = new ViewHolder(v);
        mViewHolders.add(viewHolder);
        return viewHolder;
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        PrinterItem printer = printerItems.get(position);
        holder.textmac.setText(printer.getMacAddress());
        holder.textname.setText(printer.getName());

        boolean isCurrentPrinterActive = PrefsUtils.getPrinterMac().equals(printer.getMacAddress());
        holder.textname.setChecked(isCurrentPrinterActive);

        holder.textname.setTag(printer);
        holder.textname.setOnClickListener(v -> {
            boolean newState = holder.textname.isChecked();
            printer.setActive(newState);

            if (newState) {
                for (ViewHolder viewHolder : mViewHolders) {
                    if (viewHolder != holder) {
                        viewHolder.textname.setChecked(false);
                    }
                }
            }
            updatePrinter(printer);
        });

        holder.textname.setOnTouchListener((v, event) -> !SettingsListAdapter.this.mButtonsEnabled);
    }

    @Override
    public int getItemCount() {
        return printerItems.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        @BindView(R.id.textname)
        Switch textname;

        @BindView(R.id.textmac)
        TextView textmac;

        ViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }

        public View getItemView() {
            return itemView;
        }
    }
}

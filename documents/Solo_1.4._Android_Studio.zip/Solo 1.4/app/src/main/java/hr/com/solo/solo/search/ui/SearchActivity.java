package hr.com.solo.solo.search.ui;

import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.jakewharton.rxbinding2.widget.RxTextView;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import hr.com.solo.solo.R;
import hr.com.solo.solo.base.BaseActivity;
import hr.com.solo.solo.core.CoreApplication;
import hr.com.solo.solo.core.UserCatalogManager;
import hr.com.solo.solo.main.models.CatalogItem;
import hr.com.solo.solo.navigation.Router;
import hr.com.solo.solo.search.SearchContract;
import hr.com.solo.solo.search.di.DaggerSearchComponent;
import hr.com.solo.solo.search.di.SearchComponent;
import hr.com.solo.solo.search.di.SearchComponentOwner;
import hr.com.solo.solo.search.di.SearchModule;
import hr.com.solo.solo.search.ui.adapters.SearchResultsEpoxyAdapter;
import hr.com.solo.solo.utils.CustomEditText;
import io.reactivex.Observable;

public class SearchActivity extends BaseActivity implements SearchContract.SearchView, SearchComponentOwner {

	@BindView(R.id.recycler_result_list) RecyclerView recyclerResultList;
	@BindView(R.id.search_field) CustomEditText editText;
	@BindView(R.id.empty) TextView emptyText;
	@Inject SearchContract.SearchPresenter presenter;
	@Inject Router router;
	@Inject SearchResultsEpoxyAdapter adapter;
	@Inject UserCatalogManager manager;

	SearchComponent searchComponent;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_search);
		ButterKnife.bind(this);

		searchComponent = DaggerSearchComponent.builder()
				.coreComponent(CoreApplication.getInstance().getComponent())
				.searchModule(new SearchModule(this, getSupportFragmentManager()))
				.build();
		searchComponent.inject(this);
		presenter.attachView(this);
		if (manager.isEmpty()) {
			emptyText.setText(R.string.katalog_prazan);
		} else {
			emptyText.setVisibility(View.GONE);
		}


		setupRecyclerViewWithAdapter();
	}

	@OnClick(R.id.ic_back)
	void goBack() {
		onBackPressed();
	}

	private void setupRecyclerViewWithAdapter() {
		recyclerResultList.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
		recyclerResultList.setAdapter(adapter);
		RecyclerView.ItemAnimator animator = recyclerResultList.getItemAnimator();
		if (animator instanceof SimpleItemAnimator) {
			((SimpleItemAnimator) animator).setSupportsChangeAnimations(false);
		}

	}

	@Override
	public void showLoading() { }

	@Override
	public void hideLoading() { }

	@Override
	public void displayResults(List<CatalogItem> results) {
		if (editText.getText().toString().isEmpty()) {
			displayEmpty();
		} else {
			if (recyclerResultList.getVisibility() != View.VISIBLE) {
				recyclerResultList.setVisibility(View.VISIBLE);
				emptyText.setVisibility(View.GONE);

			}
			adapter.updateModels(results, editText.getText().toString(), item -> presenter.addItemToBasket(item));
		}
	}

	@Override
	public Observable<String> getSearchObservable() {
		return RxTextView.textChanges(editText).map(CharSequence::toString);
	}

	@Override
	public void displayEmpty() {
		if (!editText.getText().toString().isEmpty()) {
			if (manager.isEmpty()) {
				emptyText.setText(getString(R.string.katalog_prazan));
			} else {
				emptyText.setText(getString(R.string.article_not_found));
			}
		emptyText.setVisibility(View.VISIBLE);
		}else emptyText.setVisibility(View.GONE);
		recyclerResultList.setVisibility(View.GONE);
		adapter.clearAndAddNewModels(new ArrayList<>(), "", item -> {
		});
	}

	@Override
	public void displayError(String message) {
		Toast.makeText(this, R.string.error_msg, Toast.LENGTH_LONG).show();
	}

	@Override
	public void done() {
		Toast.makeText(this, "Dodano", Toast.LENGTH_SHORT).show();
	}

	@Override
	public SearchComponent searchComponent() {
		return searchComponent;
	}
}

package hr.com.solo.solo.utils;

import androidx.annotation.DrawableRes;
import android.widget.ImageView;

// 2017-04-10 Ian Rumac

public interface ImageLoader {
	void loadImage(ImageView view, String url);
	void loadImageWithPlaceHolder(ImageView view, String url, @DrawableRes int placeHolderResource);
	void loadImageWithPlaceHolderCenterCrop(ImageView view, String url, @DrawableRes int placeHolderResource);
}

package hr.com.solo.solo.archive.list.ui;

import java.net.UnknownHostException;

import javax.inject.Inject;
import javax.inject.Named;

import hr.com.solo.solo.R;
import hr.com.solo.solo.archive.list.ReceiptArchiveContract;
import hr.com.solo.solo.archive.list.interactors.GetReceiptArchiveUseCase;
import hr.com.solo.solo.archive.search.network.ReceiptItemListResponseWrapper;
import hr.com.solo.solo.core.CoreApplication;
import hr.com.solo.solo.utils.PrefsUtils;
import io.reactivex.Scheduler;

// 2017-04-08 Ian Rumac

public class ReceiptArchivePresenterImpl implements ReceiptArchiveContract.ReceiptArchivePresenter {
	private ReceiptArchiveContract.ReceiptArchiveView view;
	private final GetReceiptArchiveUseCase useCase;
	private final Scheduler postExecution;

	@Inject
	public ReceiptArchivePresenterImpl(GetReceiptArchiveUseCase useCase, @Named("post_execution") Scheduler postExecution) {
		this.postExecution = postExecution;
		this.useCase = useCase;
	}

	private void displayResults(ReceiptItemListResponseWrapper wrapper) {
		PrefsUtils.saveData(wrapper);
		if(view!=null) {
			if (wrapper.status != 0) {
				view.displayError(wrapper.message);
			} else if (wrapper.itemList != null && !wrapper.itemList.isEmpty()) {
				view.hideLoading();
				view.displayReceipts(wrapper.itemList);
			} else {
				view.displayEmpty();
				view.hideLoading();
			}
		}
	}

	@Override
	public void attachView(ReceiptArchiveContract.ReceiptArchiveView view) {
		this.view = view;
	}

	@Override
	public void detachView(ReceiptArchiveContract.ReceiptArchiveView view) {
		this.view = null;
	}

	@Override
	public void handleError(Throwable throwable) {
		if (throwable instanceof UnknownHostException) {
			view.displayError(CoreApplication.getInstance().getString(R.string.api_ded));
		} else {
			view.displayError(CoreApplication.getInstance().getString(R.string.conn_error));
		}
	}

	@Override
	public void getReceiptList(String token, boolean isRefreshing) {
		if(!isRefreshing)
			view.showLoading();

		useCase.executeWithParams(token).observeOn(postExecution).subscribe(this::displayResults, this::handleError);
	}
}

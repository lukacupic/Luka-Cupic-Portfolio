package hr.com.solo.solo.utils;

import junit.framework.TestCase;

// 2017-05-11 Ian Rumac

public class MathUtilsTest extends TestCase {
	public void testRoundUp() throws Exception {
		double amount1 = 10.57;
		assertEquals(amount1,MathUtils.roundUp("10.569",2));
		assertEquals(1.24,MathUtils.roundUp("1.2345",2));
		assertEquals(18.75,MathUtils.roundUp("18.75",2));
		assertEquals(1001.00,MathUtils.roundUp("1000.9999999999995",2));
		assertEquals(1000.99,MathUtils.roundUp("1000.994",2));
		assertEquals(1.2344,MathUtils.roundUp("1.2444444",2));
	}

	public void testDiscountPrice() throws Exception {
		assertEquals("85.0",MathUtils.getDiscountedPrice("100","15"));
		assertEquals("79.42",MathUtils.getDiscountedPrice("105.9","25"));
		assertEquals("10.63", MathUtils.getBrutoPrice(MathUtils.getDiscountedPrice("10","15"),"25"));
	}
}